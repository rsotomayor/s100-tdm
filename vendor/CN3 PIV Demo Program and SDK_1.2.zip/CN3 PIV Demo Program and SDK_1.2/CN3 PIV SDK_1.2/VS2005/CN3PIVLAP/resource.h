//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CN3PIVLAP.rc
//
#define IDD_VERIFY_SQUARE               103
#define IDD_ENROLE_SQUARE               106
#define IDD_ENROLL_SQUARE               106
#define IDC_ENABLE                      1001
#define IDC_PASSWORDSTRINGOLD           1002
#define IDC_DISSABLE                    1003
#define IDC_PASSWORDSTRINGNEW           1004
#define IDC_PASSWORD                    1005
#define IDC_BUTTON1                     1006
#define IDC_LETMEIN                     1006
#define IDC_SKIP                        1007
#define IDC_VERIFY                      1008
#define IDC_ASYNC_COMMAND               1009
#define IDC_FP_IMAGE                    1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
