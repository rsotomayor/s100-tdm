//
////////////////////////////////////////////////////////////////////////////////
//
/// \file MDPSerialPort.cpp
/// \brief Implementation file for the CMDPSerialPort object.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009, Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//
#include <stdafx.h>
#include "MDPSerialPort.h"

CMDPSerialPort::CMDPSerialPort() :
  m_pMDPMessageCallback(NULL)
{
}


CMDPSerialPort::CMDPSerialPort(UINT uiPortNum) : CSerialPort(uiPortNum),
  m_pMDPMessageCallback(NULL)
{
}


CMDPSerialPort::CMDPSerialPort(UINT uiPortNum, DWORD dwBaudRate) : CSerialPort(uiPortNum, dwBaudRate),
  m_pMDPMessageCallback(NULL)
{
}


CMDPSerialPort::~CMDPSerialPort()
{
}


int CMDPSerialPort::Open()
{
  MDPMessageInit(&m_sMessage);
  return CSerialPort::Open();
}


void CMDPSerialPort::SetMDPMessageCallback(void (*pCallback)(CMDPSerialPort *pPort, MDPMessage *psMessage))
{
  m_pMDPMessageCallback = pCallback;
}


int CMDPSerialPort::WriteMDPMessage(UINT8 ui8Port, UINT8 *pui8Data, UINT8 ui8Length)
{
  int iError=0;
  UINT8 ui8Index=0;

  if(IsOpen())
  {
    WriteByte(MDP_SYNC_BYTE);
    WriteByte(ui8Port);
    WriteByte(ui8Length);
    WriteBytes(pui8Data, ui8Length);
    iError = SERIALPORT_ERROR_NONE;
  }
  else
  {
    iError = SERIALPORT_ERROR_NOT_OPEN;
  }

  return iError;
}


int CMDPSerialPort::WriteMDPMessage(UINT8 ui8Port)
{
  return WriteMDPMessage(ui8Port, NULL, 0);
}


void CMDPSerialPort::Parse(UINT8 ui8Byte)
{
  if(MDPMessageParse(&m_sMessage, ui8Byte) != NULL)
  {
    if(m_pMDPMessageCallback != NULL)
    {
      m_pMDPMessageCallback(this, &m_sMessage);
    }
  }
}
