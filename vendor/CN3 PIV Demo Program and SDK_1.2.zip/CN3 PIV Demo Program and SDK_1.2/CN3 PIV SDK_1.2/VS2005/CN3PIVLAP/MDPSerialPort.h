//
////////////////////////////////////////////////////////////////////////////////
//
/// \file MDPSerialPort.h
/// \brief Header file for the CMDPSerialPort object.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009, Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//
#ifndef MDPSERIALPORT_H
#define MDPSERIALPORT_H

#include "SerialPort.h"
#include "MDP.h"

class CMDPSerialPort : public CSerialPort
{
  public :
    CMDPSerialPort();
    CMDPSerialPort(UINT uiPortNum);
    CMDPSerialPort(UINT uiPortNum, DWORD dwBaudRate);
    ~CMDPSerialPort();

    virtual int Open();

    void SetMDPMessageCallback(void (*pCallback)(CMDPSerialPort *pPort, MDPMessage *psMessage));

    int WriteMDPMessage(UINT8 ui8Port);
    int WriteMDPMessage(UINT8 ui8Port, UINT8 *pui8Data, UINT8 ui8Length);

  private :
    MDPMessage m_sMessage;
    void (*m_pMDPMessageCallback)(CMDPSerialPort *pPort, MDPMessage *psMessage);
    virtual void Parse(UINT8 ui8Byte);
};

#endif
