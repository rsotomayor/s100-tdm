#ifndef __MDP_H__
#define __MDP_H__
//
////////////////////////////////////////////////////////////////////////////////
//
/// \file MDP.h
/// \brief Header file for MDP message routines.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009, Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//


//
/////////////////////////////////////////////////////////////////////////////
//
// This may be supplied by Win32 but this code already exists.
//
/////////////////////////////////////////////////////////////////////////////
//
typedef unsigned char UINT8;


//
/////////////////////////////////////////////////////////////////////////////
//
// Indices and things for MDP messages.  You can change MDP_MAX_DATA_LENGTH
// to save RAM on your system if you know the max length of an MDP message
// you'll ever try to parse.  MDPMessageParse() checks it.
//
/////////////////////////////////////////////////////////////////////////////
//
#define MDP_INDEX_SYNC         0
#define MDP_INDEX_PORT         1
#define MDP_INDEX_LENGTH       2
#define MDP_INDEX_DATA         3

#define MDP_MAX_DATA_LENGTH  255
#if MDP_MAX_DATA_LENGTH < 255
#define MDP_CHECK_MAX_DATA_LENGTH
#elif MDP_MAX_DATA_LENGTH > 255
#error <MDP_MAX_DATA_LENGTH Must Be L.E. 255>
#endif
#define MDP_HEADER_LENGTH      3
#define MDP_SYNC_BYTE       0x21

#define MDP_STATE_SYNC         0
#define MDP_STATE_PORT         1
#define MDP_STATE_LENGTH       2
#define MDP_STATE_PAYLOAD      3


//
/////////////////////////////////////////////////////////////////////////////
//
// A structure representing an MDP message.
//
/////////////////////////////////////////////////////////////////////////////
//
typedef struct
{
  UINT8 m_ui8State;
  UINT8 m_pui8Message[MDP_MAX_DATA_LENGTH + MDP_HEADER_LENGTH];
  UINT8 m_ui8DataLength;
} MDPMessage;


//
/////////////////////////////////////////////////////////////////////////////
//
// Macros for extracting things from a fully parsed MDP message struct.
//
/////////////////////////////////////////////////////////////////////////////
//
#define MDP_MESSAGE_STATE(S)         (S.m_ui8State)
#define MDP_MESSAGE_SYNC(S)          (S.m_pui8Message[MDP_INDEX_SYNC])
#define MDP_MESSAGE_PORT(S)          (S.m_pui8Message[MDP_INDEX_PORT])
#define MDP_MESSAGE_DATA_LENGTH(S)   (S.m_pui8Message[MDP_INDEX_LENGTH])
#define MDP_MESSAGE_LENGTH(S)        (MDP_MESSAGE_DATA_LENGTH(S) + MDP_INDEX_DATA)
#define MDP_MESSAGE_BYTE(S, I)       (S.m_pui8Message[I])
#define MDP_MESSAGE_DATA_BYTE(S, I)  (S.m_pui8Message[MDP_INDEX_DATA + I])

#define MDP_PMESSAGE_STATE(P)        (P->m_ui8State)
#define MDP_PMESSAGE_SYNC(P)         (P->m_pui8Message[MDP_INDEX_SYNC])
#define MDP_PMESSAGE_PORT(P)         (P->m_pui8Message[MDP_INDEX_PORT])
#define MDP_PMESSAGE_DATA_LENGTH(P)  (P->m_pui8Message[MDP_INDEX_LENGTH])
#define MDP_PMESSAGE_LENGTH(P)       (MDP_PMESSAGE_DATA_LENGTH(P) + MDP_INDEX_DATA)
#define MDP_PMESSAGE_BYTE(P, I)      (P->m_pui8Message[I])
#define MDP_PMESSAGE_DATA_BYTE(P, I) (P->m_pui8Message[MDP_INDEX_DATA + I])


//
////////////////////////////////////////////////////////////////////////////////
//
// Function Prototypes
//
////////////////////////////////////////////////////////////////////////////////
//
#ifdef __cplusplus
extern "C" {
#endif
  void MDPMessageInit(MDPMessage *pMessage);
  MDPMessage * MDPMessageParse(MDPMessage * pMessage, UINT8 ui8Byte);
#ifdef __cplusplus
}
#endif

#endif
