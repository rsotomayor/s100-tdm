//
////////////////////////////////////////////////////////////////////////////////
//
/// \file CN3PIV.h
/// \brief Header file for the CCN3PIV object.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009, Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//
#ifndef CN3PIV_H
#define CN3PIV_H

#include "MorphoSmartUSBSerialPort.h"
#include "MDPSerialPort.h"

/// <summary>
/// Error codes returned from CN3PIV member functions.
/// </summary>
enum
{
  /// <summary>
  /// Unknown error.
  /// </summary>
  CN3PIV_ERROR_UNKNOWN = -1,

  /// <summary>
  /// No error.
  /// </summary>
  CN3PIV_ERROR_NONE = 0,

  /// <summary>
  /// Required parameter is null.
  /// </summary>
  CN3PIV_ERROR_NULL_PARAMETER,

  /// <summary>
  /// Length of parameter is inappropriate.
  /// </summary>
  CN3PIV_ERROR_LENGTH_PARAMETER,

  /// <summary>
  /// Parameter value is bad.
  /// </summary>
  CN3PIV_ERROR_BAD_PARAMETER,

  /// <summary>
  /// Serial port is not open.
  /// </summary>
  CN3PIV_ERROR_NOT_OPEN,

  /// <summary>
  /// Error with underlying serial port.
  /// </summary>
  CN3PIV_ERROR_PORT,

  /// <summary>
  /// Error reading values from registry.
  /// </summary>
  CN3PIV_ERROR_REGISTRY,

  /// <summary>
  /// Error finding MSR/FPR port numbers from driver registry entries.
  /// </summary>
  CN3PIV_ERROR_FINDING_PORT,
};

/// <summary>
/// Ports used in MDP message communication with CN3PIV MSR.
/// </summary>
enum
{
  /// <summary>
  /// Ping port - MSR replies with f/w version and system info.
  /// </summary>
  CN3PIV_MSRPORT_PING = 0x00,

  /// <summary>
  /// Data request port - MSR replies with last MSR swipe data.
  /// </summary>
  CN3PIV_MSRPORT_DATA_REQUEST = 0x01,

  /// <summary>
  /// Data clear port - MSR clears last MSR swipe data and echoes message.
  /// </summary>
  CN3PIV_MSRPORT_DATA_CLEAR = 0x02,

  /// <summary>
  /// Power control port - MSR chip controls power for other stuff too.
  /// </summary>
  CN3PIV_MSRPORT_POWER = 0x03,

  /// <summary>
  /// MSR track one data/error port.
  /// </summary>
  CN3PIV_MSRPORT_TRACK1 = 0x61,

  /// <summary>
  /// MSR track two data/error port.
  /// </summary>
  CN3PIV_MSRPORT_TRACK2 = 0x62,

  /// <summary>
  /// MSR track three data/error port.
  /// </summary>
  CN3PIV_MSRPORT_TRACK3 = 0x63,

  /// <summary>
  /// MSR error message port.
  /// </summary>
  CN3PIV_MSRPORT_ERROR = 0xFF,
};

/// <summary>
/// Control codes used for power control of CN3PIV FPR and SCR.
/// </summary>
enum
{
  /// <summary>
  /// Fingerprint sensor power control.
  /// </summary>
  CN3PIV_POWERCONTROL_FP = 0x01,

  /// <summary>
  /// Smartcard reader power control
  /// </summary>
  CN3PIV_POWERCONTROL_CC = 0x02,

  /// <summary>
  /// 5 volt boost converter power control.
  /// </summary>
  CN3PIV_POWERCONTROL_5V = 0x03,
};


/// Object representing CN3PIV hardware interfaces and data flows.
class CCN3PIV
{
  public :
    CCN3PIV();
    ~CCN3PIV();

    UINT GetMSRPortNum();
    UINT GetFPRPortNum();

    void SetMSRMessageCallback(void (*pCallback)(CMDPSerialPort *pPort, MDPMessage *psMessage));
    void SetMSRReadErrorCallback(void (*pCallback)(CSerialPort *pPort, DWORD dwError));
    void SetFPRMessageCallback(void (*pCallback)(CMorphoSmartUSBSerialPort *pPort, MorphoSmartUSBMessage *psMessage));
    void SetFPRReadErrorCallback(void (*pCallback)(CSerialPort *pPort, DWORD dwError));

    BOOL FindMSR();
    BOOL FindFPR();

    int MSROpen();
    int MSRClose();
    int FPROpen();
    int FPRClose();

    BOOL MSRIsOpen();
    BOOL FPRIsOpen();

    int MSRSendPing();
    int MSRSendPowerSet(bool bFPOn, bool bCCOn, bool b5VOn);

    int FPRSendGetDescriptor(UINT8 ui8Format);
    int FPRSendStartGrab();

  private :
    CMorphoSmartUSBSerialPort m_oFPRPort;
    CMDPSerialPort m_oMSRPort;
};

#endif
