//
////////////////////////////////////////////////////////////////////////////////
//
/// \file CN3PIVLAP.cpp
/// \brief Implementation file for CN3PIVLAP.dll.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009, Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//
#include "stdafx.h"
#include "CN3PIVLAP.h"
#include <windows.h>
#include <commctrl.h>
#include <lap.h>
#include "resource.h"
#include "CN3PIV.h"
#include "MORPHO_Types.h"
#include "MORPHO_Errors.h"

HINSTANCE g_hInstance;
BOOL CALLBACK Enrole_DlgProc( HWND	hDlg, UINT	uMsg, WPARAM	wParam, LPARAM	lParam );
BOOL CALLBACK Verify_DlgProc( HWND	hDlg, UINT	uMsg, WPARAM	wParam, LPARAM	lParam );

extern "C" {
BOOL SetPassword( LPWSTR lpszOldPassword, LPWSTR lpszNewPassword );
BOOL SetPasswordActive( BOOL bActive, LPWSTR lpszPassword );
BOOL GetPasswordActive();
BOOL CheckPassword(LPWSTR lpszPassword);
}

BOOL g_bInit=FALSE;
CCN3PIV g_cn3piv;


#define WM_MSR_READ_THREAD_ERROR   (WM_APP + 1)
#define WM_MSR_MESSAGE             (WM_APP + 2)
#define WM_FPR_READ_THREAD_ERROR   (WM_APP + 3)
#define WM_FPR_MESSAGE             (WM_APP + 4)

#define MORPHOSMART_TEST_BITS_PER_PIXEL 8
#define MORPHOSMART_TEST_PALETTE_ENTRIES 256
HWND g_hActiveDialog=0;
LPLOGPALETTE g_pLogicalPalette=NULL;
HPALETTE g_hPalette=0;
LPBITMAPINFO g_pBMI=NULL;

//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn FreeVerifyMemory()
/// \brief Frees memory allocated for fingerprint grab in \ref AllocateVerifyMemory.
//
////////////////////////////////////////////////////////////////////////////////
//
void FreeVerifyMemory()
{
  if(g_pLogicalPalette != NULL)
  {
    delete g_pLogicalPalette;
    g_pLogicalPalette = NULL;
  }
  if(g_pBMI != NULL)
  {
    delete g_pBMI;
    g_pBMI = NULL;
  }
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn AllocateVerifyMemory()
/// \brief Allocates memory for fingerprint grab.
/// \remarks Caller must call \ref FreeVerifyMemory to free allocated memory.
//
////////////////////////////////////////////////////////////////////////////////
//
void AllocateVerifyMemory()
{
  //
  // first make sure these pointers are all freed up first
  //
  FreeVerifyMemory();

  //
  // i'm allocating extra memory here at g_pLogicalPalette (2 DWORDs instead of 2 WORDs).
  // i do this because LOGPALETTE declares "PALETTEENTRY palPalEntry[1]"
  // instead of "PALETTEENTRY *palPalEntry", so the memory must be contiguous
  // AND it must be dynamic (this just seems dumb to me, but hey, it's MS).
  // anyway, allocating two WORDS and then N*sizeof(PALETTEENTRY) would
  // assume the struct packing in LOGPALETTE is byte-wise (?), and I don't
  // want to depend on that.
  //
  g_pLogicalPalette = (LPLOGPALETTE) new char[2*sizeof(DWORD) + MORPHOSMART_TEST_PALETTE_ENTRIES*sizeof(PALETTEENTRY)];
  g_pLogicalPalette->palVersion = 0x0300;
  g_pLogicalPalette->palNumEntries = MORPHOSMART_TEST_PALETTE_ENTRIES;
  for(int i=0; i<MORPHOSMART_TEST_PALETTE_ENTRIES; i++)
  {
    g_pLogicalPalette->palPalEntry[i].peRed = (BYTE)i;
    g_pLogicalPalette->palPalEntry[i].peGreen = (BYTE)i;
    g_pLogicalPalette->palPalEntry[i].peBlue = (BYTE)i;
    g_pLogicalPalette->palPalEntry[i].peFlags = (BYTE)i;
  }
  g_hPalette = ::CreatePalette(g_pLogicalPalette);

  g_pBMI = (LPBITMAPINFO) new char[sizeof(BITMAPINFOHEADER) + MORPHOSMART_TEST_PALETTE_ENTRIES*sizeof(RGBQUAD)];
  g_pBMI->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
  g_pBMI->bmiHeader.biPlanes = 1;
  g_pBMI->bmiHeader.biBitCount = MORPHOSMART_TEST_BITS_PER_PIXEL;
  g_pBMI->bmiHeader.biCompression = BI_RGB;
  g_pBMI->bmiHeader.biSizeImage = 0;
  g_pBMI->bmiHeader.biXPelsPerMeter = 0;
  g_pBMI->bmiHeader.biYPelsPerMeter = 0;
  g_pBMI->bmiHeader.biClrUsed = MORPHOSMART_TEST_PALETTE_ENTRIES;
  g_pBMI->bmiHeader.biClrUsed = 0;
  for(int i=0; i<MORPHOSMART_TEST_PALETTE_ENTRIES; i++)
  {
    g_pBMI->bmiColors[i].rgbRed = (BYTE)i;
    g_pBMI->bmiColors[i].rgbGreen = (BYTE)i;
    g_pBMI->bmiColors[i].rgbBlue = (BYTE)i;
    g_pBMI->bmiColors[i].rgbReserved = 0;
  }
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn FPRReadErrorCallback(CSerialPort *pPort, DWORD dwError)
/// \brief Callback function called on FPR read error.
/// \param pPort Pointer to underlying serial port object.
/// \param dwError Error returned from serial port read thread.
//
////////////////////////////////////////////////////////////////////////////////
//
void FPRReadErrorCallback(CSerialPort *pPort, DWORD dwError)
{
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn FPRMessageCallback(CMorphoSmartUSBSerialPort *pPort, MorphoSmartUSBMessage *psMessage)
/// \brief Callback function called on FPR message receive.
/// \param pPort Pointer to underlying serial port object.
/// \param psMessage Pointer to message parsed by serial port.
/// \remarks Note that, since this function is called on the serial port read
///  thread, we must allocate a new message struture and copy the one passed in,
///  as it will be re-used in the serial port parser.
//
////////////////////////////////////////////////////////////////////////////////
//
void FPRMessageCallback(CMorphoSmartUSBSerialPort *pPort, MorphoSmartUSBMessage *psMessage)
{
  if(g_hActiveDialog != 0)
  {
    MorphoSmartUSBMessage *psMsg = new MorphoSmartUSBMessage;
    memcpy(psMsg, psMessage, sizeof(MorphoSmartUSBMessage));
    ::PostMessage(g_hActiveDialog, WM_FPR_MESSAGE, (WPARAM)pPort, (LPARAM)psMsg);
  }
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn MSRReadErrorCallback(CSerialPort *pPort, DWORD dwError)
/// \brief Callback function called on MSR read error.
/// \param pPort Pointer to underlying serial port object.
/// \param dwError Error returned from serial port read thread.
//
////////////////////////////////////////////////////////////////////////////////
//
void MSRReadErrorCallback(CSerialPort *pPort, DWORD dwError)
{
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn MSRMessageCallback(CMDPSerialPort *pPort, MDPMessage *psMessage)
/// \brief Callback function called on MSR message receive.
/// \param pPort Pointer to underlying serial port object.
/// \param psMessage Pointer to message parsed by serial port.
/// \remarks Note that, since this function is called on the serial port read
///  thread, we must allocate a new message struture and copy the one passed in,
///  as it will be re-used in the serial port parser.
//
////////////////////////////////////////////////////////////////////////////////
//
void MSRMessageCallback(CMDPSerialPort *pPort, MDPMessage *psMessage)
{
  if(g_hActiveDialog != 0)
  {
    MDPMessage *psMsg = new MDPMessage;
    memcpy(psMsg, psMessage, sizeof(MDPMessage));
    ::PostMessage(g_hActiveDialog, WM_MSR_MESSAGE, (WPARAM)pPort, (LPARAM)psMsg);
  }
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn LogInit()
/// \brief Logging initialization function.
//
/// \fn LogMessage(char *pcMessage)
/// \brief Message logging function.
/// \param pcMessage Pointer to null-terminated message to log.
//
////////////////////////////////////////////////////////////////////////////////
//
char g_pcLogFileBuffer[1024];
void LogInit()
{
  //HANDLE hFile = CreateFile(L"\\CN3PIVLAP.txt", GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, NULL, NULL);
  //CloseHandle(hFile);
}
void LogMessage(char *pcMessage)
{
  //DWORD written = 0;
  //HANDLE hFile = CreateFile(L"\\CN3PIVLAP.txt", GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, NULL, NULL);
  //SetFilePointer(hFile, 0, 0, FILE_END);
  //WriteFile(hFile, pcMessage, strlen(pcMessage), &written, NULL);
  //CloseHandle(hFile);
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
/// \brief Dll main function as per Windows specification.
/// \param hModule Handle to module.
/// \param ul_reason_for_call Reason for DllMain call.
/// \param lpReserved Reserved, set to 0.
/// \return Boolean as per Windows specification.
//
////////////////////////////////////////////////////////////////////////////////
//
BOOL APIENTRY DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
  //
  // if not initialized yet, do one-time init stuff
  //
  if(!g_bInit)
  {
    //
    // initialize the logging interface
    //
    LogInit();
    //sprintf(g_pcLogFileBuffer, "DllMain (init)+ (%8.8X %8.8X %8.8X)\r\n", hModule, ul_reason_for_call, lpReserved);
    //LogMessage(g_pcLogFileBuffer);

    //
    // note that we're now initalized so this only happens once
    //
    g_bInit = TRUE;
  }
  else
  {
    //sprintf(g_pcLogFileBuffer, "DllMain+ (%8.8X %8.8X %8.8X)\r\n", hModule, ul_reason_for_call, lpReserved);
    //LogMessage(g_pcLogFileBuffer);
  }

  //
  // processing depends on reason we were called
  //
  switch(ul_reason_for_call)
  {
    case DLL_PROCESS_ATTACH:
    {
      //sprintf(g_pcLogFileBuffer, " DLL_PROCESS_ATTACH\r\n");
      //LogMessage(g_pcLogFileBuffer);
    }
    break;

    case DLL_THREAD_ATTACH:
    {
      //sprintf(g_pcLogFileBuffer, " DLL_THREAD_ATTACH\r\n");
      //LogMessage(g_pcLogFileBuffer);
    }
    break;

    case DLL_THREAD_DETACH:
    {
      //sprintf(g_pcLogFileBuffer, " DLL_THREAD_DETACH\r\n");
      //LogMessage(g_pcLogFileBuffer);
    }
    break;

    case DLL_PROCESS_DETACH:
    {
      //sprintf(g_pcLogFileBuffer, " DLL_PROCESS_DETACH\r\n");
      //LogMessage(g_pcLogFileBuffer);
    }
    break;
  }

  //
  // save off the handle to this instance; this global is used later
  //
  g_hInstance = (HINSTANCE)hModule;

  //sprintf(g_pcLogFileBuffer, "DllMain-\r\n");
  //LogMessage(g_pcLogFileBuffer);
  return TRUE;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn InitLAP(InitLap* il)
/// \brief LAP-required initialization function.
/// \param il Pointer to InitLap struct.
/// \return BOOl as per LAP specification.
/// \details Performs one-time initialization of CN3PIVLAP.
//
////////////////////////////////////////////////////////////////////////////////
//
BOOL InitLAP(
        InitLap* il
        )
{
  sprintf(g_pcLogFileBuffer, "InitLAP+\r\n");
  LogMessage(g_pcLogFileBuffer);

  g_cn3piv.SetMSRMessageCallback(MSRMessageCallback);
  g_cn3piv.SetMSRReadErrorCallback(MSRReadErrorCallback);
  g_cn3piv.SetFPRMessageCallback(FPRMessageCallback);
  g_cn3piv.SetFPRReadErrorCallback(FPRReadErrorCallback);
  sprintf(g_pcLogFileBuffer, " MSR COM%d FPR COM%d\r\n", g_cn3piv.GetMSRPortNum(), g_cn3piv.GetFPRPortNum());
  LogMessage(g_pcLogFileBuffer);

  sprintf(g_pcLogFileBuffer, "InitLAP-\r\n");
  LogMessage(g_pcLogFileBuffer);
  return TRUE;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn DeinitLAP()
/// \brief LAP-required deinitialization function.
//
////////////////////////////////////////////////////////////////////////////////
//
void DeinitLAP()
{
  sprintf(g_pcLogFileBuffer, "DeinitLAP+\r\n");
  LogMessage(g_pcLogFileBuffer);

  sprintf(g_pcLogFileBuffer, "DeinitLAP-\r\n");
  LogMessage(g_pcLogFileBuffer);
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn VerifyUser(const GUID *AEKey, LPCWSTR pwszAEDisplayText, HWND hwndParent, DWORD dwOptions, PVOID pExtended)
/// \brief LAP-required verify user function.
/// \param AEKey
/// \param pwszAEDisplayText
/// \param hwndParent
/// \param dwOptions
/// \param pExtended
/// \return BOOL as per LAP specification
/// \details Creates verify-user dialog box and runs user verification.
/// \see http://msdn.microsoft.com/en-us/library/aa918210.aspx
//
////////////////////////////////////////////////////////////////////////////////
//
BOOL VerifyUser(const GUID *AEKey,
                LPCWSTR pwszAEDisplayText,
                HWND   hwndParent,
                DWORD dwOptions,
                PVOID pExtended
                )
{
  sprintf(g_pcLogFileBuffer, "VerifyUser+\r\n");
  LogMessage(g_pcLogFileBuffer);

  sprintf(g_pcLogFileBuffer, " %8.8X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X\r\n",
    AEKey->Data1, AEKey->Data2, AEKey->Data3,
    AEKey->Data4[0], AEKey->Data4[1], AEKey->Data4[2], AEKey->Data4[3],
    AEKey->Data4[4], AEKey->Data4[5], AEKey->Data4[6], AEKey->Data4[7]);
  LogMessage(g_pcLogFileBuffer);
  if(pwszAEDisplayText != NULL)
  {
    sprintf(g_pcLogFileBuffer, " %s\r\n", pwszAEDisplayText);
    LogMessage(g_pcLogFileBuffer);
  }
  sprintf(g_pcLogFileBuffer, " %8.8X %8.8X %8.8X\r\n", hwndParent, dwOptions, pExtended);
  LogMessage(g_pcLogFileBuffer);

  BOOL bReturn=FALSE;
  if((dwOptions & VU_NO_UI) == 0)
  {
    sprintf(g_pcLogFileBuffer, " calling dlg box\r\n");
    LogMessage(g_pcLogFileBuffer);
    bReturn = DialogBoxParam(g_hInstance, MAKEINTRESOURCE(IDD_VERIFY_SQUARE), hwndParent, Verify_DlgProc, (LPARAM)false);
  }
  else
  {
    sprintf(g_pcLogFileBuffer, " no call to dlg box\r\n");
    LogMessage(g_pcLogFileBuffer);
  }

  sprintf(g_pcLogFileBuffer, "VerifyUser- (%d)\r\n", (int)bReturn);
  LogMessage(g_pcLogFileBuffer);
  return bReturn;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn LAPCreateEnrollmentConfigDialog(HWND hwndParent, DWORD dwOptions)
/// \brief LAP-requried enrollment config dialog creation function.
/// \param hwndParent
/// \param dwOptions
/// \return BOOL as per LAP specification.
/// \see http://msdn.microsoft.com/en-us/library/aa925169.aspx
//
////////////////////////////////////////////////////////////////////////////////
//
BOOL LAPCreateEnrollmentConfigDialog(HWND hwndParent,DWORD dwOptions)
{
  sprintf(g_pcLogFileBuffer, "LAPCreateEnrollmentConfigDialog+\r\n");
  LogMessage(g_pcLogFileBuffer);

	DialogBoxParam( g_hInstance, MAKEINTRESOURCE(IDD_ENROLE_SQUARE), hwndParent,
		Enrole_DlgProc, (LPARAM)false );

  sprintf(g_pcLogFileBuffer, "LAPCreateEnrollmentConfigDialog-\r\n");
  LogMessage(g_pcLogFileBuffer);
	return true;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn VerifyUserStart(const GUID* AEKey, LPCWSTR pwszAEDisplayText, HWND hwndParent, DWORD dwOptions, PVOID pExtended)
/// \brief LAP-required verify user start function.
/// \param AEKey
/// \param pwszAEDisplayText
/// \param hwndParent
/// \param dwOptions
/// \param pExtended
/// \see http://msdn.microsoft.com/en-us/library/ms926488.aspx
//
////////////////////////////////////////////////////////////////////////////////
//
VOID VerifyUserStart(
  const GUID* AEKey,
  LPCWSTR pwszAEDisplayText,
  HWND hwndParent,
  DWORD dwOptions,
  PVOID pExtended
)
{
  sprintf(g_pcLogFileBuffer, "VerifyUserStart+\r\n");
  LogMessage(g_pcLogFileBuffer);

  sprintf(g_pcLogFileBuffer, " %8.8X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X %2.2X\r\n",
    AEKey->Data1, AEKey->Data2, AEKey->Data3,
    AEKey->Data4[0], AEKey->Data4[1], AEKey->Data4[2], AEKey->Data4[3],
    AEKey->Data4[4], AEKey->Data4[5], AEKey->Data4[6], AEKey->Data4[7]);
  LogMessage(g_pcLogFileBuffer);
  if(pwszAEDisplayText != NULL)
  {
    sprintf(g_pcLogFileBuffer, " %s\r\n", pwszAEDisplayText);
    LogMessage(g_pcLogFileBuffer);
  }
  sprintf(g_pcLogFileBuffer, " %8.8X %8.8X %8.8X\r\n", hwndParent, dwOptions, pExtended);
  LogMessage(g_pcLogFileBuffer);

  sprintf(g_pcLogFileBuffer, "VerifyUserStart-\r\n");
  LogMessage(g_pcLogFileBuffer);
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn VerifyUserStop()
/// \brief LAP-required verify user stop function.
/// \see http://msdn.microsoft.com/en-us/library/ms926489.aspx
//
////////////////////////////////////////////////////////////////////////////////
//
VOID VerifyUserStop()
{
  sprintf(g_pcLogFileBuffer, "VerifyUserStop+\r\n");
  LogMessage(g_pcLogFileBuffer);

  sprintf(g_pcLogFileBuffer, "VerifyUserStop-\r\n");
  LogMessage(g_pcLogFileBuffer);
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn VerifyUserToTop()
/// \brief LAP-required verify user to top function.
/// \see http://msdn.microsoft.com/en-us/library/aa925149.aspx
//
////////////////////////////////////////////////////////////////////////////////
//
VOID VerifyUserToTop()
{
  sprintf(g_pcLogFileBuffer, "VerifyUserToTop+\r\n");
  LogMessage(g_pcLogFileBuffer);

  sprintf(g_pcLogFileBuffer, "VerifyUserToTop-\r\n");
  LogMessage(g_pcLogFileBuffer);
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn OnMSRMessage(MDPMessage *psMsg)
/// \brief Handler for messages received from MSR.
/// \param psMsg Pointer to message received from MSR.
//
////////////////////////////////////////////////////////////////////////////////
//
void OnMSRMessage(MDPMessage *psMsg)
{
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn HandleMorphoImage(UINT8 ui8I, UINT32 ui32L, UINT8 *pui8V)
/// \brief Handles image from FPR by displaying it on fingerprint panel.
/// \param ui8I I parameter from ILV message.
/// \param ui32L L parameter from ILV message.
/// \param pui8V V parameter from ILV message.
/// \return Error code as per \ref CN3PIV.h.
//
////////////////////////////////////////////////////////////////////////////////
//
HWND g_hImage=NULL;
int HandleMorphoImage(UINT8 ui8I, UINT32 ui32L, UINT8 *pui8V)
{
  int iError=0;

  UINT8 ui8HeaderVersion=0, ui8HeaderSize=0, ui8Comp=0;
  UINT8 *pui8HeaderAndImage=NULL;

  sprintf(g_pcLogFileBuffer, "HandleMorphoImage+\r\n");
  LogMessage(g_pcLogFileBuffer);

  ui8HeaderVersion = pui8V[0];
  ui8HeaderSize = pui8V[1];
  ui8Comp = pui8V[10];

  switch(ui8Comp)
  {
    case MSILV_ID_COMPRESSION_NULL:
    {
      sprintf(g_pcLogFileBuffer, " comp is null\r\n");
      LogMessage(g_pcLogFileBuffer);
      pui8HeaderAndImage = pui8V;
    }
    break;

#if 0
    case MSILV_ID_COMPRESSION_V1:
    {
      unsigned long ulSize=0;
      int iError = COMPRESS_GetRawImageSize(pui8V, ui32L, &ulSize);
      if(iError == MORPHO_OK)
      {
        pui8HeaderAndImage = new UINT8[ulSize];
        if(pui8HeaderAndImage != NULL)
        {
          iError = COMPRESS_UnCompressImage(pui8V, ui32L, pui8HeaderAndImage, &ulSize);
          if(iError != MORPHO_OK)
          {
            delete pui8HeaderAndImage;
            pui8HeaderAndImage = NULL;
          }
        }
      }
    }
    break;

    case MSILV_ID_COMPRESSION_WSQ:
    {
      pui8HeaderAndImage = NULL;
    }
    break;
#endif

    default:
    {
      pui8HeaderAndImage = NULL;
    }
    break;
  }

  if(pui8HeaderAndImage != NULL)
  {
    UINT16 ui16Rows=0, ui16Cols=0;
    UINT16 ui16Vert=0, ui16Horz=0;
    UINT8 ui8CompParam=0;

    sprintf(g_pcLogFileBuffer, " processing\r\n");
    LogMessage(g_pcLogFileBuffer);

    ui16Rows = pui8HeaderAndImage[3];
    ui16Rows <<= 8;
    ui16Rows += pui8HeaderAndImage[2];
    ui16Cols = pui8HeaderAndImage[5];
    ui16Cols <<= 8;
    ui16Cols += pui8HeaderAndImage[4];
    ui16Vert = pui8HeaderAndImage[7];
    ui16Vert <<= 8;
    ui16Vert += pui8HeaderAndImage[6];
    ui16Horz = pui8HeaderAndImage[9];
    ui16Horz <<= 8;
    ui16Horz += pui8HeaderAndImage[8];
    sprintf(g_pcLogFileBuffer, " rows %d cols %d vert %d horz %d\r\n", ui16Rows, ui16Cols, ui16Vert, ui16Horz);
    LogMessage(g_pcLogFileBuffer);
    ui8CompParam = pui8HeaderAndImage[11];

    RECT rect;
    g_hImage = GetDlgItem(g_hActiveDialog, IDC_FP_IMAGE);
    sprintf(g_pcLogFileBuffer, " handles %8.8X %8.8x\r\n", g_hActiveDialog, g_hImage);
    LogMessage(g_pcLogFileBuffer);
    if(g_hImage != NULL)
    {
      if(GetClientRect(g_hImage, &rect))
      {
        HDC hDC = GetDC(g_hImage);
        sprintf(g_pcLogFileBuffer, " hDC %8.8X\r\n", hDC);
        LogMessage(g_pcLogFileBuffer);
        if(hDC != NULL)
        {
          if(SelectPalette(hDC, g_hPalette, TRUE) != NULL)
          {
            if(SetStretchBltMode(hDC, COLORONCOLOR) != 0)
            {
              g_pBMI->bmiHeader.biWidth = ui16Cols;
              g_pBMI->bmiHeader.biHeight = ui16Rows;
              if(StretchDIBits(hDC, 0, 0, rect.right-rect.left-1, rect.bottom-rect.top-1, 0, 0, (int)ui16Cols, (int)ui16Rows, &pui8HeaderAndImage[12], (LPBITMAPINFO)g_pBMI, DIB_RGB_COLORS, SRCCOPY) == GDI_ERROR)
              {
                DWORD dwError = GetLastError();
                sprintf(g_pcLogFileBuffer, " StretchDIBits() failed %8.8X %d\r\n", dwError, dwError);
                LogMessage(g_pcLogFileBuffer);
              }
              else
              {
                if(InvalidateRect(g_hActiveDialog, NULL, TRUE))
                {
                  sprintf(g_pcLogFileBuffer, " success(?)\r\n");
                  LogMessage(g_pcLogFileBuffer);
                }
                else
                {
                  sprintf(g_pcLogFileBuffer, " InvalidateRect() failed\r\n");
                  LogMessage(g_pcLogFileBuffer);
                }
              }
            }
            else
            {
              sprintf(g_pcLogFileBuffer, " SetStretchBltMode() failed\r\n");
              LogMessage(g_pcLogFileBuffer);
            }
          }
          else
          {
            sprintf(g_pcLogFileBuffer, " SelectPalette() failed\r\n");
            LogMessage(g_pcLogFileBuffer);
          }
        }
        else
        {
          sprintf(g_pcLogFileBuffer, " GetDC() failed\r\n");
          LogMessage(g_pcLogFileBuffer);
        }
      }
      else
      {
        sprintf(g_pcLogFileBuffer, " GetClientRect() failed\r\n");
        LogMessage(g_pcLogFileBuffer);
      }
    }
    else
    {
      sprintf(g_pcLogFileBuffer, " error from GetDlgItem()\r\n");
      LogMessage(g_pcLogFileBuffer);
    }
#if 0
    RECT rect;
    GetDlgItem(IDC_FP_IMAGE)->GetClientRect(&rect);
    CDC *pDC = GetDlgItem(IDC_FP_IMAGE)->GetDC();
    if(SelectPalette(pDC->GetSafeHdc(), m_hPalette, TRUE) != NULL)
    {
      if(pDC->SetStretchBltMode(COLORONCOLOR) != 0)
      {
        m_pBMI->bmiHeader.biWidth = ui16Cols;
        m_pBMI->bmiHeader.biHeight = ui16Rows;
        if(StretchDIBits(pDC->GetSafeHdc(), 0, 0, rect.right-rect.left-1, rect.bottom-rect.top-1, 0, 0, (int)ui16Cols, (int)ui16Rows, &pui8HeaderAndImage[12], (LPBITMAPINFO) m_pBMI, DIB_RGB_COLORS, SRCCOPY) == GDI_ERROR)
        {
          iError = -3;
          TRACE(" error from StretchDIBits\n");
        }
      }
      else
      {
        TRACE(" error from SetStretchBltMode\n");
        iError = -2;
      }
    }
    else
    {
      TRACE(" error from SelectPalette\n");
      iError = -1;
    }
#endif

#if 0
    if(pui8HeaderAndImage != pui8V)
    {
      delete pui8HeaderAndImage;
    }
#endif
  }

  sprintf(g_pcLogFileBuffer, "HandleMorphoImage-\r\n");
  LogMessage(g_pcLogFileBuffer);
  return iError;
}

//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn OnFPRMessage(MorphoSmartUSBMessage *psMsg)
/// \brief Handler for messages received from FPR.
/// \param psMsg Pointer to message received from FPR.
/// \return True if FPR message is last image from fingerprint grab, else false.
//
////////////////////////////////////////////////////////////////////////////////
//
BOOL OnFPRMessage(MorphoSmartUSBMessage *psMsg)
{
  UINT8 ui8I=0;
  UINT32 ui32L=0;
  UINT8 *pui8V=NULL;
  UINT8 ui8LenLen=0;
  WCHAR *pwcText=NULL;
  BOOL bLast=FALSE;

  //
  // just  extract the message stuff and process it
  //
  pui8V = MorphoSmartILVExtract(psMsg->m_pui8ILV, &ui8I, &ui32L, &ui8LenLen);
  switch(ui8I)
  {
    case MSILV_GET_DESCRIPTOR:
    {
#if 0
      buf.Format(_T("GET_DESCRIPTOR (%8.8X)\r\n"), ui32L);
      text += buf;

      //
      // skip over 1-byte status in first V byte
      //
      pui8V++;
      if(ui32L == 0x0000000B)
      {
        //
        // ID_FORMAT_BIN_VERSION style reply (0x0000000B bytes length),
        // extract internal ILV message and add to text box.
        //
        pui8V = MorphoSmartILVExtract(pui8V, &ui8I, &ui32L, &ui8LenLen);
        if(ui8I == MSILV_ID_FORMAT_BIN_VERSION)
        {
          buf.Format(_T("ID_FORMAT_BIN_VERSION (%8.8X)\r\n"), ui32L);
          text += buf;
          pwcText = new WCHAR[ui32L+1];
          MultiByteToWideChar(CP_ACP, 0, (char *)pui8V, -1, pwcText, ui32L);
          pwcText[ui32L] = 0;
          text += pwcText;
          text += "\r\n";
          delete pwcText;
          pui8V += ui32L;
        }
      }
      else
      {
        //
        // ID_FORMAT_TEXT style reply, extract internal ILV messages
        // and add their info to the text box.
        //
        pui8V = MorphoSmartILVExtract(pui8V, &ui8I, &ui32L, &ui8LenLen);
        if(ui8I == MSILV_ID_DESC_PRODUCT)
        {
          buf.Format(_T("ID_DESC_PRODUCT (%8.8X)\r\n"), ui32L);
          text += buf;
          pwcText = new WCHAR[ui32L+1];
          MultiByteToWideChar(CP_ACP, 0, (char *)pui8V, -1, pwcText, ui32L);
          pwcText[ui32L] = 0;
          text += pwcText;
          text += "\r\n";
          delete pwcText;
          pui8V += ui32L;
        }
        pui8V = MorphoSmartILVExtract(pui8V, &ui8I, &ui32L, &ui8LenLen);
        if(ui8I == MSILV_ID_DESC_SENSOR)
        {
          buf.Format(_T("ID_DESC_SENSOR (%8.8X)\r\n"), ui32L);
          text += buf;
          pwcText = new WCHAR[ui32L+1];
          MultiByteToWideChar(CP_ACP, 0, (char *)pui8V, -1, pwcText, ui32L);
          pwcText[ui32L] = 0;
          text += pwcText;
          text += "\r\n";
          delete pwcText;
          pui8V += ui32L;
        }
        pui8V = MorphoSmartILVExtract(pui8V, &ui8I, &ui32L, &ui8LenLen);
        if(ui8I == MSILV_ID_DESC_SOFTWARE)
        {
          buf.Format(_T("ID_DESC_SOFTWARE (%4.4X)\r\n"), ui32L);
          text += buf;
          pwcText = new WCHAR[ui32L+1];
          MultiByteToWideChar(CP_ACP, 0, (char *)pui8V, -1, pwcText, ui32L);
          pwcText[ui32L] = 0;
          text += pwcText;
          text += "\r\n";
          delete pwcText;
          pui8V += ui32L;
        }
      }
#endif
    }
    break;

    case MSILV_ASYNC_MESSAGE:
    {
      UINT32 ui32Parsed=0, ui32Total=0;
      sprintf(g_pcLogFileBuffer, " ASYNC_MESSAGE (%8.8X)\r\n", ui32L);
      LogMessage(g_pcLogFileBuffer);

      //
      // this message contains a status byte and then perhaps several
      // ILV messages, so ui32Total is the total number of bytes we
      // can parse for all internal ILVs and the status byte.  add the
      // status byte to the text box, skip over it and get internal ILVs.
      //
      ui32Total = ui32L;
      //buf.Format(_T("STATUS %2.2X\r\n"), *pui8V);
      //text += buf;
      ui32Parsed = 1;
      pui8V++;

      //
      // now loop through and parse internal ILV messages
      //
      while(ui32Parsed < ui32Total)
      {
        //
        // extract the next message, save off length so we can
        // add it to ui32Parsed after processing.  processing
        // depends on I parameter.
        //
        pui8V = MorphoSmartILVExtract(pui8V, &ui8I, &ui32L, &ui8LenLen);
        UINT32 ui32ThisLen = ui32L;
        switch(ui8I)
        {
          case MSILV_MESSAGE_COMMAND_CMD:
          {
            UINT32 ui32Command=0;
            sprintf(g_pcLogFileBuffer, " MESSAGE_COMMAND_CMD (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            ui32Command = pui8V[3];
            ui32Command <<= 8;
            ui32Command += pui8V[2];
            ui32Command <<= 8;
            ui32Command += pui8V[1];
            ui32Command <<= 8;
            ui32Command += pui8V[0];
            switch(ui32Command)
            {
              case MORPHO_MOVE_NO_FINGER:
              {
                sprintf(g_pcLogFileBuffer, " NO_FINGER\r\n");
                LogMessage(g_pcLogFileBuffer);
                //GetDlgItem(g_hActiveDialog, IDC_ASYNC_COMMAND)->SetWindowText(_T("No Finger"));
                SetWindowText(GetDlgItem(g_hActiveDialog, IDC_ASYNC_COMMAND), _T("No Finger"));
              }
              break;

              case MORPHO_MOVE_FINGER_UP:
              {
                sprintf(g_pcLogFileBuffer, " MOVE_FINGER_UP\r\n");
                LogMessage(g_pcLogFileBuffer);
                //GetDlgItem(IDC_ASYNC_COMMAND)->SetWindowTextW(_T("Move Up"));
                SetWindowText(GetDlgItem(g_hActiveDialog, IDC_ASYNC_COMMAND), _T("Move Up"));
              }
              break;

              case MORPHO_MOVE_FINGER_DOWN:
              {
                sprintf(g_pcLogFileBuffer, " MOVE_FINGER_DOWN\r\n");
                LogMessage(g_pcLogFileBuffer);
                //GetDlgItem(IDC_ASYNC_COMMAND)->SetWindowTextW(_T("Move Down"));
                SetWindowText(GetDlgItem(g_hActiveDialog, IDC_ASYNC_COMMAND), _T("Move Down"));
              }
              break;

              case MORPHO_MOVE_FINGER_LEFT:
              {
                sprintf(g_pcLogFileBuffer, " MOVE_FINGER_LEFT\r\n");
                LogMessage(g_pcLogFileBuffer);
                //GetDlgItem(IDC_ASYNC_COMMAND)->SetWindowTextW(_T("Move Left"));
                SetWindowText(GetDlgItem(g_hActiveDialog, IDC_ASYNC_COMMAND), _T("Move Left"));
              }
              break;

              case MORPHO_MOVE_FINGER_RIGHT:
              {
                sprintf(g_pcLogFileBuffer, " MOVE_FINGER_RIGHT\r\n");
                LogMessage(g_pcLogFileBuffer);
                //GetDlgItem(IDC_ASYNC_COMMAND)->SetWindowTextW(_T("Move Right"));
                SetWindowText(GetDlgItem(g_hActiveDialog, IDC_ASYNC_COMMAND), _T("Move Right"));
              }
              break;

              case MORPHO_PRESS_FINGER_HARDER:
              {
                sprintf(g_pcLogFileBuffer, " PRESS_FINGER_HARDER\r\n");
                LogMessage(g_pcLogFileBuffer);
                //GetDlgItem(IDC_ASYNC_COMMAND)->SetWindowTextW(_T("Press Harder"));
                SetWindowText(GetDlgItem(g_hActiveDialog, IDC_ASYNC_COMMAND), _T("Press Harder"));
              }
              break;

              case MORPHO_LATENT:
              {
                sprintf(g_pcLogFileBuffer, " LATENT\r\n");
                LogMessage(g_pcLogFileBuffer);
                //GetDlgItem(IDC_ASYNC_COMMAND)->SetWindowTextW(_T("Latent"));
                SetWindowText(GetDlgItem(g_hActiveDialog, IDC_ASYNC_COMMAND), _T("Latent"));
              }
              break;

              case MORPHO_REMOVE_FINGER:
              {
                sprintf(g_pcLogFileBuffer, " REMOVE_FINGER\r\n");
                LogMessage(g_pcLogFileBuffer);
                //GetDlgItem(IDC_ASYNC_COMMAND)->SetWindowTextW(_T("Remove Finger"));
                SetWindowText(GetDlgItem(g_hActiveDialog, IDC_ASYNC_COMMAND), _T("Remove Finger"));
              }
              break;

              case MORPHO_FINGER_OK:
              {
                sprintf(g_pcLogFileBuffer, " FINGER_OK\r\n");
                LogMessage(g_pcLogFileBuffer);
                //GetDlgItem(IDC_ASYNC_COMMAND)->SetWindowTextW(_T("Finger OK"));
                SetWindowText(GetDlgItem(g_hActiveDialog, IDC_ASYNC_COMMAND), _T("Finger OK"));
              }
              break;

              default:
              {
                //buf.Format(_T("(%8.8X)\r\n"), ui32Command);
              }
              break;
            }
            //text += buf;
          }
          break;

          case MSILV_MESSAGE_IMAGE_CMD:
          {
            int iError=0;
            sprintf(g_pcLogFileBuffer, "MESSAGE_IMAGE_CMD (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            iError = HandleMorphoImage(ui8I, ui32L, pui8V);
            if(iError == MORPHO_OK)
            {
              //buf.Format(_T("IMAGE OK\r\n"));
            }
            else
            {
              //buf.Format(_T("IMAGE ERR %d\r\n"), iError);
            }
            //text += buf;
          }
          break;

          case MSILV_MESSAGE_ENROLLMENT_CMD:
          {
            //buf.Format(_T("MESSAGE_ENROLLMENT_CMD (%8.8X)\r\n"), ui32L);
            //text += buf;
          }
          break;

          case MSILV_MESSAGE_IMAGE_FULL_RES_CMD:
          {
            //buf.Format(_T("MESSAGE_IMAGE_FULL_RES_CMD (%8.8X)\r\n"), ui32L);
            //text += buf;
          }
          break;

          case MSILV_MESSAGE_CODE_QUALITY_CMD:
          {
            //buf.Format(_T("MESSAGE_CODE_QUALITY_CMD (%8.8X)\r\n"), ui32L);
            //text += buf;
          }
          break;

          case MSILV_MESSAGE_DETECT_QUALITY_CMD:
          {
            //buf.Format(_T("MESSAGE_DETECT_QUALITY_CMD (%8.8X)\r\n"), ui32L);
            //text += buf;
          }
          break;

          default:
          {
            ui32Parsed = ui32Total;
          }
          break;
        }

        //
        // we've now parsed another I (1 byte), L (ui8LenLen bytes) and V
        // (ui32ThisLen bytes).  add that to the 'parsed' count and advance to
        // next message.
        //
        ui32Parsed += (1 + ui8LenLen + ui32ThisLen);
        pui8V += ui32ThisLen;
      }
    }
    break;

    case MSILV_VERIFY:
    {
#if 0
      UINT32 ui32Parsed=0, ui32Total=0;
      UINT8 ui8RequestStatus=0, ui8MatchingResult=0;
      buf.Format(_T("VERIFY (%8.8X)\r\n"), ui32L);
      text += buf;

      //
      // save off total length of this message so we can parse internal ILVs
      //
      ui32Total = ui32L;

      //
      // first byte of VERIFY reply is request status
      //
      ui8RequestStatus = *pui8V++;
      buf.Format(_T("REQUEST STATUS %2.2X\r\n"), ui8RequestStatus);
      text += buf;
      ui32Parsed = 1;
      int TODO__CHECK_STATUS_BEFORE_PARSING_MORE;

      //
      // next byte of VERIFY reply is matching result
      //
      ui8MatchingResult = *pui8V++;
      switch(ui8MatchingResult)
      {
        case MSILV_ILVSTS_HIT:
        {
          buf.Format(_T("M/R ILVSTS_HIT\r\n"));
        }
        break;

        case MSILV_ILVSTS_NO_HIT:
        {
          buf.Format(_T("M/R ILVSTS_NO_HIT\r\n"));
        }
        break;

        case MSILV_ILVSTS_DB_EMPTY:
        {
          buf.Format(_T("M/R ILVSTS_DB_EMPTY\r\n"));
        }
        break;

        case MSILV_ILVSTS_FFD:
        {
          buf.Format(_T("M/R ILVSTS_FFD\r\n"));
        }
        break;

        case MSILV_ILVSTS_MOIST_FINGER:
        {
          buf.Format(_T("M/R ILVSTS_MOIST_FINGER\r\n"));
        }
        break;

        default:
        {
          buf.Format(_T("M/R %2.2X (?)\r\n"), ui8MatchingResult);
        }
        break;
      }
      text += buf;
      ui32Parsed = 2;

      //
      // now there are some ILV messages next which we extract one by one
      //
      while(ui32Parsed < ui32Total)
      {
        //
        // extract next message - pui8V points to V section, don't
        // change ui32L because we use it below the 'switch'.
        //
        pui8V = MorphoSmartILVExtract(pui8V, &ui8I, &ui32L, &ui8LenLen);

        //
        // processing depends on message type
        //
        switch(ui8I)
        {
          default:
          {
            buf.Format(_T("I=%2.2X L=%8.8X\r\n"), ui8I, ui32L);
            text += buf;
          }
          break;
        }

        //
        // have now parsed I + L (2 or 4) + ui32L, advance pointer past V
        //
        ui32Parsed += (1 + ui8LenLen + ui32L);
        pui8V += ui32L;
      }
#endif
    }
    break;

    case MSILV_ENROLL:
    {
      UINT32 ui32Parsed=0, ui32Total=0;
      UINT8 ui8RequestStatus=0, ui8EnrollStatus=0;
      sprintf(g_pcLogFileBuffer, " ENROLL (%8.8X)\r\n", ui32L);
      LogMessage(g_pcLogFileBuffer);

      //
      // save off total length of this message so we can parse internal ILVs
      //
      ui32Total = ui32L;

      //
      // first byte of ENROLL reply is request status
      //
      ui8RequestStatus = *pui8V++;
      sprintf(g_pcLogFileBuffer, " REQUEST STATUS %2.2X\r\n", ui8RequestStatus);
      LogMessage(g_pcLogFileBuffer);
      ui32Parsed = 1;

      //
      // if the request came back OK, there is an enroll status next
      //
      if(ui8RequestStatus == MSILV_ILV_OK)
      {
        ui8EnrollStatus = *pui8V++;
        sprintf(g_pcLogFileBuffer, " ENROLL STATUS %2.2X\r\n", ui8EnrollStatus);
        LogMessage(g_pcLogFileBuffer);
        ui32Parsed++;
      }

      //
      // now, if the two statuses are both OK (*or* if the first failed,
      // contrary to the documentation) there is a 4 byte index next.
      //
      if(((ui8RequestStatus == MSILV_ILV_OK) && (ui8EnrollStatus == MSILV_ILVSTS_OK)) ||
         (ui8RequestStatus != MSILV_ILV_OK))
      {
        sprintf(g_pcLogFileBuffer, " IDX %2.2X%2.2X%2.2X%2.2X\r\n", pui8V[3], pui8V[2], pui8V[1], pui8V[0]);
        LogMessage(g_pcLogFileBuffer);
        ui32Parsed += 4;
        pui8V += 4;
      }

      //
      // now there are some ILV messages next which we extract one by one
      //
      while(ui32Parsed < ui32Total)
      {
        //
        // extract next message - pui8V points to V section, don't
        // change ui32L because we use it below the 'switch'.
        //
        pui8V = MorphoSmartILVExtract(pui8V, &ui8I, &ui32L, &ui8LenLen);

        //
        // processing depends on message type
        //
        switch(ui8I)
        {
          case MSILV_ID_PK_COMP:
          {
            sprintf(g_pcLogFileBuffer, " ID_PK_COMP (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            //SaveMinutiae(ui8I, pui8V, ui32L, FALSE);
          }
          break;

          case MSILV_ID_PK_MAT:
          {
            sprintf(g_pcLogFileBuffer, " ID_PK_MAT (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            //SaveMinutiae(ui8I, pui8V, ui32L, FALSE);
          }
          break;

          case MSILV_ID_PK_COMP_NORM:
          {
            sprintf(g_pcLogFileBuffer, " ID_PK_COMP_NORM (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            //SaveMinutiae(ui8I, pui8V, ui32L, FALSE);
          }
          break;

          case MSILV_ID_PK_MAT_NORM:
          {
            sprintf(g_pcLogFileBuffer, " ID_PK_MAT_NORM (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            //SaveMinutiae(ui8I, pui8V, ui32L, FALSE);
          }
          break;

          case MSILV_ID_ISO_PK_DATA_ANSI_378:
          {
            sprintf(g_pcLogFileBuffer, " ID_ISO_PK_DATA_ANSI_378 (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            //SaveMinutiae(ui8I, pui8V, ui32L, TRUE);
          }
          break;

          case MSILV_ID_ISO_PK_DATA_MINEX_A:
          {
            sprintf(g_pcLogFileBuffer, " ID_ISO_PK_DATA_MINEX_A (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            //SaveMinutiae(ui8I, pui8V, ui32L, TRUE);
          }
          break;

          case MSILV_ID_ISO_PK_DATA_ISO_FMR:
          {
            sprintf(g_pcLogFileBuffer, " ID_ISO_PK_DATA_ISO_FMR (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            //SaveMinutiae(ui8I, pui8V, ui32L, TRUE);
          }
          break;

          case MSILV_ID_ISO_PK_DATA_ISO_FMC_NS:
          {
            sprintf(g_pcLogFileBuffer, " ID_ISO_PK_DATA_ISO_FMC_NS (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            //SaveMinutiae(ui8I, pui8V, ui32L, TRUE);
          }
          break;

          case MSILV_ID_ISO_PK_DATA_ISO_FMC_CS:
          {
            sprintf(g_pcLogFileBuffer, " ID_ISO_PK_DATA_ISO_FMC_CS (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            //SaveMinutiae(ui8I, pui8V, ui32L, TRUE);
          }
          break;

          case MSILV_ID_EXPORT_IMAGE:
          {
            int iError=0;
            sprintf(g_pcLogFileBuffer, " MSILV_ID_EXPORT_IMAGE (%8.8X)\r\n", ui32L);
            LogMessage(g_pcLogFileBuffer);
            iError = HandleMorphoImage(ui8I, ui32L, pui8V);
            if(iError == MORPHO_OK)
            {
              sprintf(g_pcLogFileBuffer, " IMAGE OK\r\n");
            }
            else
            {
              sprintf(g_pcLogFileBuffer, " IMAGE ERR %d\r\n", iError);
            }
            LogMessage(g_pcLogFileBuffer);
          }
          break;

          default:
          {
            sprintf(g_pcLogFileBuffer, "I=%2.2X L=%8.8X\r\n", ui8I, ui32L);
            LogMessage(g_pcLogFileBuffer);
          }
          break;
        }

        //
        // have now parsed I + L (2 or 4) + ui32L, advance pointer past V
        //
        ui32Parsed += (1 + ui8LenLen + ui32L);
        pui8V += ui32L;
      }
      bLast = TRUE;
    }
    break;

    default:
    break;
  }

  return bLast;
}

//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn Enrole_DlgProc(HWND	hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
/// \brief Enroll dialog box window procedure.
/// \param hDlg
/// \param uMsg
/// \param wParam
/// \param lParam
/// \return BOOL as per Windows specification.
//
////////////////////////////////////////////////////////////////////////////////
//
BOOL CALLBACK Enrole_DlgProc(
	HWND	hDlg,
	UINT	uMsg,
	WPARAM	wParam,
	LPARAM	lParam )
{
	switch( uMsg )
	{
		case WM_INITDIALOG:
		{
			SHINITDLGINFO shidi;
			shidi.dwMask = SHIDIM_FLAGS;
			shidi.dwFlags = SHIDIF_SIZEDLGFULLSCREEN;
			shidi.hDlg = hDlg;
			SHInitDialog(&shidi);
			SetForegroundWindow( hDlg );

			SHSetNavBarText( hDlg, TEXT("Password") );

			//
			// Enable the additional elements for updating the password.
			//
			if ( !GetPasswordActive() )
			{
				//
				// If no password is active, turn off Dissable button and old password
				//
				EnableWindow(GetDlgItem(hDlg,IDC_DISSABLE), FALSE);
				EnableWindow(GetDlgItem(hDlg,IDC_PASSWORDSTRINGOLD), FALSE);

				SetDlgItemText(hDlg,IDC_ENABLE,L"Enable");
				EnableWindow(GetDlgItem(hDlg,IDC_ENABLE), TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_PASSWORDSTRINGNEW), TRUE);
				SetDlgItemText(hDlg,IDC_PASSWORDSTRINGOLD,L"");
				SetDlgItemText(hDlg,IDC_PASSWORDSTRINGNEW,L"");
				SetFocus(GetDlgItem(hDlg,IDC_PASSWORDSTRINGNEW));
			}
			else
			{
				//
				// Password is active - allow dissable button and accept old password
				//
				SetDlgItemText(hDlg,IDC_ENABLE,L"Change");
				EnableWindow(GetDlgItem(hDlg,IDC_DISSABLE), TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_ENABLE), TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_PASSWORDSTRINGOLD), TRUE);
				EnableWindow(GetDlgItem(hDlg,IDC_PASSWORDSTRINGNEW), TRUE);
				SetDlgItemText(hDlg,IDC_PASSWORDSTRINGOLD,L"");
				SetDlgItemText(hDlg,IDC_PASSWORDSTRINGNEW,L"");
				SetFocus(GetDlgItem(hDlg,IDC_PASSWORDSTRINGOLD));
			}
		}
			return FALSE;

		case WM_CLOSE:
			EndDialog( hDlg, 0 );
			return FALSE;

		case WM_COMMAND:
			switch( LOWORD(wParam) )
			{
				case IDC_ENABLE:
					{
						// Get the old and new password values
						wchar_t OldPwd[MAX_PATH];
						wchar_t NewPwd[MAX_PATH];
						GetDlgItemText(hDlg,IDC_PASSWORDSTRINGOLD,OldPwd,MAX_PATH);
						GetDlgItemText(hDlg,IDC_PASSWORDSTRINGNEW,NewPwd,MAX_PATH);

						// Is a password active? Check with OS
						if (GetPasswordActive())
						{
							// Now check the old password is OK with the system
							if (CheckPassword(OldPwd))
							{
								// Change password values
								if (!SetPassword( OldPwd,  NewPwd))
								{
									MessageBox(hDlg, L"Failed to change the password, unknown error", L"Error",MB_OK);
								}
								else
								{
									HKEY hkey;
									//
									// Enable power-on dialog.
									//
									RegCreateKeyEx( HKEY_CURRENT_USER, TEXT("ControlPanel\\Owner"), 0, 0, 0, 0, 0, &hkey, 0 );
									RegSetValueEx( hkey, TEXT("PowrPass"), 0, REG_BINARY, (CONST BYTE*)"\x01", 1 );
									RegCloseKey( hkey );
								}
								EndDialog( hDlg, 1 );
							}
							else
							{
								MessageBox(hDlg,L"Invalid Password - please enter Old Password",L"Error",MB_OK|MB_ICONHAND);
							}
						}
						else
						{
							// Enable for the first time - set OS password to new value
							if (!SetPassword( NULL, NewPwd))
								MessageBox(hDlg, L"Failed to set the password, unknown error", L"Error",MB_OK);
							else
								if (!SetPasswordActive( TRUE,  NewPwd )) // Now make it active
									MessageBox(hDlg, L"Failed to activate password, unknown error", L"Error",MB_OK);
								else
									{
										HKEY hkey;
										//
										// Enable power-on dialog.
										//
										RegCreateKeyEx( HKEY_CURRENT_USER, TEXT("ControlPanel\\Owner"), 0, 0, 0, 0, 0, &hkey, 0 );
										RegSetValueEx( hkey, TEXT("PowrPass"), 0, REG_BINARY, (CONST BYTE*)"\x01", 1 );
										RegCloseKey( hkey );
									}
							EndDialog( hDlg, 1 );
						}
					}
					break;

				case IDC_DISSABLE:
					{
						// Check the OLD password value and dissable the security
						wchar_t ItemText[MAX_PATH];
						GetDlgItemText(hDlg,IDC_PASSWORDSTRINGOLD,ItemText,MAX_PATH);

						// Check the OLD password is correct
						if (CheckPassword(ItemText))
						{
							// Turn it off
							if (!SetPasswordActive(FALSE,ItemText))
								MessageBox(hDlg, L"Failed to deactivate password, unknown error", L"Error",MB_OK);
							else
								if (!SetPassword(ItemText,NULL))	// Change pwd value to null
									MessageBox(hDlg, L"Failed to clear the password, unknown error", L"Error",MB_OK);
								else
								{
									HKEY hkey;
									//
									// Dissable power-on dialog.
									//
									if (ERROR_SUCCESS!=RegCreateKeyEx( HKEY_CURRENT_USER, TEXT("ControlPanel\\Owner"), 0, 0, 0, 0, 0, &hkey, 0 ))
										MessageBox(hDlg,L"Failed to open the Owner key",L"Error",MB_OK);

									if (ERROR_SUCCESS!=RegSetValueEx( hkey, TEXT("PowrPass"), 0, REG_BINARY, (CONST BYTE*)"\x00", 1 ))
										MessageBox(hDlg,L"Failed to clear Owner value",L"Error",MB_OK);

									RegCloseKey( hkey );
								}

							EndDialog( hDlg, 1 );
						}
						else
						{
							MessageBox(hDlg,L"XXInvalid Password - please enter Old Password",L"Error",MB_OK|MB_ICONHAND);
						}
					}
					break;
			}
			break;
	}

	return FALSE;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn Verify_DlgProc(HWND	hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
/// \brief Verify dialog box window procedure.
/// \param hDlg
/// \param uMsg
/// \param wParam
/// \param lParam
/// \return BOOL as per Windows specification.
//
////////////////////////////////////////////////////////////////////////////////
//
BOOL CALLBACK Verify_DlgProc(
	HWND	hDlg,
	UINT	uMsg,
	WPARAM	wParam,
	LPARAM	lParam )
{
  //sprintf(g_pcLogFileBuffer, "Verify_DlgProc+ (%8.8X %8.8X)\r\n", hDlg, uMsg);
  //LogMessage(g_pcLogFileBuffer);

  switch( uMsg )
	{
    case WM_MSR_MESSAGE:
    {
      //sprintf(g_pcLogFileBuffer, " WM_MSR_MESSAGE %8.8X %8.8X\r\n", wParam, lParam);
      //LogMessage(g_pcLogFileBuffer);

      //
      // parameters passed to us are pointer to serial port which received
      // this message and also a pointer to the message object itself.  we
      // are responsible for 'deleting' the message when done with it.
      //
      MDPMessage *psMsg = (MDPMessage *)lParam;
      OnMSRMessage(psMsg);

      //sprintf(g_pcLogFileBuffer, " MDP %2.2X %2.2X %2.2X", MDP_PMESSAGE_SYNC(psMsg), MDP_PMESSAGE_PORT(psMsg), MDP_PMESSAGE_DATA_LENGTH(psMsg));
      //LogMessage(g_pcLogFileBuffer);
      //if(psMsg->m_ui8DataLength > 0)
      //{
      //  for(UINT8 ui8Index=0; ui8Index<psMsg->m_ui8DataLength; ui8Index++)
      //  {
      //    sprintf(g_pcLogFileBuffer, " %2.2X", MDP_PMESSAGE_DATA_BYTE(psMsg, ui8Index));
      //    LogMessage(g_pcLogFileBuffer);
      //  }
      //  sprintf(g_pcLogFileBuffer, "\r\n");
      //  LogMessage(g_pcLogFileBuffer);
      //}

      //
      // these messages are new'd from the serial port read thread callback
      // and then sent to us through the message queue; we need to delete
      // them here or else we'll leak memory.
      //
      delete psMsg;
    }
    break;

    case WM_FPR_MESSAGE:
    {
      BOOL bLast=FALSE;
      sprintf(g_pcLogFileBuffer, " WM_FPR_MESSAGE %8.8X %8.8X\r\n", wParam, lParam);
      LogMessage(g_pcLogFileBuffer);

      //
      // parameters passed to us are pointer to serial port which received
      // this message and also a pointer to the message object itself.  we
      // are responsible for 'deleting' the message when done with it.
      //
      MorphoSmartUSBMessage *psMsg = (MorphoSmartUSBMessage *)lParam;
      sprintf(g_pcLogFileBuffer, " [0] = %2.2X", psMsg->m_pui8ILV[0]);
      LogMessage(g_pcLogFileBuffer);
      //for(UINT32 ui32Index=1; ui32Index<psMsg->m_ui32ILVLength; ui32Index++)
      //{
      //  sprintf(g_pcLogFileBuffer, " %2.2X", psMsg->m_pui8ILV[ui32Index]);
      //  LogMessage(g_pcLogFileBuffer);
      //}
      //sprintf(g_pcLogFileBuffer, "\r\n");
      //LogMessage(g_pcLogFileBuffer);
      bLast = OnFPRMessage(psMsg);
      delete psMsg;
      if(bLast)
      {
        sprintf(g_pcLogFileBuffer, " found last FPR\r\n");
        LogMessage(g_pcLogFileBuffer);
        g_cn3piv.FPRClose();
        g_cn3piv.MSRSendPowerSet(false, false, true);
        g_cn3piv.MSRClose();
        g_hActiveDialog = 0;
        FreeVerifyMemory();
        EndDialog(hDlg, true);
      }
    }
    break;

    case WM_MSR_READ_THREAD_ERROR:
    {
      sprintf(g_pcLogFileBuffer, " WM_MSR_READ_THREAD_ERROR %8.8X %8.8X\r\n", wParam, lParam);
      LogMessage(g_pcLogFileBuffer);
    }
    break;

    case WM_FPR_READ_THREAD_ERROR:
    {
      sprintf(g_pcLogFileBuffer, " WM_FPR_READ_THREAD_ERROR %8.8X %8.8X\r\n", wParam, lParam);
      LogMessage(g_pcLogFileBuffer);
    }
    break;

    case WM_INITDIALOG:
		{
      BOOL b;
			SHINITDLGINFO shidi;
      sprintf(g_pcLogFileBuffer, " WM_INITDIALOG\r\n");
      LogMessage(g_pcLogFileBuffer);
			shidi.dwMask = SHIDIM_FLAGS;
			shidi.dwFlags = SHIDIF_SIZEDLGFULLSCREEN;
			shidi.hDlg = hDlg;
			b = SHInitDialog(&shidi);
      sprintf(g_pcLogFileBuffer, " SHInitDialog returns %d\r\n", (int)b);
      LogMessage(g_pcLogFileBuffer);
      DWORD dwExStyle = GetWindowLong( hDlg, GWL_EXSTYLE ); 
      dwExStyle |= WS_EX_ABOVESTARTUP; 
      SetWindowLong( hDlg, GWL_EXSTYLE, dwExStyle ); 
      b = SetForegroundWindow( ((HWND)((DWORD)hDlg | 0x01)) );
      sprintf(g_pcLogFileBuffer, " SetForegroundWindow returns %d\r\n", (int)b);
      LogMessage(g_pcLogFileBuffer);
#if ( WIN32_PLATFORM_PSPC >= 310 )
			{
				//
				// Don't show "X" button on Pocket PC 2002 and later
				//
				DWORD dwStyle = GetWindowLong( hDlg, GWL_STYLE );
				dwStyle |= WS_NONAVDONEBUTTON;
				SetWindowLong( hDlg, GWL_STYLE, dwStyle );
			}
#endif
			SHSetNavBarText( hDlg, TEXT("Password") );
      g_hActiveDialog = hDlg;
    }
		return FALSE;

    case WM_PAINT:
    {
      sprintf(g_pcLogFileBuffer, "WM_PAINT\r\n");
      LogMessage(g_pcLogFileBuffer);

      //{
      //  PAINTSTRUCT paint;
      //  HDC hDC = (HDC)wParam;
      //  BeginPaint(g_hActiveDialog, &paint);
      //  EndPaint(g_hActiveDialog, &paint);
      //  ReleaseDC(g_hImage, hDC);
      //}

      //{
      //  DefWindowProc(hDlg, WM_PAINT, wParam, lParam);
      //}
    }
    break;

		case WM_CLOSE:
      sprintf(g_pcLogFileBuffer, "WM_CLOSE\r\n");
      LogMessage(g_pcLogFileBuffer);
      g_hActiveDialog = 0;
      FreeVerifyMemory();
			EndDialog( hDlg, 0 );
			return FALSE;

		case WM_COMMAND:
      sprintf(g_pcLogFileBuffer, "WM_COMMAND\r\n");
      LogMessage(g_pcLogFileBuffer);
			switch( LOWORD(wParam) )
			{
				case IDC_LETMEIN:
					{
						// Check the password value and return appropriately
						wchar_t ItemText[MAX_PATH];
						GetDlgItemText(hDlg,IDC_PASSWORD,ItemText,MAX_PATH);
            g_hActiveDialog = 0;
            FreeVerifyMemory();
						EndDialog( hDlg, CheckPassword(ItemText));
					}
					break;

        case IDC_SKIP:
        {
          g_hActiveDialog = 0;
          FreeVerifyMemory();
          EndDialog(hDlg, true);
        }
        break;

        case IDC_VERIFY:
        {
          int iError=0;
          iError = g_cn3piv.MSROpen();
          if(iError == CN3PIV_ERROR_NONE)
          {
            int WARNING__WHY_ARE_THESE_NECESSARY;
            g_cn3piv.MSRSendPing();
            g_cn3piv.MSRSendPing();
            g_cn3piv.MSRSendPing();
            g_cn3piv.MSRSendPowerSet(true, false, true);
            int iCount=0;
            do
            {
              Sleep(250);
              iCount++;
              iError = g_cn3piv.FPROpen();
            } while((iCount < 20) && (!g_cn3piv.FPRIsOpen()));
            if(g_cn3piv.FPRIsOpen())
            {
              AllocateVerifyMemory();
              g_cn3piv.FPRSendGetDescriptor(MSILV_ID_FORMAT_BIN_VERSION);
              g_cn3piv.FPRSendStartGrab();
            }
            else
            {
              MessageBox(hDlg, L"Error opening FPR", L"Error", MB_OK);
            }
          }
          else
          {
            MessageBox(hDlg, L"Error opening MSR", L"Error", MB_OK);
          }
        }
        break;
			}
			break;
	}
	return FALSE;
}
