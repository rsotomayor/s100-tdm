//
////////////////////////////////////////////////////////////////////////////////
//
/// \file CN3PIVLAP.h
/// \brief Header file for CN3PIVLAP.dll.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009, Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//

// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the CN3PIVLAP_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// CN3PIVLAP_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef CN3PIVLAP_EXPORTS
#define CN3PIVLAP_API __declspec(dllexport)
#else
#define CN3PIVLAP_API __declspec(dllimport)
#endif
