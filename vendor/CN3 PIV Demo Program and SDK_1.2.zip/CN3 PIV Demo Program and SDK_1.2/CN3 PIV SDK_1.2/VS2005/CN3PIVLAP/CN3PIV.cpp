//
////////////////////////////////////////////////////////////////////////////////
//
/// \file CN3PIV.cpp
/// \brief Implementation file for the CCN3PIV object.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009, Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//
#include <stdafx.h>
#include <winreg.h>
#include "CN3PIV.h"


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::CCN3PIV()
/// \brief Default contstrutor.
//
////////////////////////////////////////////////////////////////////////////////
//
CCN3PIV::CCN3PIV()
{
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::~CCN3PIV()
/// \brief Default destructor.
//
////////////////////////////////////////////////////////////////////////////////
//
CCN3PIV::~CCN3PIV()
{
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::GetMSRPortNum()
/// \brief Used to retrieve MSR COM port number.
/// \return Port number - '1' for COM1, '2' for COM2, etc.
//
////////////////////////////////////////////////////////////////////////////////
//
UINT CCN3PIV::GetMSRPortNum()
{
  return m_oMSRPort.GetPortNum();
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::GetFPRPortNum()
/// \brief Used to retrieve FPR COM port number.
/// \return Port number - '1' for COM1, '2' for COM2, etc.
//
////////////////////////////////////////////////////////////////////////////////
//
UINT CCN3PIV::GetFPRPortNum()
{
  return m_oFPRPort.GetPortNum();
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::SetMSRMessageCallback(void (*pCallback)(CMDPSerialPort *pPort, MDPMessage *psMessage))
/// \brief Used to set callback function invoked when MSR message is received.
/// \param pCallback Pointer to callback function.
/// \remarks Note that the callback function will be called in the underlying
///  serial port read thread.  Caller should ensure threadsafe operation.
//
////////////////////////////////////////////////////////////////////////////////
//
void CCN3PIV::SetMSRMessageCallback(void (*pCallback)(CMDPSerialPort *pPort, MDPMessage *psMessage))
{
  m_oMSRPort.SetMDPMessageCallback(pCallback);
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::SetMSRReadErrorCallback(void (*pCallback)(CSerialPort *pPort, DWORD dwError))
/// \brief Used to set callback function invoked when MSR error is received.
/// \param pCallback Pointer to callback function.
/// \remarks Note that the callback function will be called in the underlying
///  serial port read thread.  Caller should ensure threadsafe operation.
//
////////////////////////////////////////////////////////////////////////////////
//
void CCN3PIV::SetMSRReadErrorCallback(void (*pCallback)(CSerialPort *pPort, DWORD dwError))
{
  m_oMSRPort.SetReadErrorCallback(pCallback);
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::SetFPRMessageCallback(void (*pCallback)(CMorphoSmartUSBSerialPort *pPort, MorphoSmartUSBMessage *psMessage))
/// \brief Used to set callback function invoked when FPR message is received.
/// \param pCallback Pointer to callback function.
/// \remarks Note that the callback function will be called in the underlying
///  serial port read thread.  Caller should ensure threadsafe operation.
//
////////////////////////////////////////////////////////////////////////////////
//
void CCN3PIV::SetFPRMessageCallback(void (*pCallback)(CMorphoSmartUSBSerialPort *pPort, MorphoSmartUSBMessage *psMessage))
{
  m_oFPRPort.SetILVMessageCallback(pCallback);
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::SetFPRReadErrorCallback(void (*pCallback)(CSerialPort *pPort, DWORD dwError))
/// \brief Used to set callback function invoked when FPR error is received.
/// \param pCallback Pointer to callback function.
/// \remarks Note that the callback function will be called in the underlying
///  serial port read thread.  Caller should ensure threadsafe operation.
//
////////////////////////////////////////////////////////////////////////////////
//
void CCN3PIV::SetFPRReadErrorCallback(void (*pCallback)(CSerialPort *pPort, DWORD dwError))
{
  m_oFPRPort.SetReadErrorCallback(pCallback);
}


char pcName[1024];
char pcFullName[1024];
char pcValue[1024];
WCHAR pwcName[1024];
WCHAR pwcFullName[1024];
WCHAR pwcValue[1024];
BOOL CCN3PIV::FindMSR()
{
  DWORD dwVarType=REG_DWORD;
  DWORD dwBuffSize=4;
  DWORD dwNameSize=1024;
  int iVal=0;
  HKEY hKey=NULL, hSubKey=NULL;
  BOOL bFound=FALSE;
  DWORD dwIndex=0;

  //sprintf(g_pcLogFileBuffer, "CCN3PIV::FindMSR\r\n");
  //LogMessage(g_pcLogFileBuffer);

  if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("Drivers\\Active\0"), 0, KEY_READ | KEY_ENUMERATE_SUB_KEYS, &hKey) == ERROR_SUCCESS)
  {
    //sprintf(g_pcLogFileBuffer, " opened Drivers\\Active\r\n");
    //LogMessage(g_pcLogFileBuffer);

    while(!bFound)
    {
      dwNameSize = 1024;
      if(RegEnumKeyEx(hKey, dwIndex, pwcName, &dwNameSize, NULL, NULL, NULL, NULL) == ERROR_SUCCESS)
      {
        WideCharToMultiByte(CP_ACP, 0, pwcName, -1, pcName, 1024, NULL, NULL);
        //sprintf(g_pcLogFileBuffer, " opened subkey %s\r\n", pcName);
        //LogMessage(g_pcLogFileBuffer);

        wsprintf(pwcFullName, TEXT("Drivers\\Active\\%s"), pwcName);
        if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, pwcFullName, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS)
        {
          WideCharToMultiByte(CP_ACP, 0, pwcFullName, -1, pcFullName, 1024, NULL, NULL);
          //sprintf(g_pcLogFileBuffer, " opened subkey %s\r\n", pcFullName);
          //LogMessage(g_pcLogFileBuffer);

          dwNameSize = 1024;
          if(RegQueryValueEx(hSubKey, TEXT("Key\0"), NULL, NULL, (LPBYTE)pwcValue, &dwNameSize) == ERROR_SUCCESS)
          {
            WideCharToMultiByte(CP_ACP, 0, pwcValue, -1, pcValue, 1024, NULL, NULL);
            //sprintf(g_pcLogFileBuffer, " queried \"Key\", got %s\r\n", pcValue);
            //LogMessage(g_pcLogFileBuffer);

            if(wcscmp(pwcValue, TEXT("Drivers\\USB\\ClientDrivers\\USBCDC_Template_PIV_MSR\0")) == 0)
            {
              //sprintf(g_pcLogFileBuffer, " found MSR active driver\r\n");
              //LogMessage(g_pcLogFileBuffer);
              dwNameSize = 1024;
              if(RegQueryValueEx(hSubKey, TEXT("Name\0"), NULL, NULL, (LPBYTE)pwcValue, &dwNameSize) == ERROR_SUCCESS)
              {
                WideCharToMultiByte(CP_ACP, 0, pwcValue, -1, pcValue, 1024, NULL, NULL);
                //sprintf(g_pcLogFileBuffer, " queried \"Name\", got %s\r\n", pcValue);
                //LogMessage(g_pcLogFileBuffer);

                sscanf(&pcValue[3], "%d", &iVal);
                //sprintf(g_pcLogFileBuffer, " found MSR on COM%d\r\n", iVal);
                //LogMessage(g_pcLogFileBuffer);
                m_oMSRPort.SetPortNum(iVal);
                bFound = TRUE;
              }
            }
          }
          RegCloseKey(hSubKey);
        }

        dwIndex++;
      }
      else
      {
        //sprintf(g_pcLogFileBuffer, " RegEnumKeyEx failed, exiting\r\n");
        //LogMessage(g_pcLogFileBuffer);
        break;
      }
    }
    RegCloseKey(hKey);
  }

  return bFound;
}
BOOL CCN3PIV::FindFPR()
{
  DWORD dwVarType=REG_DWORD;
  DWORD dwBuffSize=4;
  DWORD dwNameSize=1024;
  int iVal=0;
  HKEY hKey=NULL, hSubKey=NULL;
  BOOL bFound=FALSE;
  DWORD dwIndex=0;

  //sprintf(g_pcLogFileBuffer, "CCN3PIV::FindFPR\r\n");
  //LogMessage(g_pcLogFileBuffer);

  if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("Drivers\\Active\0"), 0, KEY_READ | KEY_ENUMERATE_SUB_KEYS, &hKey) == ERROR_SUCCESS)
  {
    //sprintf(g_pcLogFileBuffer, " opened Drivers\\Active\r\n");
    //LogMessage(g_pcLogFileBuffer);

    while(!bFound)
    {
      dwNameSize = 1024;
      if(RegEnumKeyEx(hKey, dwIndex, pwcName, &dwNameSize, NULL, NULL, NULL, NULL) == ERROR_SUCCESS)
      {
        WideCharToMultiByte(CP_ACP, 0, pwcName, -1, pcName, 1024, NULL, NULL);
        //sprintf(g_pcLogFileBuffer, " opened subkey %s\r\n", pcName);
        //LogMessage(g_pcLogFileBuffer);

        wsprintf(pwcFullName, TEXT("Drivers\\Active\\%s"), pwcName);
        if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, pwcFullName, 0, KEY_READ, &hSubKey) == ERROR_SUCCESS)
        {
          WideCharToMultiByte(CP_ACP, 0, pwcFullName, -1, pcFullName, 1024, NULL, NULL);
          //sprintf(g_pcLogFileBuffer, " opened subkey %s\r\n", pcFullName);
          //LogMessage(g_pcLogFileBuffer);

          dwNameSize = 1024;
          if(RegQueryValueEx(hSubKey, TEXT("Key\0"), NULL, NULL, (LPBYTE)pwcValue, &dwNameSize) == ERROR_SUCCESS)
          {
            WideCharToMultiByte(CP_ACP, 0, pwcValue, -1, pcValue, 1024, NULL, NULL);
            //sprintf(g_pcLogFileBuffer, " queried \"Key\", got %s\r\n", pcValue);
            //LogMessage(g_pcLogFileBuffer);

            if(wcscmp(pwcValue, TEXT("Drivers\\USB\\ClientDrivers\\USBCDC_Template_PIV_FPR\0")) == 0)
            {
              //sprintf(g_pcLogFileBuffer, " found FPR active driver\r\n");
              //LogMessage(g_pcLogFileBuffer);
              dwNameSize = 1024;
              if(RegQueryValueEx(hSubKey, TEXT("Name\0"), NULL, NULL, (LPBYTE)pwcValue, &dwNameSize) == ERROR_SUCCESS)
              {
                WideCharToMultiByte(CP_ACP, 0, pwcValue, -1, pcValue, 1024, NULL, NULL);
                //sprintf(g_pcLogFileBuffer, " queried \"Name\", got %s\r\n", pcValue);
                //LogMessage(g_pcLogFileBuffer);

                sscanf(&pcValue[3], "%d", &iVal);
                //sprintf(g_pcLogFileBuffer, " found FPR on COM%d\r\n", iVal);
                //LogMessage(g_pcLogFileBuffer);
                m_oFPRPort.SetPortNum(iVal);
                bFound = TRUE;
              }
            }
          }
          RegCloseKey(hSubKey);
        }

        dwIndex++;
      }
      else
      {
        //sprintf(g_pcLogFileBuffer, " RegEnumKeyEx failed, exiting\r\n");
        //LogMessage(g_pcLogFileBuffer);
        break;
      }
    }
    RegCloseKey(hKey);
  }

  return bFound;
}

//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::MSROpen()
/// \brief Attempts to open MSR port.
/// \return Error code as per \ref CN3PIV.h.
//
////////////////////////////////////////////////////////////////////////////////
//
int CCN3PIV::MSROpen()
{
  int iError = CN3PIV_ERROR_UNKNOWN;

  if(MSRIsOpen())
  {
    m_oMSRPort.Close();
  }
  if(FindMSR())
  {
    iError = m_oMSRPort.Open();
    if(iError != CN3PIV_ERROR_NONE)
    {
      m_oMSRPort.Close();
    }
  }
  else
  {
    iError = CN3PIV_ERROR_FINDING_PORT;
  }

  return iError;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::MSRClose()
/// \brief Attempts to close MSR port.
/// \return Error code as per \ref CN3PIV.h.
//
////////////////////////////////////////////////////////////////////////////////
//
int CCN3PIV::MSRClose()
{
  int iError = CN3PIV_ERROR_UNKNOWN;

  if(MSRIsOpen())
  {
    iError = m_oMSRPort.Close();
  }
  else
  {
    iError = CN3PIV_ERROR_NOT_OPEN;
  }

  return iError;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::FPROpen()
/// \brief Attempts to open FPR port.
/// \return Error code as per \ref CN3PIV.h.
//
////////////////////////////////////////////////////////////////////////////////
//
int CCN3PIV::FPROpen()
{
  int iError = CN3PIV_ERROR_UNKNOWN;

  if(FPRIsOpen())
  {
    m_oFPRPort.Close();
  }
  if(FindFPR())
  {
    iError = m_oFPRPort.Open();
    if(iError != CN3PIV_ERROR_NONE)
    {
      m_oFPRPort.Close();
    }
  }
  else
  {
    iError = CN3PIV_ERROR_FINDING_PORT;
  }

  return iError;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::FPRClose()
/// \brief Attempts to close FPR port.
/// \return Error code as per \ref CN3PIV.h.
//
////////////////////////////////////////////////////////////////////////////////
//
int CCN3PIV::FPRClose()
{
  int iError = CN3PIV_ERROR_UNKNOWN;

  if(FPRIsOpen())
  {
    iError = m_oFPRPort.Close();
  }
  else
  {
    iError = CN3PIV_ERROR_NOT_OPEN;
  }

  return iError;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::MSRIsOpen()
/// \brief Test MSR port to see if it is open.
/// \return True if MSR port open, false otherwise.
//
////////////////////////////////////////////////////////////////////////////////
//
BOOL CCN3PIV::MSRIsOpen()
{
  return m_oMSRPort.IsOpen();
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::FPRIsOpen()
/// \brief Test FPR port to see if it is open.
/// \return True if FPR port open, false otherwise.
//
////////////////////////////////////////////////////////////////////////////////
//
BOOL CCN3PIV::FPRIsOpen()
{
  return m_oFPRPort.IsOpen();
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::MSRSendPing()
/// \brief Attempts to send a Ping message to the MSR.
/// \return Error code as per \ref CN3PIV.h.
/// \details If successful, MSR will receive message and respond.  MSR
///  message callback will be called with response.
//
////////////////////////////////////////////////////////////////////////////////
//
int CCN3PIV::MSRSendPing()
{
  int iError=CN3PIV_ERROR_UNKNOWN;

  //
  // just check to see if the port is open, then send the message
  //
  if(m_oMSRPort.IsOpen())
  {
    //
    // port is open, just send message and set no error
    //
    if(m_oMSRPort.WriteMDPMessage(CN3PIV_MSRPORT_PING) == SERIALPORT_ERROR_NONE)
    {
      iError = CN3PIV_ERROR_NONE;
    }
    else
    {
      iError = CN3PIV_ERROR_PORT;
    }
  }
  else
  {
    //
    // port is not open, set error code
    //
    iError = CN3PIV_ERROR_PORT;
  }

  //
  // return value is error code set above
  //
  return iError;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::MSRSendPowerSet(bool bFPOn, bool bCCOn, bool b5VOn)
/// \brief Attempts to send a Power Set message to the MSR.
/// \param bFPOn True to turn FPR on, false to turn it off.
/// \param bCCOn True to turn SCR on, false to turn it off.
/// \param b5VOn True to turn 5V on, false to turn it off.
/// \return Error code as per \ref CN3PIV.h.
/// \details If successful, MSR will receive message and respond.  MSR
///  message callback will be called with response.
/// \remarks Note that the FPR and SCR cannot be turned on simultaneously.  An
///  attempt to do this will result in an error code being returned.
//
////////////////////////////////////////////////////////////////////////////////
//
int CCN3PIV::MSRSendPowerSet(bool bFPOn, bool bCCOn, bool b5VOn)
{
  int iError=CN3PIV_ERROR_UNKNOWN;

  //
  // check to see if the port is open, then send the message
  //
  if(m_oMSRPort.IsOpen())
  {
    //
    // check parameters - both FP and CC should not be
    // turned on at the same time, so we check that here.
    //
    if(!(bFPOn && bCCOn))
    {
      //
      // we construct the message in an order such that the
      // things that are getting powered off are processed
      // first, to keep the power consumption down.
      //
      UINT8 msg[6];
      msg[0] = CN3PIV_POWERCONTROL_5V;
      msg[1] = b5VOn ? 0xFF : 0x00;
      if(bFPOn)
      {
        //
        // FP is going on, so do CC first (going off)
        //
        msg[2] = CN3PIV_POWERCONTROL_CC;
        msg[3] = bCCOn ? 0xFF : 0x00;
        msg[4] = CN3PIV_POWERCONTROL_FP;
        msg[5] = bFPOn ? 0xFF : 0x00;
      }
      else
      {
        //
        // FP is going off, so do it first
        //
        msg[2] = CN3PIV_POWERCONTROL_FP;
        msg[3] = bFPOn ? 0xFF : 0x00;
        msg[4] = CN3PIV_POWERCONTROL_CC;
        msg[5] = bCCOn ? 0xFF : 0x00;
      }

      //
      // now just write the message, return error
      // on any error from the 'write' call.
      //
      if(m_oMSRPort.WriteMDPMessage(CN3PIV_MSRPORT_POWER, msg, 6) == SERIALPORT_ERROR_NONE)
      {
        iError = CN3PIV_ERROR_NONE;
      }
      else
      {
        iError = CN3PIV_ERROR_PORT;
      }
    }
    else
    {
      //
      // some bad parameter, set error code
      //
      iError = CN3PIV_ERROR_BAD_PARAMETER;
    }
  }
  else
  {
    //
    // port is not open, set error code
    //
    iError = CN3PIV_ERROR_NOT_OPEN;
  }

  //
  // return value is error code set above
  //
  return iError;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::FPRSendGetDescriptor(UINT8 ui8Format)
/// \param ui8Format Format of descriptor requested.
/// \brief Attempts to send a Get Descriptor message to the FPR.
/// \return Error code as per \ref CN3PIV.h.
/// \details If successful, FPR will receive message and respond.  FPR
///  message callback will be called with response.
//
////////////////////////////////////////////////////////////////////////////////
//
int CCN3PIV::FPRSendGetDescriptor(UINT8 ui8Format)
{
  int iError=CN3PIV_ERROR_UNKNOWN;

  //
  // check to see if the port is open, then send the message
  //
  if(m_oFPRPort.IsOpen())
  {
    //
    // port is open, write message and set error code accordingly.
    //
    if(m_oFPRPort.WriteILVMessage(MSILV_GET_DESCRIPTOR, 1, &ui8Format) == SERIALPORT_ERROR_NONE)
    {
      iError = CN3PIV_ERROR_NONE;
    }
    else
    {
      iError = CN3PIV_ERROR_PORT;
    }
  }
  else
  {
    //
    // port is not open, set error code
    //
    iError = CN3PIV_ERROR_NOT_OPEN;
  }

  //
  // return value is error code set above
  //
  return iError;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn CCN3PIV::FPRSendStartGrab()
/// \brief Attempts to send an Enroll message to the FPR.
/// \return Error code as per \ref CN3PIV.h.
/// \details the Enroll message is used to grab a fingerprint image and return
///  it and its associated minutiae data.  If successful, FPR will receive
///  message, grab a fingerprint (or timeout) and respond.  FPR message callback
///  will be called with asynchronous messages and finally with response.
//
////////////////////////////////////////////////////////////////////////////////
//
int CCN3PIV::FPRSendStartGrab()
{
  int iError=CN3PIV_ERROR_UNKNOWN;

  //
  // check to see if the port is open, then send the message
  //
  if(m_oFPRPort.IsOpen())
  {
    UINT16 ui16Len=0;
    UINT8 pui8Msg[8 + 7 + 4 + 9];
    UINT8 ui8=0;

    //
    // required parameters
    //
    pui8Msg[0] = 0x00;                           // database identifier
    pui8Msg[1] = 10;                             // timeout lsb
    pui8Msg[2] = 0;                              // timeout msb
    pui8Msg[3] = 0x00;                           // acq qual thresh
    pui8Msg[4] = 1;                              // enrollment type 
    pui8Msg[5] = 1;                              // number of fingers
    pui8Msg[6] = 0x00;                           // save record (bool)
    pui8Msg[7] = 0x01;                           // export minutiae 
    ui16Len = 8;

    //
    // asynchronous event (optional)
    //
    pui8Msg[ui16Len++] = MSILV_ID_ASYNCHRONOUS_EVENT;
    pui8Msg[ui16Len++] = 0x04;
    pui8Msg[ui16Len++] = 0x00;
    pui8Msg[ui16Len++] = MSILV_MESSAGE_COMMAND_CMD | MSILV_MESSAGE_IMAGE_CMD;
    pui8Msg[ui16Len++] = 0;
    pui8Msg[ui16Len++] = 0;
    pui8Msg[ui16Len++] = 0;

    //
    // biomentric algorithm (optional)
    //
    pui8Msg[ui16Len++] = MSILV_ID_BIO_ALGO_PARAM;
    pui8Msg[ui16Len++] = 0x01;
    pui8Msg[ui16Len++] = 0x00;
    pui8Msg[ui16Len++] = 0;     // PK_COMP
    //pui8Msg[ui16Len++] = 1;   // PK_COMP_NORM
    //pui8Msg[ui16Len++] = 2;   // PK_MAT
    //pui8Msg[ui16Len++] = 3;   // PK_MAT_NORM
    //pui8Msg[ui16Len++] = 65;  // ANSI_378
    //pui8Msg[ui16Len++] = 108; // ISO_FMC_CS
    //pui8Msg[ui16Len++] = 109; // ISO_FMC_NS
    //pui8Msg[ui16Len++] = 110; // ISO_FMR
    //pui8Msg[ui16Len++] = 111; // MINEX_A

    //
    // export image (optional)
    //
    pui8Msg[ui16Len++] = MSILV_ID_EXPORT_IMAGE;
    pui8Msg[ui16Len++] = 0x06;
    pui8Msg[ui16Len++] = 0x00;
    pui8Msg[ui16Len++] = MSILV_ID_DEFAULT_IMAGE;
    pui8Msg[ui16Len++] = MSILV_ID_COMPRESSION;
    pui8Msg[ui16Len++] = 0x02;
    pui8Msg[ui16Len++] = 0x00;
    pui8Msg[ui16Len++] = MSILV_ID_COMPRESSION_NULL;
    pui8Msg[ui16Len++] = 0x00;

    //
    // write command and set error code
    //
    iError = m_oFPRPort.WriteILVMessage(MSILV_ENROLL, ui16Len, pui8Msg);
    if(iError == SERIALPORT_ERROR_NONE)
    {
      iError = CN3PIV_ERROR_NONE;
    }
    else
    {
      iError = CN3PIV_ERROR_PORT;
    }
  }
  else
  {
    //
    // port is not open, set error code
    //
    iError = CN3PIV_ERROR_NOT_OPEN;
  }

  //
  // return value is error code set above
  //
  return iError;
}
