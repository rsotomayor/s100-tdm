//
////////////////////////////////////////////////////////////////////////////////
//
/// \file MDP.cpp
/// \brief Implementation file for MDP message routines.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2008, Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//


//
////////////////////////////////////////////////////////////////////////////////
//
// Include files
//
////////////////////////////////////////////////////////////////////////////////
//
#include <stdafx.h>
#include "MDP.h"


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn MDPMessageInit(MDPMessage *pMessage)
/// \brief MPD message init function.
/// \param pMessage Pointer to MDP message structure to initialize.
//
////////////////////////////////////////////////////////////////////////////////
//
void MDPMessageInit(MDPMessage *pMessage)
{
  //
  // just set message state to 'waiting for sync'
  //
  pMessage->m_ui8State = MDP_STATE_SYNC;

  //
  // return is void - message struct init'd
  //
  return;
}


//
////////////////////////////////////////////////////////////////////////////////
//
/// \fn MDPMessageParse(MDPMessage * pMessage, UINT8 ui8Byte)
/// \brief Parses an MDP message based on internal state and byte stream.
/// \param pMessage Pointer to struct into which message will be parsed.
/// \param ui8Byte Next byte read from the byte stream.
/// \return Pointer to parsed message struct (pMessage) when MDP message is
///         parsed, NULL otherwise.
/// \remarks Assumes that MDPMessageInit() has been called to init message
///          struct before the first call.
//
////////////////////////////////////////////////////////////////////////////////
//
MDPMessage * MDPMessageParse(MDPMessage * pMessage, UINT8 ui8Byte)
{
  MDPMessage *pReturn=NULL;

  //
  // processing depends on state of message
  //
  switch(pMessage->m_ui8State)
  {
    //
    // waiting for sync byte
    //
    case MDP_STATE_SYNC:
      if(ui8Byte == MDP_SYNC_BYTE)
      {
        pMessage->m_pui8Message[MDP_INDEX_SYNC] = ui8Byte;
        pMessage->m_ui8State = MDP_STATE_PORT;
      }
      break;

    //
    // waiting for 'port' - message id
    //
    case MDP_STATE_PORT:
      pMessage->m_pui8Message[MDP_INDEX_PORT] = ui8Byte;
      pMessage->m_ui8State = MDP_STATE_LENGTH;
      break;

    //
    // waiting for message data length.  first check that the length
    // is <= MDP_MAX_DATA_LENGTH.  if it's >, go back to 'waiting
    // for sync' state.  otherwise if > 0, wait for payload, or
    // we're parsed, so return a pointer to the message.
    //
    case MDP_STATE_LENGTH:
#ifdef MDP_CHECK_MAX_DATA_LENGTH
      if(ui8Byte <= MDP_MAX_DATA_LENGTH)
      {
#endif
        pMessage->m_pui8Message[MDP_INDEX_LENGTH] = ui8Byte;
        pMessage->m_ui8DataLength = 0;
        if(ui8Byte > 0)
        {
          pMessage->m_ui8State = MDP_STATE_PAYLOAD;
        }
        else
        {
          pMessage->m_ui8State = MDP_STATE_SYNC;
          pReturn = pMessage;
        }
#ifdef MDP_CHECK_MAX_DATA_LENGTH
      }
      else
      {
        pMessage->m_ui8State = MDP_STATE_SYNC;
      }
#endif
      break;

    //
    // waiting for message data payload.  when we've read the entire
    // payload, return a pointer to the message.
    //
    case MDP_STATE_PAYLOAD:
      pMessage->m_pui8Message[MDP_INDEX_DATA + pMessage->m_ui8DataLength] = ui8Byte;
      pMessage->m_ui8DataLength++;
      if(pMessage->m_ui8DataLength == pMessage->m_pui8Message[MDP_INDEX_LENGTH])
      {
        pMessage->m_ui8State = MDP_STATE_SYNC;
        pReturn = pMessage;
      }
      break;

    //
    // unknown state - this should never happen, but if it
    // does, just reset the state machine
    //
    default:
      pMessage->m_ui8State = MDP_STATE_SYNC;
      break;
  }

  //
  // return value as set above is NULL unless message is parsed
  //
  return pReturn;
}
