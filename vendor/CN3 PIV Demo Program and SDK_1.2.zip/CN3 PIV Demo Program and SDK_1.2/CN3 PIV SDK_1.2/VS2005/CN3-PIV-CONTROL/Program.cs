//
////////////////////////////////////////////////////////////////////////////////
//
/// \file Program.cs
/// \brief Source file for PIVControlForm form.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009 Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace PIVControl
{
  static class Program
  {
    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [MTAThread]
    static void Main()
    {
      Application.Run(new PIVControlForm());
    }
  }
}