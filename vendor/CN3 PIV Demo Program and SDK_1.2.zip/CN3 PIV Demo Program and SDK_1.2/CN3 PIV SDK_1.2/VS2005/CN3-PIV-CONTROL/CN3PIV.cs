//
////////////////////////////////////////////////////////////////////////////////
//
/// \file CN3PIV.cs
/// \brief Implementation file for the CN3PIV API.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009 Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//
using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#region public class CN3PIV
/// <summary>
/// CN3PIV is an object which encapsulates the CN3 PIV snap-on hardware
/// and its associated data flows and interfaces.
/// </summary>
public class CN3PIV
{
  #region DLL Imports

#if false
  /// <summary>
  /// See \ref OKPWRCE.cpp::OKPWR_GetVersion in \ref OKPWRCE.cpp.
  /// </summary>
  [DllImport("okpwrce.dll")]
  static extern int OKPWR_GetVersion(ref int piVersion);

  /// <summary>
  /// See \ref OKPWRCE.cpp::OKPWR_OpenReader in \ref OKPWRCE.cpp.
  /// </summary>
  [DllImport("okpwrce.dll")]
  static extern bool OKPWR_OpenReader(string strReaderName, ref int hReader);

  /// <summary>
  /// See \ref OKPWRCE.cpp::OKPWR_CloseReader in \ref OKPWRCE.cpp.
  /// </summary>
  [DllImport("okpwrce.dll")]
  static extern bool OKPWR_CloseReader(int hReader);

  /// <summary>
  /// See \ref OKPWRCE.cpp::OKPWR_AntennaOff in \ref OKPWRCE.cpp.
  /// </summary>
  [DllImport("okpwrce.dll")]
  static extern bool OKPWR_AntennaOff(int hReader);

  /// <summary>
  /// See \ref OKPWRCE.cpp::OKPWR_AntennaOn in \ref OKPWRCE.cpp.
  /// </summary>
  [DllImport("okpwrce.dll")]
  static extern bool OKPWR_AntennaOn(int hReader);

  /// <summary>
  /// See \ref OKPWRCE.cpp::OKPWR_IdleOn in \ref OKPWRCE.cpp.
  /// </summary>
  [DllImport("okpwrce.dll")]
  static extern bool OKPWR_IdleOn(int hReader, byte uchLedMode);

  /// <summary>
  /// See \ref OKPWRCE.cpp::OKPWR_IdleOff in \ref OKPWRCE.cpp.
  /// </summary>
  [DllImport("okpwrce.dll")]
  static extern bool OKPWR_IdleOff(int hReader);

  /// <summary>
  /// See \ref OKPWRCE.cpp::OKPWR_ReaderOn in \ref OKPWRCE.cpp.
  /// </summary>
  [DllImport("okpwrce.dll")]
  static extern bool OKPWR_ReaderOn(int hReader);

  /// <summary>
  /// See \ref OKPWRCE.cpp::OKPWR_ReaderOff in \ref OKPWRCE.cpp.
  /// </summary>
  [DllImport("okpwrce.dll")]
  static extern bool OKPWR_ReaderOff(int hReader);
#endif

  /// <summary>
  /// See \ref WSQDLL.cpp::WSQ_GetVersion in \ref WSQDLL.cpp.
  /// </summary>
  [DllImport("wsq.dll")]
  static extern int WSQ_GetVersion(ref int piVersion);

  /// <summary>
  /// See \ref WSQDLL.cpp::WSQ_ConvertFromRaw in \ref WSQDLL.cpp.
  /// </summary>
  [DllImport("wsq.dll")]
  static extern int WSQ_ConvertFromRaw(IntPtr idata, int width, int height, int depth, int ppi, IntPtr odata, IntPtr olen);

  /// <summary>
  /// See \ref WSQDLL.cpp::WSQ_ConvertToRaw in \ref WSQDLL.cpp.
  /// </summary>
  [DllImport("wsq.dll")]
  static extern int WSQ_ConvertToRaw(IntPtr idata, int ilen, IntPtr width, IntPtr height, IntPtr depth, IntPtr ppi, IntPtr lossy, IntPtr odata, IntPtr olen);

  /// <summary>
  /// See http://msdn.microsoft.com/en-us/library/aa379479(VS.85).aspx.
  /// </summary>
  [DllImport("Winscard.dll")]
  public static extern int SCardEstablishContext(uint dwScope, int nNotUsed1, int nNotUsed2, ref int phContext);

  /// <summary>
  /// See http://msdn.microsoft.com/en-us/library/aa379793(VS.85).aspx.
  /// </summary>
  [DllImport("Winscard.dll")]
  public static extern int SCardListReaders(int hContext, string cGroups, byte[] mszReaders, out int pcchReaders);

  /// <summary>
  /// See http://msdn.microsoft.com/en-us/library/aa379473(VS.85).aspx.
  /// </summary>
  [DllImport("Winscard.dll")]
  public static extern int SCardConnect(int hContext, string szReader, uint dwShareMode, uint dwPreferredProtocols, ref int phCard, ref uint pdwActiveProtocol);

  /// <summary>
  /// See http://msdn.microsoft.com/en-us/library/aa379803(VS.85).aspx.
  /// </summary>
  [DllImport("Winscard.dll")]
  public static extern int SCardStatus(int hCard, string szReaderName, ref uint pcchReaderLen, ref uint pdwState, ref uint pdwProtocol, IntPtr pbAtr, ref uint pdwATRLength);

  /// <summary>
  /// See http://msdn.microsoft.com/en-us/library/aa379475(VS.85).aspx.
  /// </summary>
  [DllImport("Winscard.dll")]
  public static extern int SCardDisconnect(int hCard, uint dwDisposition);

  /// <summary>
  /// See http://msdn.microsoft.com/en-us/library/aa379798(VS.85).aspx.
  /// </summary>
  [DllImport("Winscard.dll")]
  public static extern int SCardReleaseContext(int hContext);

  #endregion

  #region Constants

  /// <summary>
  /// Size of BMP file header.
  /// </summary>
  public const uint BMPBaseHeaderSize=14;

  /// <summary>
  /// Size of BMP DIB header.
  /// </summary>
  public const uint BMPDIBHeaderSize=40;

  /// <summary>
  /// Size of grayscale palette we use for BMP files (4 bytes * 256 colors = 1024).
  /// </summary>
  public const uint BMPPaletteSize=1024;

  /// <summary>
  /// The context is a user context, and any database operations
  /// are performed within the domain of the user.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winscard.h".</remarks>
  public const uint SCARD_SCOPE_USER = 0;

  /// <summary>
  /// The context is that of the current terminal, and any database
  /// operations are performed within the domain of that terminal.
  /// (The calling application must have appropriate access permissions
  /// for any database actions.)
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winscard.h".</remarks>
  public const uint SCARD_SCOPE_TERMINAL = 1;

  /// <summary>
  /// The context is the system context, and any database operations
  /// are performed within the domain of the system.  (The calling
  /// application must have appropriate access permissions for any
  /// database actions.)
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winscard.h".</remarks>
  public const uint SCARD_SCOPE_SYSTEM = 2;

  /// <summary>
  /// This application is not willing to share this card with other
  /// applications.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winscard.h".</remarks>
  public const uint SCARD_SHARE_EXCLUSIVE = 1;

  /// <summary>
  /// This application is willing to share this card with other
  /// applications.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winscard.h".</remarks>
  public const uint SCARD_SHARE_SHARED = 2;

  /// <summary>
  /// This application demands direct control of the reader,
  /// so it is not available to other applications.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winscard.h".</remarks>
  public const uint SCARD_SHARE_DIRECT = 3;

  /// <summary>
  /// There is no active protocol.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winsmcrd.h".</remarks>
  public const uint SCARD_PROTOCOL_UNDEFINED = 0x00000000;

  /// <summary>
  /// T=0 is the active protocol.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winsmcrd.h".</remarks>
  public const uint SCARD_PROTOCOL_T0 = 0x00000001;

  /// <summary>
  /// T=1 is the active protocol.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winsmcrd.h".</remarks>
  public const uint SCARD_PROTOCOL_T1 = 0x00000002;

  /// <summary>
  /// Raw is the active protocol.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winsmcrd.h".</remarks>
  public const uint SCARD_PROTOCOL_RAW = 0x00010000;

  /// <summary>
  /// Don't do anything special on close
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winscard.h".</remarks>
  public const uint SCARD_LEAVE_CARD = 0;
  
  /// <summary>
  /// Reset the card on close
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winscard.h".</remarks>
  public const uint SCARD_RESET_CARD = 1;
  
  /// <summary>
  /// Power down the card on close
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winscard.h".</remarks>
  public const uint SCARD_UNPOWER_CARD = 2;

  /// <summary>
  /// Eject the card on close
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winscard.h".</remarks>
  public const uint SCARD_EJECT_CARD = 3;

  /// <summary>
  /// This value implies the driver is unaware of the current
  /// state of the reader.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winsmcrd.h".</remarks>
  public const uint SCARD_UNKNOWN = 0;

  /// <summary>
  /// This value implies there is no card in the reader.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winsmcrd.h".</remarks>
  public const uint SCARD_ABSENT = 1;

  /// <summary>
  /// This value implies there is a card is present in the reader, but
  /// that it has not been moved into position for use.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winsmcrd.h".</remarks>
  public const uint SCARD_PRESENT = 2;
  
  /// <summary>
  /// This value implies there is a card in the reader in position for
  /// use.  The card is not powered.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winsmcrd.h".</remarks>
  public const uint SCARD_SWALLOWED = 3;
  
  /// <summary>
  /// This value implies there is power is being provided to the card,
  /// but the Reader Driver is unaware of the mode of the card.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winsmcrd.h".</remarks>
  public const uint SCARD_POWERED = 4;
  
  /// <summary>
  /// This value implies the card has been reset and is awaiting
  /// PTS negotiation.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winsmcrd.h".</remarks>
  public const uint SCARD_NEGOTIABLE = 5;
  
  /// <summary>
  /// This value implies the card has been reset and specific communication
  /// protocols have been established.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winsmcrd.h".</remarks>
  public const uint SCARD_SPECIFIC = 6;
  
  /// <summary>
  /// Invalid handle value as defined in Windows API header files.
  /// </summary>
  /// <remarks>Taken from WM 5.0 header file "winbase.h".</remarks>
  const int INVALID_HANDLE_VALUE = -1;

  #region public enum Error
  /// <summary>
  /// Error codes returned from CN3PIV member functions.
  /// </summary>
  public enum Error
  {
    /// <summary>
    /// Unknown error.
    /// </summary>
    Unknown = -1,

    /// <summary>
    /// No error.
    /// </summary>
    None = 0,

    /// <summary>
    /// Required parameter is null.
    /// </summary>
    NullParameter,

    /// <summary>
    /// Length of parameter is inappropriate.
    /// </summary>
    LengthParameter,

    /// <summary>
    /// Parameter value is bad.
    /// </summary>
    BadParameter,

    /// <summary>
    /// Serial port is not open.
    /// </summary>
    NotOpen,

    /// <summary>
    /// Error with underlying serial port.
    /// </summary>
    Port,

    /// <summary>
    /// SCR already init'd.
    /// </summary>
    AlreadyInit,

    /// <summary>
    /// Error establishing context, or context already established.
    /// </summary>
    EstablishContext,

    /// <summary>
    /// Error listing readers, or readers need to be listed.
    /// </summary>
    ListReaders,

    /// <summary>
    /// No context has been established.
    /// </summary>
    NoContext,

    /// <summary>
    /// No readers available.
    /// </summary>
    NoReaders,

    /// <summary>
    /// Already connected to card.
    /// </summary>
    AlreadyConnected,

    /// <summary>
    /// Error connecting to card.
    /// </summary>
    Connect, 

    /// <summary>
    /// No card inserted.
    /// </summary>
    NoCard,

    /// <summary>
    /// Not connected to card.
    /// </summary>
    NotConnected,

    /// <summary>
    /// Error getting card status.
    /// </summary>
    CardStatus,

    /// <summary>
    /// Error disconnecting from card.
    /// </summary>
    Disconnect,

    /// <summary>
    /// Error releasing smartcard context.
    /// </summary>
    ReleaseContext,

    /// <summary>
    /// Error reading values from registry.
    /// </summary>
    Registry,
  }
  #endregion

  #region public enum MSRTrack
  /// <summary>
  /// Tracks of 3-track MSR card, One, Two and Three.
  /// </summary>
  public enum MSRTrack
  {
    /// <summary>
    /// Track 1
    /// </summary>
    One=1,

    /// <summary>
    /// Track 2
    /// </summary>
    Two=2,

    /// <summary>
    /// Track 3
    /// </summary>
    Three=3,
  }
  #endregion

  #region public enum PowerControl
  /// <summary>
  /// Values for controlling power in CN3 hardware.
  /// </summary>
  public enum PowerControl
  {
    /// <summary>
    /// Fingerprint sensor power control.
    /// </summary>
    FP = 0x01,

    /// <summary>
    /// Smartcard reader power control
    /// </summary>
    CC = 0x02,

    /// <summary>
    /// 5 volt boost converter power control.
    /// </summary>
    _5V = 0x03,
  }
  #endregion

  #region public enum MSRPort : byte
  /// <summary>
  /// Ports defined by MSR MDP message set.
  /// </summary>
  public enum MSRPort : byte
  {
    /// <summary>
    /// Ping port - MSR replies with f/w version and system info.
    /// </summary>
    Ping = 0x00,

    /// <summary>
    /// Data request port - MSR replies with last MSR swipe data.
    /// </summary>
    DataRequest = 0x01,

    /// <summary>
    /// Data clear port - MSR clears last MSR swipe data and echoes message.
    /// </summary>
    DataClear = 0x02,

    /// <summary>
    /// Power control port - MSR chip controls power for other stuff too.
    /// </summary>
    Power = 0x03,

    /// <summary>
    /// Power save port - MSR chip can save its power configuration as default.
    /// </summary>
    PowerSave = 0x04,

    /// <summary>
    /// MSR track one data/error port.
    /// </summary>
    Track1 = 0x61,

    /// <summary>
    /// MSR track two data/error port.
    /// </summary>
    Track2 = 0x62,

    /// <summary>
    /// MSR track three data/error port.
    /// </summary>
    Track3 = 0x63,

    /// <summary>
    /// MSR error message port.
    /// </summary>
    Error = 0xFF,
  }
  #endregion

  #endregion

  #region Members

  /// <summary>
  /// The form that owns this CN3PIV object.  This form's UI thread will
  /// be "Invoke()'d" for functions registered to the CN3PIV delegates.
  /// </summary>
  Form m_form;

  /// <summary>
  /// Resume notification object.  This is used to trap for power control
  /// 'resume' events which allow the owner to know that it's time to close
  /// the MSR and FPR interfaces as their corresponing serial ports have
  /// deenumerated and must be closed and reopened.
  /// </summary>
  ResumeNotifier m_resumeNotifier;

  /// <summary>
  /// Name of Sagem device serial port.
  /// </summary>
  string m_sagemPortName;

  /// <summary>
  /// Name of MSR device serial port.
  /// </summary>
  string m_msrPortName;

  /// <summary>
  /// Serial port over which communcation w/ Sagem MS device will happen.
  /// </summary>
  MSUSBSerialPort m_sagemPort;

  /// <summary>
  /// Serial port over which communcation w/ MSR will happen.
  /// </summary>
  MDPSerialPort m_msrPort;

  /// <summary>
  /// Handle to smart card context.
  /// </summary>
  int m_hContext=INVALID_HANDLE_VALUE;

  /// <summary>
  /// Array of names of card readers present in the system.
  /// </summary>
  string[] m_sReaders;

  /// <summary>
  /// Index of currently active reader.
  /// </summary>
  uint m_uiReader=0;

  /// <summary>
  /// Handle to smart card.
  /// </summary>
  int m_hCard=INVALID_HANDLE_VALUE;

  /// <summary>
  /// Smartcard active protocol.
  /// </summary>
  uint m_uiActiveProtocol=SCARD_PROTOCOL_UNDEFINED;

  /// <summary>
  /// Smartcard state.
  /// </summary>
  uint m_uiState=SCARD_UNKNOWN;

  /// <summary>
  /// Smartcard ATR data.
  /// </summary>
  byte[] m_pui8ATRData;

  /// <summary>
  /// Error from Init() call when registry is read.
  /// </summary>
  Error m_eRegistryError;

  /// <summary>
  /// Delegate type used to invoke MUSUBMessage handler in window UI thread.
  /// </summary>
  /// <param name="msg">MSUSBMessage message to handle.</param>
  public delegate void MSUSBMessageDelegate(MSUSBMessage msg);

  /// <summary>
  /// Delegate type used to invoke Exception handler in window UI thread.
  /// </summary>
  /// <param name="ex">Exception to handle.</param>
  public delegate void MSUSBExceptionDelegate(Exception ex);

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for every MSUSB message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever any message is recevied from
  ///          the Sagem device.
  /// </summary>
  public MSUSBMessageDelegate HandleSagemMessage;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for GET_DESCRIPTOR message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever a GET_DESCRIPTOR message is
  ///          recevied from the Sagem device.
  /// </summary>
  public MSUSBMessageDelegate HandleILVGetDescriptor;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for ASYNCHRONOUS_MESSAGE message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever an ASYNCHRONOUS_MESSAGE message
  ///          is recevied from the Sagem device.
  /// </summary>
  public MSUSBMessageDelegate HandleILVAsynchronousMessage;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for ENROLL message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever an ENROLL message is recevied
  ///          from the Sagem device.
  /// </summary>
  public MSUSBMessageDelegate HandleILVEnroll;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for VERIFY_MATCH message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever an VERIFY_MATCH message is
  ///          recevied from the Sagem device.
  /// </summary>
  public MSUSBMessageDelegate HandleILVVerifyMatch;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for messages w/o their own delegate.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever an message is recevied from the
  ///          Sagem device for which there is no specific delgate defined.
  /// </summary>
  public MSUSBMessageDelegate HandleILVOther;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for an MSUSB exception.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever an exception is thrown by the
  ///          CN3PIV MSUSBSerialPort object's read thread.
  /// </summary>
  public MSUSBExceptionDelegate HandleSagemReadException;

  /// <summary>
  /// Delegate used to invoke MDPMessage handler in window UI thread.
  /// </summary>
  /// <param name="msg">MDPMessage message to handle.</param>
  public delegate void MDPMessageDelegate(MDPMessage msg);

  /// <summary>
  /// Delegate used to invoke Exception handler in window UI thread.
  /// </summary>
  /// <param name="ex">Exception to handle.</param>
  public delegate void MDPExceptionDelegate(Exception ex);

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for every MSR message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever any message is recevied from
  ///          the MSR device.
  /// </summary>
  public MDPMessageDelegate HandleMSRMessage;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for ping data MSR message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever a Ping message is recevied from
  ///          the MSR device.
  /// </summary>
  public MDPMessageDelegate HandleMSRMessagePing;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for power status MSR message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever a Power message is recevied from
  ///          the MSR device.
  /// </summary>
  public MDPMessageDelegate HandleMSRMessagePower;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for data clear MSR message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever a Data Clear message is recevied
  ///          from the MSR device.
  /// </summary>
  public MDPMessageDelegate HandleMSRMessageDataClear;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for track 1 data MSR message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever a track 1 data message is
  ///          recevied from the MSR device.
  /// </summary>
  public MDPMessageDelegate HandleMSRMessageTrack1Data;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for track 2 data MSR message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever a track 2 data message is
  ///          recevied from the MSR device.
  /// </summary>
  public MDPMessageDelegate HandleMSRMessageTrack2Data;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for track 3 data MSR message.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever a track 3 data message is
  ///          recevied from the MSR device.
  /// </summary>
  public MDPMessageDelegate HandleMSRMessageTrack3Data;

  /// <summary>
  /// \brief Delegate invoked on form's UI thread for an MSR exception.
  /// \details Add a form's handler to this delegate and it will be Invoke()'d
  ///          on the form's UI thread whenever an exception is thrown by the
  ///          CN3PIV MDPSerialPort object's read thread.
  /// </summary>
  public MDPExceptionDelegate HandleMSRReadException;

  /// <summary>
  /// Delegate we'll use to invoke when a resume event happens.
  /// </summary>
  /// <param name="state">PowerState sent in resume event.</param>
  public delegate void ResumeDelegate(PowerState state);

  /// <summary>
  /// Delegate variable to which owner can add his handler.
  /// </summary>
  public event ResumeDelegate HandleResume;

  #endregion

  #region Constructors

  #region CN3PIV()
  /// <summary>
  /// Default constructor, do not use.
  /// </summary>
  public CN3PIV()
  {
    System.Diagnostics.Debug.Assert(false);
  }
  #endregion

  #region CN3PIV(Form form)
  /// <summary>
  /// \brief Full valued constructor, register parent form.
  /// \details This constructor saves a reference to the Form passed in.  The
  ///          Form is then used as the target of Invoke() when the CN3PIV
  ///          object receives messages from the Sagem device or MSR.
  /// </summary>
  public CN3PIV(Form form)
  {
    Error msrErr=Error.Unknown, fprErr=Error.Unknown;
    Microsoft.Win32.RegistryKey key=null;

    m_form = form;

    System.OperatingSystem osInfo = System.Environment.OSVersion;    
    if(osInfo.Platform == PlatformID.WinCE)
    {
      m_resumeNotifier = new ResumeNotifier(form);
      m_resumeNotifier.HandleResume += OnResume;
      m_resumeNotifier.Start();
    }
    m_msrPortName = "COM1";
    m_sagemPortName = "COM2";
  }
  #endregion

  #endregion Constructors

  #region Methods

  #region private string FindPortName(string device)
  /// <summary>
  /// Finds the COM port name of either the MSR or FPR device per the
  /// list of active drivers in the Windows Registry.
  /// </summary>
  /// <param name="device">"MSR" or "FPR", device to search for.</param>
  /// <returns>A string of the form "COMx", where 'x' is the port number, 0-9.</returns>
  private string FindPortName(string device)
  {
    string portName=null;
    Microsoft.Win32.RegistryKey key=null;

    key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("Drivers\\Active");

    if(key != null)
    {
      string[] subKeyNames = key.GetSubKeyNames();
      if(subKeyNames != null)
      {
        for(int i=0; i<subKeyNames.Length; i++)
        {
          Microsoft.Win32.RegistryKey subkey=null;
          subkey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("Drivers\\Active\\" + subKeyNames[i]);
          if(subkey != null)
          {
            object o = subkey.GetValue("Key", (object)null);
            if(o != null)
            {
              string keyString = o.ToString();
              if(keyString.CompareTo("Drivers\\USB\\ClientDrivers\\USBCDC_Template_PIV_" + device) == 0)
              {
                o = subkey.GetValue("Name", (object)null);
                if(o != null)
                {
                  string s = o.ToString();
                  portName = s.Substring(0, s.Length-1);
                }
              }
            }
          }
        }
      }
    }

    return portName;
  }
  #endregion

  #region public bool FindMSR()
  /// <summary>
  /// Finds the COM port name of the MSR device per the
  /// list of active drivers in the Windows Registry.
  /// </summary>
  /// <returns>True if the MSR device COM port is found, false otherwise.</returns>
  /// <remarks>This function sets the MSRPortName property if found.</remarks>
  public bool FindMSR()
  {
    string msrPortName = FindPortName("MSR");
    if(msrPortName != null)
    {
      m_msrPortName = msrPortName;
    }
    return (msrPortName != null);
  }
  #endregion

  #region public bool FindSagem()
  /// <summary>
  /// Finds the COM port name of the FPR device per the
  /// list of active drivers in the Windows Registry.
  /// </summary>
  /// <returns>True if the FPR device COM port is found, false otherwise.</returns>
  /// <remarks>This function sets the SagemPortName property if found.</remarks>
  public bool FindSagem()
  {
    string fprPortName = FindPortName("FPR");
    if(fprPortName != null)
    {
      m_sagemPortName = fprPortName;
    }
    return (fprPortName != null);
  }
  #endregion

  #region private byte[] GetImageILVData(MSUSBMessage msg)
  /// <summary>
  /// Extracts the data section from an 'image' ILV message.
  /// </summary>
  /// <param name="msg">ILV message from which data will be extracted.</param>
  /// <returns>Byte array containing image data.</returns>
  private byte[] GetImageILVData(MSUSBMessage msg)
  {
    //
    // first extract the length and 'size of length field' from ILV
    //
    ulong ui64L = msg.L;
    uint ui32L = (uint)ui64L;
    uint ui32LBytes = (uint)(ui64L>>32);

    //
    // now create two byte arrays - header and image
    //
    byte[] message = msg.Message;
    byte[] image = new byte [message.Length - 1 - ui32LBytes - 12];
    for(int i=0; i<image.Length; i++)
    {
      image[i] = message[1 + ui32LBytes + 12 + i];
    }

    //
    // return value is array of image bytes
    //
    return image;
  }
  #endregion

  #region private byte[] GetImageILVHeader(MSUSBMessage msg)
  /// <summary>
  /// Extracts the header section from an 'image' ILV message.
  /// </summary>
  /// <param name="msg">ILV message from which header will be extracted.</param>
  /// <returns>Byte array containing image header.</returns>
  private byte[] GetImageILVHeader(MSUSBMessage msg)
  {
    //
    // first extract the length and 'size of length field' from ILV
    //
    ulong ui64L = msg.L;
    uint ui32L = (uint)ui64L;
    uint ui32LBytes = (uint)(ui64L>>32);

    //
    // now create two byte arrays - header and image
    //
    byte[] message = msg.Message;
    byte[] header = new byte[12];
    for(int i=0; i<header.Length; i++)
    {
      header[i] = message[1 + ui32LBytes + i];
    }

    //
    // return value is array of bytes constituting header
    //
    return header;
  }
  #endregion

  #region public int GetWSQDLLVersion()
  /// <summary>
  /// Gets the version of the WSQ.dll currently being used by the CN3PIV object.
  /// </summary>
  /// <returns>Version of WSQ.dll as returned by \ref WSQDLL.cpp::WSQ_GetVersion
  /// if successful, 0 on any error from ref WSQDLL.cpp::WSQ_GetVersion.</returns>
  public int GetWSQDLLVersion()
  {
    int iVersion=0, iStatus=0;
    iStatus = WSQ_GetVersion(ref iVersion);
    if(iStatus != 0)
    {
      iVersion = 0;
    }
    return iVersion;
  }
  #endregion

  #region public int GetOKPWRCEDLLVersion()
  /// <summary>
  /// Gets the version of the OKPWRCE.dll currently being used by the CN3PIV object.
  /// </summary>
  /// <returns>Version of OKPWRCE.dll as returned by \ref OKPWRCE.cpp::OKPWRCE_GetVersion
  /// if successful, 0 on any error from ref OKPWRCE.cpp::OKPWRCE_GetVersion.</returns>
  public int GetOKPWRCEDLLVersion()
  {
    return 0;
    //int iVersion=0, iStatus=0;
    //iStatus = OKPWR_GetVersion(ref iVersion);
    //if(iStatus != 0)
    //{
    //  iVersion = 0;
    //}
    //return iVersion;
  }
  #endregion

  #region private byte[] BMPCreate(...)
  /// <summary>
  /// Creates a .bmp file image in ram from raw input data.
  /// </summary>
  /// <param name="data">Byte array containing bitmap data.</param>
  /// <param name="width">Width in pixels of bitmap data.</param>
  /// <param name="height">Height in pixels of bitmap data.</param>
  /// <param name="depth">Depth in bits-per-pixel of bitmap data.</param>
  /// <param name="hres">Horizontal resolution of bitmap data in pixels per meter.</param>
  /// <param name="vres">Vertical resolution of bitmap data in pixels per meter.</param>
  /// <param name="numcolors">Number of colors in bitmap image.</param>
  /// <param name="impcolors">Number of important colors in bitmap image.</param>
  /// <returns>Byte array containing .bmp image.</returns>
  /// <remarks>Note that this function swaps left for right and up for down when
  /// creating .bmp image.  This is due to the orientation of the sensor on the CN3PIV hardware.</remarks>
  private byte[] BMPCreate(byte[] data, int width, int height, int depth, int hres, int vres, int numcolors, int impcolors)
  {
    byte[] bmp=null;

    //
    // first calculate overall header sizes, file size, etc
    //
    uint dataOffset = BMPBaseHeaderSize + BMPDIBHeaderSize + BMPPaletteSize;
    uint imageSize = (uint)data.Length;
    uint overallFileSize = dataOffset + imageSize;

    //
    // create bmp file array based on sizes and fill in data
    //
    bmp = new byte[overallFileSize];
    bmp[0x00] = 0x42;                             // 'B'
    bmp[0x01] = 0x4D;                             // 'M'
    bmp[0x02] = (byte)(overallFileSize);          // overall file size
    bmp[0x03] = (byte)(overallFileSize >> 8);     //
    bmp[0x04] = (byte)(overallFileSize >> 16);    //
    bmp[0x05] = (byte)(overallFileSize >> 24);    //
    bmp[0x06] = 0x00;                             // unused = 0x0000
    bmp[0x07] = 0x00;                             //
    bmp[0x08] = 0x00;                             // unused = 0x0000
    bmp[0x09] = 0x00;                             //
    bmp[0x0A] = (byte)(dataOffset);               // data offset
    bmp[0x0B] = (byte)(dataOffset >> 8);          //
    bmp[0x0C] = (byte)(dataOffset >> 16);         //
    bmp[0x0D] = (byte)(dataOffset >> 24);         //
    bmp[0x0E] = (byte)(BMPDIBHeaderSize);         // num header bytes
    bmp[0x0F] = (byte)(BMPDIBHeaderSize >> 8);    //
    bmp[0x10] = (byte)(BMPDIBHeaderSize >> 16);   //
    bmp[0x11] = (byte)(BMPDIBHeaderSize >> 24);   //
    bmp[0x12] = (byte)(width);                    // width
    bmp[0x13] = (byte)(width >> 8);               //
    bmp[0x14] = (byte)(width >> 16);              //
    bmp[0x15] = (byte)(width >> 24);              //
    bmp[0x16] = (byte)(height);                   // height
    bmp[0x17] = (byte)(height >> 8);              //
    bmp[0x18] = (byte)(height >> 16);             //
    bmp[0x19] = (byte)(height >> 24);             //
    bmp[0x1A] = 0x01;                             // num color planes = 0x0001
    bmp[0x1B] = 0x00;                             //
    bmp[0x1C] = (byte)(depth);                    // bits per pixel
    bmp[0x1D] = (byte)(depth >> 8);               //
    bmp[0x1E] = 0x00;                             // compression = none
    bmp[0x1F] = 0x00;                             //
    bmp[0x20] = 0x00;                             //
    bmp[0x21] = 0x00;                             //
    bmp[0x22] = (byte)(imageSize);                // size of bmp data
    bmp[0x23] = (byte)(imageSize >> 8);           //
    bmp[0x24] = (byte)(imageSize >> 16);          //
    bmp[0x25] = (byte)(imageSize >> 24);          //
    bmp[0x26] = (byte)hres;                       // horiz resolution
    bmp[0x27] = (byte)(hres >> 8);                //
    bmp[0x28] = (byte)(hres >> 16);               //
    bmp[0x29] = (byte)(hres >> 24);               //
    bmp[0x2A] = (byte)vres;                       // vert resolution
    bmp[0x2B] = (byte)(vres >> 8);                //
    bmp[0x2C] = (byte)(vres >> 16);               //
    bmp[0x2D] = (byte)(vres >> 24);               //
    bmp[0x2E] = (byte)numcolors;                  // number of colors
    bmp[0x2F] = (byte)(numcolors >> 8);           //
    bmp[0x30] = (byte)(numcolors >> 16);          //
    bmp[0x31] = (byte)(numcolors >> 24);          //
    bmp[0x32] = (byte)(impcolors);                // important colors (0 all)
    bmp[0x33] = (byte)(impcolors >> 8);           //
    bmp[0x34] = (byte)(impcolors >> 16);          //
    bmp[0x35] = (byte)(impcolors >> 24);          //
    for(int i=0; i<BMPPaletteSize; i+=4)          // grayscale 0x00 0x00 0x00 0x00
    {                                             //           0x01 0x01 0x01 0x00
      bmp[0x36 + i] = (byte)i;                    //           0x02 0x02 0x02 0x00
      bmp[0x37 + i] = (byte)i;                    //           .... .... .... ....
      bmp[0x38 + i] = (byte)i;                    //           .... .... .... ....
      bmp[0x39 + i] = 0x00;                       //           0xEE 0xEE 0xEE 0x00
    }                                             //           0xFF 0xFF 0xFF 0x00
#if true                                          // image data (swap for sensor orientation)
    for(int row=0; row<height; row++)
    {
      for(int col=0; col<width; col++)
      {
        bmp[(0x36 + BMPPaletteSize) + (height-row-1)*width + col] = (byte)(data[row*width + col]);
      }
    }
#else
    for(int i=0; i<data.Length; i++)              // image data (no accounting for sensor orientation)
    {
      bmp[0x36 + BMPPaletteSize + i] = (byte)(data[i]);
    }
#endif
    return bmp;
  }
  #endregion

  #region public byte[] ILV2BMP(MSUSBMessage msg)
  /// <summary>
  /// Creates a .bmp image from an ILV Image message.
  /// </summary>
  /// <param name="msg">ILV Image message.</param>
  /// <param name="numcolors">Number of colors to set in .bmp image.</param>
  /// <returns>Byte array containing .bmp image data.</returns>
  /// <remarks>Note that this function swaps left for right and up for down when
  /// creating .bmp image.  This is due to the orientation of the sensor on the CN3PIV hardware.</remarks>
  public byte[] ILV2BMP(MSUSBMessage msg, int numcolors)
  {
    byte[] bmp=null;

    //
    // first extract header and image from ILV
    //
    byte[] header = GetImageILVHeader(msg);
    byte[] imageData = GetImageILVData(msg);

    //
    // check parameters etc and continue if OK
    //
    if(header[10] == MSUSBMessage.ILV.ID_COMPRESSION_NULL)
    {
      //
      // get parameters from ILV header and
      // generate a bitmap file image in memory
      //
      int width = header[5];
      width <<= 8;
      width += header[4];
      int height = header[3];
      height <<= 8;
      height += header[2];
      int depth = header[11];
      int hres = header[9];
      hres <<= 8;
      hres += header[8];
      int vres = header[7];
      vres <<= 8;
      vres += header[6];
      bmp = BMPCreate(imageData, width, height, depth, hres*800, vres*800, numcolors, 0);
    }

    return bmp;
  }
  #endregion

  #region public byte[] ILV2WSQ(MSUSBMessage msg)
  /// <summary>
  /// Creates a .wsq image from an ILV Image message.
  /// </summary>
  /// <param name="msg">ILV Image message.</param>
  /// <returns>Byte array containing .wsq image data.</returns>
  public byte[] ILV2WSQ(MSUSBMessage msg)
  {
    int width=0, height=0, depth=0, ppi=0;
    byte[] wsqimage=null;

    //
    // first extract the length and 'size of length field' from ILV
    //
    ulong ui64L = msg.L;
    uint ui32L = (uint)ui64L;
    uint ui32LBytes = (uint)(ui64L>>32);

    //
    // now create two byte arrays - header and image
    //
    byte[] header = GetImageILVHeader(msg);
    byte[] image = GetImageILVData(msg);

    //
    // thus far we've used uncompressed images from the sagem device
    // so we'll check for that here - leave compressed images for future.
    //
    if(header[10] == MSUSBMessage.ILV.ID_COMPRESSION_NULL)
    {
      //
      // extract parameters from header - width, height and depth are in image
      // header, we use -1 for ppi since we don't know it here.
      //
      width = header[5];
      width <<= 8;
      width += header[4];
      height = header[3];
      height <<= 8;
      height += header[2];
      depth = header[11];
      ppi = -1;

      //
      // now get a pointer to the input data, a pointer to hold the output
      // data and a pointer to the output data array length.  we pass the
      // pointer to the output array size into the DLL call and it changes
      // the value to match the output array size on return.
      //
      IntPtr idata = Marshal.AllocHGlobal(image.Length);
      Marshal.Copy(image, 0, idata, image.Length);
      IntPtr odata = Marshal.AllocHGlobal(image.Length);
      IntPtr olen = Marshal.AllocHGlobal(sizeof(int));
      int[] olenarray = new int[1];
      olenarray[0] = image.Length;
      Marshal.Copy(olenarray, 0, olen, 1);

      //
      // call into the DLL to convert the image to WSQ format.  when this
      // returns, the image is 'olen' bytes long in 'odata'.
      //
      int res = WSQ_ConvertFromRaw(idata, width, height, depth, ppi, odata, olen);

      //
      // check result - 0 is success and we can proceed with creating the
      // WSQ image output array.  it's 'olen' bytes long in 'odata'.
      //
      if(res == 0)
      {
        Marshal.Copy(olen, olenarray, 0, 1);
        wsqimage = new byte[olenarray[0]];
        Marshal.Copy(odata, wsqimage, 0, wsqimage.Length);
      }

      //
      // in any case, free up what we've allocated before the DLL call.
      //
      Marshal.FreeHGlobal(idata);
      Marshal.FreeHGlobal(olen);
      Marshal.FreeHGlobal(odata);
    }

    return wsqimage;
  }
  #endregion

  #region public byte[] WSQ2BMP(byte[] wsq, int maxlen, int numcolors, int impcolors)\
  /// <summary>
  /// Creates a .bmp image from an .wsq image.
  /// </summary>
  /// <param name="wsq">Byte array containing .wsq image data.</param>
  /// <param name="maxlen">Maximum length to allocate for .bmp image data.</param>
  /// <param name="numcolors">Number of colors to set in .bmp image data.</param>
  /// <param name="impcolors">Number of important colors to set in .bmp image data.</param>
  /// <returns>Byte array containing .bmp image data.</returns>
  /// <remarks>Note that this function swaps left for right and up for down when
  /// creating .bmp image.  This is due to the orientation of the sensor on the CN3PIV hardware.</remarks>
  public byte[] WSQ2BMP(byte[] wsq, int maxlen, int numcolors, int impcolors)
  {
    byte[] raw=null;
    byte[] bmp=null;
    int[] intarray = new int[1];

    //
    // first thing to do is extract the raw data from the wsq.  allocate
    // pointers to memory for DLL call first...
    //
    IntPtr idata = Marshal.AllocHGlobal(wsq.Length);
    Marshal.Copy(wsq, 0, idata, wsq.Length);
    IntPtr width = Marshal.AllocHGlobal(sizeof(int));
    IntPtr height = Marshal.AllocHGlobal(sizeof(int));
    IntPtr depth = Marshal.AllocHGlobal(sizeof(int));
    IntPtr ppi = Marshal.AllocHGlobal(sizeof(int));
    IntPtr lossy = Marshal.AllocHGlobal(sizeof(int));
    IntPtr odata = Marshal.AllocHGlobal(maxlen);
    IntPtr olen = Marshal.AllocHGlobal(sizeof(int));
    intarray[0] = maxlen;
    Marshal.Copy(intarray, 0, olen, 1);

    //
    // now call into DLL to decompress image.  return value is 0 on success.
    //
    int res = WSQ_ConvertToRaw(idata, wsq.Length, width, height, depth, ppi, lossy, odata, olen);
    if(res == 0)
    {
      //
      // looks like decompression was successfull.  next thing to do is
      // get parameters out of their pointers.
      //
      Marshal.Copy(width, intarray, 0, 1);
      int iwidth = intarray[0];
      Marshal.Copy(height, intarray, 0, 1);
      int iheight = intarray[0];
      Marshal.Copy(depth, intarray, 0, 1);
      int idepth = intarray[0];
      Marshal.Copy(ppi, intarray, 0, 1);
      int ippi = intarray[0];
      Marshal.Copy(lossy, intarray, 0, 1);
      int ilossy = intarray[0];
      Marshal.Copy(olen, intarray, 0, 1);
      raw = new byte[intarray[0]];
      Marshal.Copy(odata, raw, 0, raw.Length);

      //
      // now create a bmp image in memory using what we've extracted
      //
      bmp = BMPCreate(raw, iwidth, iheight, idepth, ippi, ippi, numcolors, impcolors);
    }

    //
    // no matter the success or failure of DLL call, we need to free memory
    //
    Marshal.FreeHGlobal(idata);
    Marshal.FreeHGlobal(width);
    Marshal.FreeHGlobal(height);
    Marshal.FreeHGlobal(depth);
    Marshal.FreeHGlobal(ppi);
    Marshal.FreeHGlobal(lossy);
    Marshal.FreeHGlobal(odata);
    Marshal.FreeHGlobal(olen);

    //
    // return bmp image (this may be null if decompression failed)
    //
    return bmp;
  }
  #endregion

  #region private void OnResume(PowerState powerState)
  /// <summary>
  /// Handler for 'resume' event sent to us by \ref m_resumeNotifier.
  /// </summary>
  /// <param name="powerState">New power state as per event contents.</param>
  private void OnResume(PowerState powerState)
  {
    #warning <Do These Two Things In Invoke()'d Delegate>
    CloseMSR();
    CloseSagem();
    if(m_form.InvokeRequired)
    {
      m_form.Invoke(HandleResume, new object[] {powerState});
    }
    else
    {
      HandleResume(powerState);
    }
  }
  #endregion

  #region public void CloseAndStopAll()
  /// <summary>
  /// Cleanup function used to make sure all hardware is closed and threads
  /// are stopped.
  /// </summary>
  public void CloseAndStopAll()
  {
    CloseMSR();
    CloseSagem();
    if(m_resumeNotifier != null)
    {
      m_resumeNotifier.Stop();
    }
  }
  #endregion

  #region public void OpenSagem()
  /// <summary>
  /// \brief Opens Sagem serial port.
  /// \details Call this function to open the Sagem serial port contained in
  ///          the CN3PIV object.  Use the \ref SagemIsOpen property to see
  ///          if the port was opened properly.
  /// </summary>
  /// <remarks>This function looks into the Windows Registry to try to find the COM
  /// port representing the Sagem device, and therefore may not open the COM port
  /// to which its \ref SagemPortName parameter is set.</remarks>
  #warning <This Should Be Renamed>
  #warning <Implement Optional Timeout>
  public void OpenSagem()
  {
    if(m_sagemPort != null)
    {
      if(m_sagemPort.IsOpen)
      {
        try
        {
          m_sagemPort.Close();
        }
        catch
        {
        }
      }
      m_sagemPort = null;
    }

    if(FindSagem())
    {
      m_sagemPort = new MSUSBSerialPort(m_sagemPortName, 9600);
      m_sagemPort.OnMessage += OnSagemMessage;
      m_sagemPort.OnReadException += OnSagemReadException;

      try
      {
        m_sagemPort.Open();
      }
      catch
      {
        try
        {
          m_sagemPort.Close();
        }
        catch
        {
        }
        m_sagemPort = null;
      }
    }
  }
  #endregion

  #region public void OpenMSR()
  /// <summary>
  /// \brief Opens MSR serial port.
  /// \details Call this function to open the MSR serial port contained in
  ///          the CN3PIV object.  Use the \ref MSRIsOpen property to see
  ///          if the port was opened properly.
  /// </summary>
  /// <remarks>This function looks into the Windows Registry to try to find the COM
  /// port representing the MSR device, and therefore may not open the COM port
  /// to which its \ref MSRPortName parameter is set.</remarks>
  #warning <This Should Be Renamed>
  #warning <Implement Optional Timeout>
  public void OpenMSR()
  {
    if(m_msrPort != null)
    {
      if(m_msrPort.IsOpen)
      {
        try
        {
          m_msrPort.Close();
        }
        catch
        {
        }
      }
      m_msrPort = null;
    }

    if(FindMSR())
    {
      m_msrPort = new MDPSerialPort(m_msrPortName, 9600);
      m_msrPort.OnMessage += OnMSRMessage;
      m_msrPort.OnReadException += OnMSRReadException;
    
      try
      {
        m_msrPort.Open();
      }
      catch
      {
        try
        {
          m_msrPort.Close();
        }
        catch
        {
        }
        m_msrPort = null;
      }
    }
  }
  #endregion

  #region public void CloseSagem()
  /// <summary>
  /// \brief Closes Sagem serial port.
  /// \details Call this function to close the Sagem serial port contained in
  ///          the CN3PIV object.  Use the \ref SagemIsOpen property to see if
  ///          the port was closed properly.
  /// </summary>
  #warning <This Should Be Renamed>
  public void CloseSagem()
  {
    if(m_sagemPort != null)
    {
      if(m_sagemPort.IsOpen)
      {
        try
        {
          m_sagemPort.Close();
        }
        catch
        {
          m_sagemPort = null;
        }
      }
      m_sagemPort = null;
    }
  }
  #endregion

  #region public void CloseMSR()
  /// <summary>
  /// \brief Closes MSR serial port.
  /// \details Call this function to close the MSR serial port contained in
  ///          the CN3PIV object.  Use the \ref MSRIsOpen property to see if
  ///          the port was closed properly.
  /// </summary>
  #warning <This Should Be Renamed>
  public void CloseMSR()
  {
    if(m_msrPort != null)
    {
      if(m_msrPort.IsOpen)
      {
        try
        {
          m_msrPort.Close();
        }
        catch
        {
          m_msrPort = null;
        }
      }
      m_msrPort = null;
    }
  }
  #endregion

  #region public Error SendILVCancel()
  /// <summary>
  /// \brief Cancels any operation the Sagem device is currently performing.
  /// \details This function sends the CANCEL ILV message to the Sagem device
  ///          to cancel any current operation.  The Sagem device will respond
  ///          with the reply message appropriate to the operation it is
  ///          performing (if any) and return to its idle state.
  /// </summary>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  #warning <This Should Be Renamed>
  public Error SendILVCancel()
  {
    Error eError=Error.Unknown;

    //
    // just check the port and send message if open.  set error code per port.
    //
    if(SagemIsOpen)
    {
      if(m_sagemPort.WriteILVMessage(MSUSBMessage.ILV.CANCEL) == ParsingSerialPort.Error.None)
      {
        eError = Error.None;
      }
      else
      {
        eError = Error.Port;
      }
    }
    else
    {
      eError = Error.NotOpen;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SendILVGetDescriptor(byte ui8Format)
  /// <summary>
  /// \brief Sends the GET DESCRIPTOR ILV message to the Sagem device.
  /// \details This function sends the GET DESCRIPTOR ILV message to the Sagem
  ///          device to retrieve its descriptor in the specified format.  The
  ///          Sagem device will respond with the GET DESCRIPTOR ILV message
  ///          and the \ref HandleILVGetDescriptor delegate will be invoked.
  /// </summary>
  /// <param name="ui8Format">Format of descriptor to be returned.  MSUSBMessage.ILV.ID_FORMAT_BIN_VERSION, MSUSBMessage.ILV.ID_FORMAT_BIN_VERSION or MSUSBMessage.ILV.ID_FORMAT_BIN_VERSION.</param>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  #warning <This Should Be Renamed>
  public Error SendILVGetDescriptor(byte ui8Format)
  {
    Error eError=Error.Unknown;
    byte[] pui8V = new byte[1];
    pui8V[0] = ui8Format;

    //
    // just check the port and send message if open.  set error code per port.
    //
    if(SagemIsOpen)
    {
      if(m_sagemPort.WriteILVMessage(MSUSBMessage.ILV.GET_DESCRIPTOR, pui8V) == ParsingSerialPort.Error.None)
      {
        eError = Error.None;
      }
      else
      {
        eError = Error.Port;
      }
    }
    else
    {
      //
      // port is not open, set error code
      //
      eError = Error.NotOpen;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SendILVEnroll(...)
  /// <summary>
  /// \brief Sends the ENROLL ILV message to the Sagem device.
  /// \details This function sends the ENROLL ILV message to the Sagem device
  ///          to retrieve a fingerprint image.  When a fingerprint grab is
  ///          complete, The Sagem device will respond with the ENROLL ILV
  ///          message and the \ref HandleILVEnroll delegate will be invoked.
  ///          If asynchronous events are specified in the \ref
  ///          ui32AsynchronousEvents parameter, the \ref
  ///          HandleILVAsynchronousMessage delegate will be invoked when they
  ///          are received.
  /// </summary>
  /// <param name="ui16Timeout">Timeout in seconds.  A value of 0 specifies an infinite timeout.</param>
  /// <param name="ui8EnrollmentType">Specifies the number of fingerprint image acquisitions per finger.  Allowed values are 1 and 3.</param>
  /// <param name="ui8NumberOfFingers">The number of fingers to enroll. This function can enroll 1 or 2 fingers.</param>
  /// <param name="ui32AsynchronousEvents">Bitmask containing asynchronous events the Sagem device should generate.
  ///                                      Values to be or'd together are...
  ///                                      \li MSUSBMessage.ILV.MESSAGE_COMMAND_CMD
  ///                                      \li MSUSBMessage.ILV.MESSAGE_IMAGE_CMD
  ///                                      \li MSUSBMessage.ILV.MESSAGE_ENROLLMENT_CMD
  ///                                      \li MSUSBMessage.ILV.MESSAGE_IMAGE_FULL_RES_CMD
  ///                                      \li MSUSBMessage.ILV.MESSAGE_CODE_QUALITY_CMD
  ///                                      \li MSUSBMessage.ILV.MESSAGE_DETECT_QUALITY_CMD
  /// </param>
  /// <param name="ui8BiometricAlgorithmParameter">Specifies the format of the biometric
  ///                                              templates to be output by the Sagem device.
  ///                                              Allowed values are specified in \ref
  ///                                              MSUSBMessage.ILV.BiometricAlgorithmParameter.</param>
  /// <param name="bExportImage">Specify true to include the fingerprint image data in the final ENROLL message reply.</param>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  #warning <This Should Be Renamed>
  public Error SendILVEnroll(ushort ui16Timeout, byte ui8EnrollmentType,
                             byte ui8NumberOfFingers,
                             uint ui32AsynchronousEvents,
                             byte ui8BiometricAlgorithmParameter,
                             bool bExportImage)
  {
    Error eError=Error.Unknown;

    //
    // first check to make sure the port is open
    //
    if(SagemIsOpen)
    {
      //
      // 8 bytes for mandatory stuff, 7 optional asynchronous events bytes,
      // 4 mandatory biometric algorithm parameter bytes, 9 optional bytes
      // for export image data
      //
      ushort ui16Len = 8;
      if(ui32AsynchronousEvents != 0)
      {
        ui16Len += 7;
      }
      ui16Len += 4;
      if(bExportImage)
      {
        ui16Len += 9;
      }
      byte[] pui8Msg = new byte[ui16Len];

      if(pui8Msg != null)
      {
        //
        // first 8 bytes are mandatory
        //
        pui8Msg[0] = 0x00;                      // database identifier
        pui8Msg[1] = (byte)ui16Timeout;         // timeout lsb
        pui8Msg[2] = (byte)(ui16Timeout >> 8);  // timeout msb
        pui8Msg[3] = 0x00;                      // acq qual thresh
        pui8Msg[4] = ui8EnrollmentType;         // grabs per finger
        pui8Msg[5] = ui8NumberOfFingers;        // number of fingers
        pui8Msg[6] = 0x00;                      // don't save record
        pui8Msg[7] = 0x01;                      // export minutiae 
        ui16Len = 8;

        //
        // next comes asynchronous events, if specified
        //
        if(ui32AsynchronousEvents != 0)
        {
          pui8Msg[ui16Len++] = MSUSBMessage.ILV.ID_ASYNCHRONOUS_EVENT;
          pui8Msg[ui16Len++] = 0x04;
          pui8Msg[ui16Len++] = 0x00;
          pui8Msg[ui16Len++] = (byte)(ui32AsynchronousEvents);
          pui8Msg[ui16Len++] = (byte)(ui32AsynchronousEvents >> 8);
          pui8Msg[ui16Len++] = (byte)(ui32AsynchronousEvents >> 16);
          pui8Msg[ui16Len++] = (byte)(ui32AsynchronousEvents >> 24);
        }

        //
        // biomentric algorithm is next
        //
        pui8Msg[ui16Len++] = MSUSBMessage.ILV.ID_BIO_ALGO_PARAM;
        pui8Msg[ui16Len++] = 0x01;
        pui8Msg[ui16Len++] = 0x00;
        pui8Msg[ui16Len++] = ui8BiometricAlgorithmParameter;

        //
        // export image (optional) is last
        //
        if(bExportImage)
        {
          pui8Msg[ui16Len++] = MSUSBMessage.ILV.ID_EXPORT_IMAGE;
          pui8Msg[ui16Len++] = 0x06;
          pui8Msg[ui16Len++] = 0x00;
          pui8Msg[ui16Len++] = MSUSBMessage.ILV.ID_DEFAULT_IMAGE;
          pui8Msg[ui16Len++] = MSUSBMessage.ILV.ID_COMPRESSION;
          pui8Msg[ui16Len++] = 0x02;
          pui8Msg[ui16Len++] = 0x00;
          pui8Msg[ui16Len++] = MSUSBMessage.ILV.ID_COMPRESSION_NULL;
          pui8Msg[ui16Len++] = 0x00;
        }

        //
        // now just send message we've constructed
        //
        if(m_sagemPort.WriteILVMessage(MSUSBMessage.ILV.ENROLL, pui8Msg) == ParsingSerialPort.Error.None)
        {
          eError = Error.None;
        }
        else
        {
          eError = Error.Port;
        }
      }
    }
    else
    {
      //
      // port not open - set error code
      //
      eError = Error.NotOpen;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SendILVVerifyMatch(...)
  /// <summary>
  /// \brief Sends the VERIFY MATCH ILV message to the Sagem device.
  /// \details This function sends the VERIFY MATCH ILV message to the Sagem
  ///          device to compare one set of fingerprint minutiae data to up to
  ///          20 others.  When the comparison is complete, The Sagem device
  ///          will respond with the VERIFY MATCH ILV message and the \ref
  ///          HandleILVVerifyMatch delegate will be invoked.
  /// </summary>
  /// <param name="ui16MatchingThreshold">This parameter can be set to values
  ///                                     from 0 to 10 (Sagem Securite recommends
  ///                                     5). This parameter specifies how tight
  ///                                     the matching threshold is. For some more
  ///                                     information, please refer to the
  ///                                     <a href="../pdf\MorphoSmartOverview.pdf">MorphoSmartOverview.pdf</a>
  ///                                     documentation.
  /// </param>
  /// <param name="searchTemplate">MSUSBMessage containing ILV with fingerprint
  ///                              minutiae data as returned by Sagem device in
  ///                              response to an ENROLL command.</param>
  /// <param name="referenceTemplates">ArrayList containing up to 20 MSUSBMessages
  ///                                  containing ILV fingerprint minutiae data
  ///                                  against which searchTemplate will be compared.</param>
  /// <param name="bReturnMatchingScore">True to include the Matching Score ILV in
  ///                                    the VERIFY MATCH reply, false otherwise.</param>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  #warning <This Should Be Renamed>
  public Error SendILVVerifyMatch(ushort ui16MatchingThreshold,
                                  MSUSBMessage searchTemplate,
                                  ArrayList referenceTemplates,
                                  bool bReturnMatchingScore)
  {
    Error eError=Error.Unknown;

    //
    // first make sure we've got appropriate parameters
    //
    if((searchTemplate != null) && (referenceTemplates != null))
    {
      //
      // check number of reference templates
      //
      if((referenceTemplates.Count > 0) && (referenceTemplates.Count <= 20))
      {
        //
        // next check to see if the port is open
        //
        if(SagemIsOpen)
        {
          //
          // first two bytes are mandatory, they are the matching threshold
          //
          ushort ui16Len = 2;

          //
          // next bytes are the search template ILV
          //
          ui16Len += (ushort)(searchTemplate.Length);
          for(int i=0; i<referenceTemplates.Count; i++)
          {
            ui16Len += (ushort)(((MSUSBMessage)(referenceTemplates[i])).Length);
          }

          //
          // matching score is optional, 4 more bytes if set
          //
          if(bReturnMatchingScore)
          {
            ui16Len += 4;
          }

          //
          // make array of bytes of the appropriate length
          //
          byte[] pui8Msg = new byte[ui16Len];
          if(pui8Msg != null)
          {
            //
            // first fill in matching threshold
            //
            pui8Msg[0] = (byte)(ui16MatchingThreshold);
            pui8Msg[1] = (byte)(ui16MatchingThreshold >> 8);
            ui16Len = 2;

            //
            // next fill in search template
            //
            byte[] st = searchTemplate.Message;
            for(int i=0; i<searchTemplate.Length; i++)
            {
              pui8Msg[ui16Len++] = st[i];
            }

            //
            // now fill in reference templates
            //
            for(int j=0; j<referenceTemplates.Count; j++)
            {
              MSUSBMessage referenceTemplate = (MSUSBMessage)referenceTemplates[j];
              byte[] rt = referenceTemplate.Message;
              for(int i=0; i<referenceTemplate.Length; i++)
              {
                pui8Msg[ui16Len++] = rt[i];
              }
            }

            //
            // finally fill in matching score ILV if specified
            //
            if(bReturnMatchingScore)
            {
              pui8Msg[ui16Len++] = MSUSBMessage.ILV.MATCHING_SCORE;
              pui8Msg[ui16Len++] = 0x01;
              pui8Msg[ui16Len++] = 0x00;
              pui8Msg[ui16Len++] = 0xFF;
            }

            //
            // last, just write ILV message to Sagem port and set error
            //
            if(m_sagemPort.WriteILVMessage(MSUSBMessage.ILV.VERIFY_MATCH, pui8Msg) == ParsingSerialPort.Error.None)
            {
              eError = Error.None;
            }
            else
            {
              eError = Error.Port;
            }
          }
          else
          {
            //
            // couldn't allocate array?  wierd.
            //
            eError = Error.Unknown;
          }
        }
        else
        {
          //
          // port not open - set error code
          //
          eError = Error.NotOpen;
        }
      }
      else
      {
        //
        // reference template contains more than 20, set error code
        //
        eError = Error.BadParameter;
      }
    }
    else
    {
      //
      // one or more parameters is null - set error code
      //
      eError = Error.NullParameter;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SendMSRPing()
  /// <summary>
  /// \brief Sends a Ping command to the MSR in order to retreive its
  ///        system information.
  /// \details This function sends a Ping message to the MSR device.
  ///          When the Ping response is received, the MSR device
  ///          will respond with a Ping response message and the \ref
  ///          HandleMSRMessagePing delegate will be invoked.
  /// </summary>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  public Error SendMSRPing()
  {
    Error eError=Error.Unknown;

    //
    // just check to see if the port is open, then send the message
    //
    if(MSRIsOpen)
    {
      //
      // port is open, just send message and set no error
      //
      if(m_msrPort.WriteMDP((byte)MSRPort.Ping, null) == ParsingSerialPort.Error.None)
      {
        eError = Error.None;
      }
      else
      {
        eError = Error.Port;
      }
    }
    else
    {
      //
      // port is not open, set error code
      //
      eError = Error.NotOpen;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SendMSRDataRequest()
  /// <summary>
  /// \brief Sends a Data Request command to the MSR in order to
  ///        retreive its latest MSR data.
  /// \details This function sends a Data Request message to the MSR
  ///          device.  When the Data Request response is received by
  ///          the MSR device, it will respond with three MSR data
  ///          messages and the
  ///          \ref HandleMSRMessageTrack1Data,
  ///          \ref HandleMSRMessageTrack1Error,
  ///          \ref HandleMSRMessageTrack2Data,
  ///          \ref HandleMSRMessageTrack2Error,
  ///          \ref HandleMSRMessageTrack3Data and/or
  ///          \ref HandleMSRMessageTrack3Error delegates will be invoked.
  /// </summary>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  public Error SendMSRDataRequest()
  {
    Error eError=Error.Unknown;

    //
    // just check to see if the port is open, then send the message
    //
    if(MSRIsOpen)
    {
      //
      // port is open, try to send message and set error
      //
      if(m_msrPort.WriteMDP((byte)MSRPort.DataRequest, null) == ParsingSerialPort.Error.None)
      {
        eError = Error.None;
      }
      else
      {
        eError = Error.Port;
      }
    }
    else
    {
      //
      // port is not open, set error code
      //
      eError = Error.NotOpen;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SendMSRDataClear()
  /// <summary>
  /// Sends a 'clear data' message to the MSR.  This causes the MSR to clear its
  /// internal copy of the last MSR swipe data.
  /// </summary>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  public Error SendMSRDataClear()
  {
    Error eError=Error.Unknown;

    //
    // just check to see if the port is open, then send the message
    //
    if(MSRIsOpen)
    {
      //
      // port is open, try to send message and no error
      //
      if(m_msrPort.WriteMDP((byte)MSRPort.DataClear, null) == ParsingSerialPort.Error.None)
      {
        eError = Error.None;
      }
      else
      {
        eError = Error.Port;
      }
    }
    else
    {
      //
      // port is not open, set error code
      //
      eError = Error.NotOpen;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SendMSRPowerSet(bool bFPOn, bool bCCOn, bool b5VOn)
  /// <summary>
  /// Sends a 'power set' message to the MSR, allowing control of the power
  /// supplies to the FPR, SCR and 5V bias.
  /// </summary>
  /// <param name="bFPOn">True to turn the FPR interface on, false to turn it off.</param>
  /// <param name="bCCOn">True to turn the SCR interface on, false to turn it off.</param>
  /// <param name="b5VOn">True to turn the 5V bias on, false to turn it off.</param>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  /// <remarks>Note that the FPR and SCR interfaces cannot be turned on at the same time.
  /// Attempting to do so will result in an error being returned from this call.</remarks>
  public Error SendMSRPowerSet(bool bFPOn, bool bCCOn, bool b5VOn)
  {
    Error eError = Error.Unknown;

    //
    // check to see if the port is open, then send the message
    //
    if(MSRIsOpen)
    {
      //
      // check parameters - both FP and CC should not be
      // turned on at the same time, so we check that here.
      //
      if(!(bFPOn && bCCOn))
      {
        //
        // we construct the message in an order such that the
        // things that are getting powered off are processed
        // first, to keep the power consumption down.
        //
        byte[] msg = new byte[6];
        msg[0] = (byte)(PowerControl._5V);
        msg[1] = b5VOn ? (byte)0xFF : (byte)0x00;
        if(bFPOn)
        {
          //
          // FP is going on, so do CC first (going off)
          //
          msg[2] = (byte)(PowerControl.CC);
          msg[3] = bCCOn ? (byte)0xFF : (byte)0x00;
          msg[4] = (byte)(PowerControl.FP);
          msg[5] = bFPOn ? (byte)0xFF : (byte)0x00;
        }
        else
        {
          //
          // FP is going off, so do it first
          //
          msg[2] = (byte)(PowerControl.FP);
          msg[3] = bFPOn ? (byte)0xFF : (byte)0x00;
          msg[4] = (byte)(PowerControl.CC);
          msg[5] = bCCOn ? (byte)0xFF : (byte)0x00;
        }

        //
        // now just write the message, return error
        // on any error from the 'write' call.
        //
        if(m_msrPort.WriteMDP((byte)(MSRPort.Power), msg) == ParsingSerialPort.Error.None)
        {
          eError = Error.None;
        }
        else
        {
          eError = Error.Port;
        }
      }
      else
      {
        //
        // some bad parameter, set error code
        //
        eError = Error.BadParameter;
      }
    }
    else
    {
      //
      // port is not open, set error code
      //
      eError = Error.NotOpen;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SendMSRPowerGet()
  /// <summary>
  /// Sends a 'power get' message to the MSR, allowing query of the state of
  /// the power supplies to the FPR, SCR and 5V bias.
  /// </summary>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  public Error SendMSRPowerGet()
  {
    Error eError = Error.Unknown;

    //
    // check to see if the port is open, then send the message
    //
    if(MSRIsOpen)
    {
      //
      // port is open, send MDP message and set error code
      //
      if(m_msrPort.WriteMDP((byte)(MSRPort.Power), null) == ParsingSerialPort.Error.None)
      {
        eError = Error.None;
      }
      else
      {
        eError = Error.Port;
      }
    }
    else
    {
      //
      // port is not open, set error code
      //
      eError = Error.NotOpen;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SendMSRPowerSave()
  /// <summary>
  /// Sends a 'power save' message to the MSR, allowing storage of the state of
  /// the power supplies to the FPR, SCR and 5V bias.  This configuration will be
  /// retained in the PIV through a power cycle and assumed when the PIV turns on.
  /// </summary>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  public Error SendMSRPowerSave()
  {
    Error eError = Error.Unknown;

    //
    // check to see if the port is open, then send the message
    //
    if(MSRIsOpen)
    {
      //
      // port is open, send MDP message and set error code
      //
      if(m_msrPort.WriteMDP((byte)(MSRPort.PowerSave), null) == ParsingSerialPort.Error.None)
      {
        eError = Error.None;
      }
      else
      {
        eError = Error.Port;
      }
    }
    else
    {
      //
      // port is not open, set error code
      //
      eError = Error.NotOpen;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SCRInit(uint uiScope)
  /// <summary>
  /// Attempts initialization of the SCR interface.
  /// </summary>
  /// <param name="uiScope">Scope of actions requested by caller,
  /// \ref SCARD_SCOPE_USER, \ref SCARD_SCOPE_TERMINAL or
  /// \ref SCARD_SCOPE_SYSTEM.</param>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  /// \see SCardListReaders
  public Error SCRInit(uint uiScope)
  {
    int iResult;
    Error eError = Error.Unknown;

    //
    // check for valid handle to context
    //
    if(m_hContext == INVALID_HANDLE_VALUE)
    {
      //
      // no context already, try to establish one
      //
      #warning <Can We Get Rid Of These?>
      int iNotUsed1=0;
      int iNotUsed2=0;
      iResult = SCardEstablishContext(uiScope, iNotUsed1, iNotUsed2, ref m_hContext);
      if(iResult == 0)
      {
        //
        // context established, next is to list readers
        //
        int iCharCount = -1;
        string group = "" + Convert.ToChar(0);
        System.Threading.Thread.Sleep(100);
        iResult = SCardListReaders(m_hContext, group, null, out iCharCount);
        if(iResult == 0)
        {
          iCharCount *= 2;
          byte[] bReaderList = new byte[iCharCount];
          System.Threading.Thread.Sleep(100);
          iResult = SCardListReaders(m_hContext, group, bReaderList, out iCharCount);
          if(iResult == 0)
          {
            //
            // readers listed, make array and return success
            //
            string cReaderList = System.Text.UnicodeEncoding.Unicode.GetString(bReaderList, 0, bReaderList.Length);
            char[] delimiter = new char[1];
            delimiter[0] = Convert.ToChar(0);
            m_sReaders = cReaderList.Split(delimiter);
            eError = Error.None;
          }
          else
          {
            //
            // error listing readers, set error code
            //
            eError = Error.ListReaders;
            m_hContext = INVALID_HANDLE_VALUE;
            m_sReaders = null;
          }
        }
        else
        {
          //
          // error listing readers, set error code
          //
          eError = Error.ListReaders;
          m_hContext = INVALID_HANDLE_VALUE;
          m_sReaders = null;
        }
      }
      else
      {
        //
        // error establishing context, set error code and allow retry
        //
        eError = Error.EstablishContext;
        m_hContext = INVALID_HANDLE_VALUE;
        m_sReaders = null;
      }
    }
    else
    {
      //
      // already have a context, can't re-init, set error code
      //
      eError = Error.AlreadyInit;
    }

    //
    // return value is error set above
    //
    return eError;
  }
  #endregion

  #region public Error SCRConnectReader(uint uiShare, uint uiProtocol, uint uiReader)
  /// <summary>
  /// Attempts to connect to card in the specified card reader.
  /// </summary>
  /// <param name="uiShare">Sharing mode.  \ref SCARD_SHARE_EXCLUSIVE,
  /// \ref SCARD_SHARE_SHARED or \ref SCARD_SHARE_DIRECT.</param>
  /// <param name="uiProtocol">Acceptable protocols.  Bitmask of
  /// \ref SCARD_PROTOCOL_T0 and \ref SCARD_PROTOCOL_T1.</param>
  /// <param name="uiReader">Reader index (0-based).  Must be <= number of readers in system.</param>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  /// \see SCardConnect
  public Error SCRConnectReader(uint uiShare, uint uiProtocol, uint uiReader)
  {
    Error eError = Error.Unknown;

    //
    // first check that a valid context exists
    //
    if(m_hContext != INVALID_HANDLE_VALUE)
    {
      //
      // context OK, make sure we've got readers and the specified reader is OK
      //
      if((m_sReaders != null) && (m_sReaders.Length > 0) && (uiReader < m_sReaders.Length))
      {
        //
        // now make sure we're not already connected
        //
        if(m_hCard == INVALID_HANDLE_VALUE)
        {
          //
          // try for connection
          //
          int iResult = SCardConnect(m_hContext, m_sReaders[uiReader], uiShare, uiProtocol, ref m_hCard, ref m_uiActiveProtocol);
          if(iResult == 0)
          {
            //
            // connection OK, set no error
            //
            eError = Error.None;
            m_uiReader = uiReader;
          }
          else
          {
            //
            // error from connection, check for 'no card' or other error
            //
            unchecked
            {
              if(iResult == (int)0x8010000C)
              {
                eError = Error.NoCard;
              }
              else
              {
                eError = Error.Connect;
              }
            }
            m_hCard = INVALID_HANDLE_VALUE;
            m_uiActiveProtocol = SCARD_PROTOCOL_UNDEFINED;
          }
        }
        else
        {
          //
          // already connected, set error code
          //
          eError = Error.AlreadyConnected;
        }
      }
      else
      {
        //
        // need to list readers, set error code
        //
        eError = Error.NoReaders;
      }
    }
    else
    {
      //
      // need to establish context, set error code
      //
      eError = Error.NoContext;
    }

    //
    // error code is set above
    //
    return eError;
  }
  #endregion

  #region public Error SCRConnect(uint uiShare, uint uiProtocol)
  /// <summary>
  /// Attempts to connect to card in first card reader.
  /// </summary>
  /// <param name="uiShare">Sharing mode.  \ref SCARD_SHARE_EXCLUSIVE,
  /// \ref SCARD_SHARE_SHARED or \ref SCARD_SHARE_DIRECT.</param>
  /// <param name="uiProtocol">Acceptable protocols.  Bitmask of
  /// \ref SCARD_PROTOCOL_T0 and \ref SCARD_PROTOCOL_T1.</param>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  /// \see SCardConnect
  public Error SCRConnect(uint uiShare, uint uiProtocol)
  {
    return SCRConnectReader(uiShare, uiProtocol, 1);
  }
  #endregion

  #region public Error SCRStatus()
  /// <summary>
  /// Queries the status of the SCR interface.  Use the \ref SCRState and
  /// \ref SCRATRData properties to read the resultant information if this
  /// function returns success.
  /// </summary>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  /// \see SCardStatus
  public Error SCRStatus()
  {
    Error eError = Error.Unknown;

    if(m_hCard != INVALID_HANDLE_VALUE)
    {
      if(m_uiReader <= m_sReaders.Length)
      {
        string szReaderName = m_sReaders[m_uiReader] + "  ";
        uint cchReaderLen = (uint)szReaderName.Length;
        uint dwProtocol=0, dwATRLength;

        dwATRLength = 32;
        IntPtr pbAtr = new IntPtr();
        pbAtr = Marshal.AllocHGlobal((int)dwATRLength);
        int iResult = SCardStatus(m_hCard, szReaderName, ref cchReaderLen, ref m_uiState, ref dwProtocol, pbAtr, ref dwATRLength);
        if(iResult == 0)
        {
          //
          // save off ATR data and mark no error
          //
          m_pui8ATRData = new byte[dwATRLength];
          Marshal.Copy(pbAtr, m_pui8ATRData, 0, (int)dwATRLength);
          eError = Error.None;
        }
        else
        {
          //
          // some error from card status call, set error code
          //
          eError = Error.CardStatus;
        }
      }
      else
      {
        //
        // illegal reader value, set error code
        //
        eError = Error.BadParameter;
      }
    }
    else
    {
      //
      // not connected to card, set error code
      //
      eError = Error.NotConnected;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SCRDisconnect(uint uiDisposition)
  /// <summary>
  /// Attempt to disconnect from the currently connected card.
  /// </summary>
  /// <param name="uiDisposition">Action to take when disconnecting from card.
  /// \ref SCARD_LEAVE_CARD, \ref SCARD_RESET_CARD, \ref SCARD_UNPOWER_CARD
  /// or \ref SCARD_EJECT_CARD.</param>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  /// \see SCardDisconnect
  public Error SCRDisconnect(uint uiDisposition)
  {
    Error eError = Error.Unknown;

    if(m_hCard != INVALID_HANDLE_VALUE)
    {
      int iResult = SCardDisconnect(m_hCard, uiDisposition);
      if(iResult == 0)
      {
        //
        // success, mark no error
        //
        eError = Error.None;
      }
      else
      {
        //
        // some error from disconnect, set error code
        //
        eError = Error.Disconnect;
      }
      m_hCard = INVALID_HANDLE_VALUE;
      m_uiActiveProtocol = SCARD_PROTOCOL_UNDEFINED;
      m_uiState = SCARD_UNKNOWN;
      m_pui8ATRData = null;
    }
    else
    {
      //
      // not connected, set error code
      //
      eError = Error.NotConnected;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public Error SCRDeinit()
  /// <summary>
  /// Attempts de-initialization of the SCR interface.
  /// </summary>
  /// <returns>Error code as defined in \ref CN3PIV::Error enumeration.</returns>
  /// \see SCardReleaseContext
  public Error SCRDeinit()
  {
    Error eError = Error.Unknown;

    //
    // check a valid context to release
    //
    if(m_hContext != INVALID_HANDLE_VALUE)
    {
      //
      // disconnect just in case we're connected
      //
      SCRDisconnect(SCARD_LEAVE_CARD);

      //
      // now release the current context
      //
      int iResult = SCardReleaseContext(m_hContext);
      if(iResult == 0)
      {
        eError = Error.None;
      }
      else
      {
        eError = Error.ReleaseContext;
      }
      m_hContext = INVALID_HANDLE_VALUE;
      m_sReaders = null;
    }
    else
    {
      //
      // no context to release, set error code
      //
      eError = Error.NoContext;
    }

    //
    // return value is error code set above
    //
    return eError;
  }
  #endregion

  #region public string SCRReaderName(int iIndex)
  /// <summary>
  /// \brief Used to retrieve reader names based on index.
  /// </summary>
  /// <param name="iIndex">Index of reader to return name, < SCRNumReaders.</param>
  /// <returns>Name of reader if index valid and reader exists at index, "" if index valid
  /// but no reader exists at index, null if SCR not init'd.</returns>
  public string SCRReaderName(int iIndex)
  {
    string name=null;
    if(m_sReaders != null)
    {
      name = "";
      if(iIndex < m_sReaders.Length)
      {
        name = m_sReaders[iIndex];
      }
    }
    return name;
  }
  #endregion

  #region public bool SCRPower_OpenReader(string strReaderName, ref int hReader)
  /// <summary>
  /// Opens a handle to the specified reader for use other functions.
  /// The handle is stored in the variable pointed by hReader
  /// </summary>
  /// <param name="strReaderName">Name of reader to open.</param>
  /// <param name="hReader">Output handle to open reader if function succeeds.</param>
  /// <returns>True if successful, false otherwise.</returns>
  public bool SCRPower_OpenReader(string strReaderName, ref int hReader)
  {
    return false;
    //return OKPWR_OpenReader(strReaderName, ref hReader);
  }
  #endregion

  #region public bool SCRPower_CloseReader(int hReader)
  /// <summary>
  /// Closes the handle obtained with \ref SCRPower_OpenReader.
  /// </summary>
  /// <param name="hReader">Handle returned from \ref SCRPower_OpenReader.</param>
  /// <returns>True if successful, false otherwise.</returns>
  public bool SCRPower_CloseReader(int hReader)
  {
    return false;
    //return OKPWR_CloseReader(hReader);
  }
  #endregion

  #region public bool SCRPower_AntennaOff(int hReader)
  /// <summary>
  /// Turns antenna off to reduce current.
  /// </summary>
  /// <param name="hReader">Handle returned from \ref SCRPower_OpenReader.</param>
  /// <returns>True if successful, false otherwise.</returns>
  public bool SCRPower_AntennaOff(int hReader)
  {
    return false;
    //return OKPWR_AntennaOff(hReader);
  }
  #endregion

  #region public bool SCRPower_AntennaOn(int hReader)
  /// <summary>
  /// Turns antenna on.
  /// </summary>
  /// <param name="hReader">Handle returned from \ref SCRPower_OpenReader.</param>
  /// <returns>True if successful, false otherwise.</returns>
  public bool SCRPower_AntennaOn(int hReader)
  {
    return false;
    //return OKPWR_AntennaOn(hReader);
  }
  #endregion

  #region public bool SCRPower_IdleOn(int hReader, byte uchLedMode)
  /// <summary>
  /// Turns idle mode on to reduce current.  To achive a worth mentioning current
  /// reduction in idle mode the anntena has to be turned off.  Depending on the
  /// LED mode parameter the current consumption of the device will be additionally
  /// reduced.
  /// </summary>
  /// <param name="hReader">Handle returned from \ref SCRPower_OpenReader.</param>
  /// <param name="uchLedMode">LED mode.</param>
  /// <returns>True if successful, false otherwise.</returns>
  public bool SCRPower_IdleOn(int hReader, byte uchLedMode)
  {
    return false;
    //return OKPWR_IdleOn(hReader, uchLedMode);
  }
  #endregion

  #region public bool SCRPower_IdleOff(int hReader)
  /// <summary>
  /// Turns idle mode off.
  /// </summary>
  /// <param name="hReader">Handle returned from \ref SCRPower_OpenReader.</param>
  /// <returns>True if successful, false otherwise.</returns>
  public bool SCRPower_IdleOff(int hReader)
  {
    return false;
    //return OKPWR_IdleOff(hReader);
  }
  #endregion

  #region public bool SCRPower_ReaderOn(int hReader)
  /// <summary>
  /// Turns reader on.
  /// </summary>
  /// <param name="hReader">Handle returned from \ref SCRPower_OpenReader.</param>
  /// <returns>True if successful, false otherwise.</returns>
  public bool SCRPower_ReaderOn(int hReader)
  {
    return false;
    //return OKPWR_ReaderOn(hReader);
  }
  #endregion

  #region public bool SCRPower_ReaderOff(int hReader)
  /// <summary>
  /// Turns reader off to reduce current.
  /// </summary>
  /// <param name="hReader">Handle returned from \ref SCRPower_OpenReader.</param>
  /// <returns>True if successful, false otherwise.</returns>
  public bool SCRPower_ReaderOff(int hReader)
  {
    return false;
    //return OKPWR_ReaderOff(hReader);
  }
  #endregion

  #region void OnSagemMessage(ParseableMessage msg)
  /// <summary>
  /// \brief Internal callback, registered to m_sagemPort.OnMessage.
  /// \details This callback is called on the serial port read thread
  ///          when a Sagem message is parsed.  It uses the Form reference
  ///          set in the CN3PIV::CN3PIV(Form form) to invoke the \ref
  ///          HandleSagemMessage delegate on the Form's UI thread.  Then,
  ///          depending on the message type, \ref HandleILVGetDescriptor,
  ///          \ref HandleILVAsynchronousMessage, \ref HandleILVEnroll,
  ///          \ref HandleILVVerifyMatch and / or \ref HandleILVOther
  ///          will also be invoked.
  /// </summary>
  /// <param name="msg">MSUSBMessage parsed from Sagem device.</param>
  void OnSagemMessage(ParseableMessage msg)
  {
    //
    // we will need an object[] array to invoke some delegates, so make
    // that and invoke the generic 'handle message' delegate.
    //
    object[] msgArray = new object[] {msg};
    m_form.BeginInvoke(HandleSagemMessage, msgArray);

    //
    // now invoke type-specific delegate based on message 'I' value
    //
    switch(((MSUSBMessage)(msg)).I)
    {
      case MSUSBMessage.ILV.GET_DESCRIPTOR:
        m_form.BeginInvoke(HandleILVGetDescriptor, msgArray);
        break;

      case MSUSBMessage.ILV.ID_ASYNCHRONOUS_MESSAGE:
        m_form.BeginInvoke(HandleILVAsynchronousMessage, msgArray);
        break;

      case MSUSBMessage.ILV.ENROLL:
        m_form.BeginInvoke(HandleILVEnroll, msgArray);
        break;

      case MSUSBMessage.ILV.VERIFY_MATCH:
        m_form.BeginInvoke(HandleILVVerifyMatch, msgArray);
        break;

      default:
        m_form.BeginInvoke(HandleILVOther, msgArray);
        break;
    }
  }
  #endregion

  #region void OnSagemReadException(Exception ex)
  /// <summary>
  /// \brief Internal callback, registered to m_sagemPort.OnException.
  /// \details This callback is called on the serial port read thread
  ///          when the Sagem device serial port object throws an exception.
  ///          It uses the Form reference set in the
  ///          CN3PIV::CN3PIV(Form form) to invoke the \ref
  ///          HandleSagemException delegate on the Form's UI thread.
  /// </summary>
  /// <param name="ex">Exception thrown by Sagem serial port object.</param>
  void OnSagemReadException(Exception ex)
  {
    if(m_form.InvokeRequired)
    {
      m_form.BeginInvoke(HandleSagemReadException, new object[] {ex});
    }
    else
    {
      HandleSagemReadException(ex);
    }
  }
  #endregion

  #region void OnMSRMessage(ParseableMessage msg)
  /// <summary>
  /// \brief Internal callback, registered to m_msrPort.OnMessage.
  /// \details This callback is called on the serial port read thread
  ///          when an MSR message is parsed.  It uses the Form reference
  ///          set in the CN3PIV::CN3PIV(Form form) to invoke the \ref
  ///          HandleMSRMessage delegate on the Form's UI thread.  Then,
  ///          depending on the message type, \ref HandleMSRMessagePing,
  ///          \ref HandleMSRMessageTrack1Data, \ref HandleMSRMessageTrack2Data
  ///          and/or \ref HandleMSRMessageTrack3Data will also be invoked.
  /// </summary>
  /// <param name="msg"></param>
  void OnMSRMessage(ParseableMessage msg)
  {
    //
    // we will need an object[] array to invoke some delegates, so make
    // that and invoke the generic 'handle message' delegate.
    //
    object[] msgArray = new object[] {msg};
    m_form.BeginInvoke(HandleMSRMessage, msgArray);

    //
    // now invoke type-specific delegate based on message 'Port' value
    //
    switch(((MDPMessage)msg).Port)
    {
      case (byte)MSRPort.Ping:
      {
        m_form.BeginInvoke(HandleMSRMessagePing, msgArray);
      }
      break;

      case (byte)MSRPort.DataClear:
      {
        m_form.BeginInvoke(HandleMSRMessageDataClear, msgArray);
      }
      break;

      case (byte)MSRPort.Power:
      {
        m_form.BeginInvoke(HandleMSRMessagePower, msgArray);
      }
      break;

      case (byte)MSRPort.Track1:
      {
        m_form.BeginInvoke(HandleMSRMessageTrack1Data, msgArray);
      }
      break;

      case (byte)MSRPort.Track2:
      {
        m_form.BeginInvoke(HandleMSRMessageTrack2Data, msgArray);
      }
      break;

      case (byte)MSRPort.Track3:
      {
        m_form.BeginInvoke(HandleMSRMessageTrack3Data, msgArray);
      }
      break;

      default:
        MessageBox.Show("Port " + ((MDPMessage)msg).Port.ToString("X2"), "OnMSRMessage");
        break;
    }
  }
  #endregion

  #region void OnMSRReadException(Exception ex)
  /// <summary>
  /// \brief Internal callback, registered to m_msrPort.OnException.
  /// \details This callback is called on the serial port read thread
  ///          when the MSR device serial port object throws an exception.
  ///          It uses the Form reference set in the
  ///          CN3PIV::CN3PIV(Form form) to invoke the \ref
  ///          HandleMSRException delegate on the Form's UI thread.
  /// </summary>
  /// <param name="ex">Exception thrown by MSR serial port object.</param>
  void OnMSRReadException(Exception ex)
  {
    if(m_form.InvokeRequired)
    {
      m_form.BeginInvoke(HandleMSRReadException, new object[] {ex});
    }
    else
    {
      HandleMSRReadException(ex);
    }
  }
  #endregion

  #endregion

  #region Properties

  #region public string SagemPortName
  /// <summary>
  /// \brief Gets and sets the Sagem serial port name.
  /// \details The serial port name should be in the "COMx" format, "COM1" through "COM99".
  /// </summary>
  #warning <Use Port Object Property>
  public string SagemPortName
  {
    get
    {
      return m_sagemPortName;
    }
    set
    {
      m_sagemPortName = value;
    }
  }
  #endregion

  #region public string MSRPortName
  /// <summary>
  /// \brief Gets and sets the MSR serial port name.
  /// \details The serial port name should be in the "COMx" format, "COM1" through "COM99".
  /// </summary>
  #warning <Use Port Object Property>
  public string MSRPortName
  {
    get
    {
      return m_msrPortName;
    }
    set
    {
      m_msrPortName = value;
    }
  }
  #endregion

  #region public bool SagemIsOpen
  /// <summary>
  /// Returns true if the Sagem serial port is currently open, false otherwise.
  /// </summary>
  public bool SagemIsOpen
  {
    get
    {
      bool bIsOpen=false;
      if(m_sagemPort != null)
      {
        bIsOpen = m_sagemPort.IsOpen;
      }
      return bIsOpen;
    }
  }
  #endregion

  #region public bool MSRIsOpen
  /// <summary>
  /// Returns true if the MSR serial port is currently open, false otherwise.
  /// </summary>
  public bool MSRIsOpen
  {
    get
    {
      bool bIsOpen=false;
      if(m_msrPort != null)
      {
        bIsOpen = m_msrPort.IsOpen;
      }
      return bIsOpen;
    }
  }
  #endregion

  #region public bool SCRIsInit
  /// <summary>
  /// Returns true if the SCR interface has been initialized.
  /// </summary>
  public bool SCRIsInit
  {
    get
    {
      return m_hContext == INVALID_HANDLE_VALUE ? false : true;
    }
  }
  #endregion

  #region public bool SCRIsConnected
  /// <summary>
  /// Returns true if the SCR interface is currently connected to a card.
  /// </summary>
  public bool SCRIsConnected
  {
    get
    {
      return m_hCard == INVALID_HANDLE_VALUE ? false : true;
    }
  }
  #endregion

  #region public uint SCRActiveProtocol
  /// <summary>
  /// Returns the protocol of the currently active card.
  /// </summary>
  public uint SCRActiveProtocol
  {
    get
    {
      return m_uiActiveProtocol;
    }
  }
  #endregion

  #region public byte[] SCRATRData
  /// <summary>
  /// Returns the ATR data from the currently connected card.
  /// </summary>
  public byte[] SCRATRData
  {
    get
    {
      byte[] pui8ATRData=null;
      if(m_pui8ATRData != null)
      {
        pui8ATRData = new byte[m_pui8ATRData.Length];
        for(int i=0; i<m_pui8ATRData.Length; i++)
        {
          pui8ATRData[i] = m_pui8ATRData[i];
        }
      }
      return pui8ATRData;
    }
  }
  #endregion

  #region public uint SCRState
  /// <summary>
  /// Returns the current state of the SCR card interface connection.
  /// </summary>
  public uint SCRState
  {
    get
    {
      return m_uiState;
    }
  }
  #endregion

  #region public Error RegistryError
  /// <summary>
  /// Returns the error code set when the registry is read in Init().
  /// </summary>
  public Error RegistryError
  {
    get
    {
      return m_eRegistryError;
    }
  }
  #endregion

  #region public int SCRNumReaders
  /// <summary>
  /// Returns the number of SCR readers in the system, -1 if SCR is not currently init'd.
  /// </summary>
  public int SCRNumReaders
  {
    get
    {
      int i=-1;
      if(m_sReaders != null)
      {
        i = m_sReaders.Length;
      }
      return i;
    }
  }
  #endregion

#warning <Remove This>
  public int MSRByteCount
  {
    get
    {
      int iCount=-1;
      if(m_msrPort != null)
      {
        iCount = m_msrPort.m_iByteCount;
      }
      return iCount;
    }
    set
    {
      if(m_msrPort != null)
      {
        m_msrPort.m_iByteCount = 0;
      }
    }
  }

  #endregion
}
#endregion
