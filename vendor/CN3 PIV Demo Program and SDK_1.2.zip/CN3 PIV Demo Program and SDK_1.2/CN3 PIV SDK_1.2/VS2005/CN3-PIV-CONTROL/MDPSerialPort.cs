//
////////////////////////////////////////////////////////////////////////////////
//
/// \file MDPSerialPort.cs
/// \brief Implementation file for the MDPSerialPort object.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009 Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//
using System;
using System.Diagnostics;
using System.IO;
using System.IO.Ports;

/// <summary>
/// MDPSerialPort is a class which parses and sends MDP messages over a serial
/// port.
/// </summary>
public class MDPSerialPort : ParsingSerialPort
{
  #region Constructors

  #region public MDPSerialPort()
  /// <summary>
  /// Default constrcuctor creates serial port on COM1 at 9600.
  /// </summary>
  public MDPSerialPort()
  {
    m_oParser = new MDPMessageParser();
  }
  #endregion

  #region public MDPSerialPort(string portName, int baudRate)
  /// <summary>
  /// Full-valued constrcuctor sets serial port and baud rate.
  /// </summary>
  /// <param name="portName">Port name, "COMx".</param>
  /// <param name="baudRate">Baud rate in bits per second.</param>
  public MDPSerialPort(string portName, int baudRate) : base(portName, baudRate)
  {
    m_oParser = new MDPMessageParser();
  }
  #endregion

  #endregion

  #region Methods

  #region public ParsingSerialPort.Error WriteMDP(byte ui8Port, byte[] pui8Data)
  /// <summary>
  /// Write generic MDP message to the serial port.
  /// </summary>
  /// <param name="ui8Port">Port value in MDP message.</param>
  /// <param name="pui8Data">Data bytes in MDP mesage, null => 0 data bytes</param>
  /// <returns>Error code, one of ParsingSerialPort.Error</returns>
  public ParsingSerialPort.Error WriteMDP(byte ui8Port, byte[] pui8Data)
  {
    ParsingSerialPort.Error eError=ParsingSerialPort.Error.Unknown;

    if(m_oPort.IsOpen)
    {
      byte[] pui8SyncPortLength = new byte[3];
      pui8SyncPortLength[MDPMessage.IndexSyncByte] = MDPMessage.SyncByte;
      pui8SyncPortLength[MDPMessage.IndexPort] = ui8Port;
      pui8SyncPortLength[MDPMessage.IndexLength] = 0;
      if(pui8Data != null)
      {
        pui8SyncPortLength[MDPMessage.IndexLength] = (byte)(pui8Data.Length);
      }
      try
      {
        m_oPort.Write(pui8SyncPortLength, 0, 3);
        if(pui8Data != null)
        {
          m_oPort.Write(pui8Data, 0, pui8Data.Length);
        }
        m_oPort.BaseStream.Flush();
        eError = ParsingSerialPort.Error.None;
      }
      catch
      {
        try
        {
          m_oPort.Close();
        }
        catch
        {
        }
        eError = ParsingSerialPort.Error.Exception;
      }
    }
    else
    {
      eError = ParsingSerialPort.Error.NotOpen;
    }

    return eError;
  }
  #endregion

  #endregion
}
