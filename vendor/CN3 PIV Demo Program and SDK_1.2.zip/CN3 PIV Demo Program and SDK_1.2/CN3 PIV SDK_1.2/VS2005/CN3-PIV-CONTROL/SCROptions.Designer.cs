partial class SCROptions
{
  /// <summary>
  /// Required designer variable.
  /// </summary>
  private System.ComponentModel.IContainer components = null;
  private System.Windows.Forms.MainMenu mainMenu1;

  /// <summary>
  /// Clean up any resources being used.
  /// </summary>
  /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
  protected override void Dispose(bool disposing)
  {
    if (disposing && (components != null))
    {
      components.Dispose();
    }
    base.Dispose(disposing);
  }

  #region Windows Form Designer generated code

  /// <summary>
  /// Required method for Designer support - do not modify
  /// the contents of this method with the code editor.
  /// </summary>
  private void InitializeComponent()
  {
    this.mainMenu1 = new System.Windows.Forms.MainMenu();
    this.label1 = new System.Windows.Forms.Label();
    this.label8 = new System.Windows.Forms.Label();
    this.ContactAntennaOnCheckBox = new System.Windows.Forms.CheckBox();
    this.ContactIdleModeCheckBox = new System.Windows.Forms.CheckBox();
    this.ContactReaderOnCheckBox = new System.Windows.Forms.CheckBox();
    this.ContactlessReaderOnCheckBox = new System.Windows.Forms.CheckBox();
    this.ContactlessIdleModeCheckBox = new System.Windows.Forms.CheckBox();
    this.ContactlessAntennaOnCheckBox = new System.Windows.Forms.CheckBox();
    this.OKButton = new System.Windows.Forms.Button();
    this.CancelButton = new System.Windows.Forms.Button();
    this.SuspendLayout();
    // 
    // label1
    // 
    this.label1.Location = new System.Drawing.Point(3, 9);
    this.label1.Name = "label1";
    this.label1.Size = new System.Drawing.Size(234, 20);
    this.label1.Text = "Contact Reader";
    // 
    // label8
    // 
    this.label8.Location = new System.Drawing.Point(3, 128);
    this.label8.Name = "label8";
    this.label8.Size = new System.Drawing.Size(234, 20);
    this.label8.Text = "Contactless Reader";
    // 
    // ContactAntennaOnCheckBox
    // 
    this.ContactAntennaOnCheckBox.Location = new System.Drawing.Point(3, 32);
    this.ContactAntennaOnCheckBox.Name = "ContactAntennaOnCheckBox";
    this.ContactAntennaOnCheckBox.Size = new System.Drawing.Size(100, 20);
    this.ContactAntennaOnCheckBox.TabIndex = 15;
    this.ContactAntennaOnCheckBox.Text = "Antenna On";
    // 
    // ContactIdleModeCheckBox
    // 
    this.ContactIdleModeCheckBox.Location = new System.Drawing.Point(3, 58);
    this.ContactIdleModeCheckBox.Name = "ContactIdleModeCheckBox";
    this.ContactIdleModeCheckBox.Size = new System.Drawing.Size(100, 20);
    this.ContactIdleModeCheckBox.TabIndex = 16;
    this.ContactIdleModeCheckBox.Text = "Idle Mode";
    // 
    // ContactReaderOnCheckBox
    // 
    this.ContactReaderOnCheckBox.Location = new System.Drawing.Point(3, 84);
    this.ContactReaderOnCheckBox.Name = "ContactReaderOnCheckBox";
    this.ContactReaderOnCheckBox.Size = new System.Drawing.Size(100, 20);
    this.ContactReaderOnCheckBox.TabIndex = 17;
    this.ContactReaderOnCheckBox.Text = "Reader On";
    // 
    // ContactlessReaderOnCheckBox
    // 
    this.ContactlessReaderOnCheckBox.Location = new System.Drawing.Point(3, 203);
    this.ContactlessReaderOnCheckBox.Name = "ContactlessReaderOnCheckBox";
    this.ContactlessReaderOnCheckBox.Size = new System.Drawing.Size(100, 20);
    this.ContactlessReaderOnCheckBox.TabIndex = 20;
    this.ContactlessReaderOnCheckBox.Text = "Reader On";
    // 
    // ContactlessIdleModeCheckBox
    // 
    this.ContactlessIdleModeCheckBox.Location = new System.Drawing.Point(3, 177);
    this.ContactlessIdleModeCheckBox.Name = "ContactlessIdleModeCheckBox";
    this.ContactlessIdleModeCheckBox.Size = new System.Drawing.Size(100, 20);
    this.ContactlessIdleModeCheckBox.TabIndex = 19;
    this.ContactlessIdleModeCheckBox.Text = "Idle Mode";
    // 
    // ContactlessAntennaOnCheckBox
    // 
    this.ContactlessAntennaOnCheckBox.Location = new System.Drawing.Point(3, 151);
    this.ContactlessAntennaOnCheckBox.Name = "ContactlessAntennaOnCheckBox";
    this.ContactlessAntennaOnCheckBox.Size = new System.Drawing.Size(100, 20);
    this.ContactlessAntennaOnCheckBox.TabIndex = 18;
    this.ContactlessAntennaOnCheckBox.Text = "Antenna On";
    // 
    // OKButton
    // 
    this.OKButton.DialogResult = System.Windows.Forms.DialogResult.OK;
    this.OKButton.Location = new System.Drawing.Point(3, 245);
    this.OKButton.Name = "OKButton";
    this.OKButton.Size = new System.Drawing.Size(72, 20);
    this.OKButton.TabIndex = 23;
    this.OKButton.Text = "OK";
    // 
    // CancelButton
    // 
    this.CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
    this.CancelButton.Location = new System.Drawing.Point(165, 245);
    this.CancelButton.Name = "CancelButton";
    this.CancelButton.Size = new System.Drawing.Size(72, 20);
    this.CancelButton.TabIndex = 24;
    this.CancelButton.Text = "Cancel";
    // 
    // SCROptions
    // 
    this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
    this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
    this.AutoScroll = true;
    this.ClientSize = new System.Drawing.Size(240, 268);
    this.Controls.Add(this.CancelButton);
    this.Controls.Add(this.OKButton);
    this.Controls.Add(this.ContactlessReaderOnCheckBox);
    this.Controls.Add(this.ContactlessIdleModeCheckBox);
    this.Controls.Add(this.ContactlessAntennaOnCheckBox);
    this.Controls.Add(this.ContactReaderOnCheckBox);
    this.Controls.Add(this.ContactIdleModeCheckBox);
    this.Controls.Add(this.ContactAntennaOnCheckBox);
    this.Controls.Add(this.label8);
    this.Controls.Add(this.label1);
    this.Menu = this.mainMenu1;
    this.Name = "SCROptions";
    this.Text = "SCROptions";
    this.ResumeLayout(false);

  }

  #endregion

  private System.Windows.Forms.Label label1;
  private System.Windows.Forms.Label label8;
  public System.Windows.Forms.CheckBox ContactAntennaOnCheckBox;
  public System.Windows.Forms.CheckBox ContactIdleModeCheckBox;
  public System.Windows.Forms.CheckBox ContactReaderOnCheckBox;
  public System.Windows.Forms.CheckBox ContactlessReaderOnCheckBox;
  public System.Windows.Forms.CheckBox ContactlessIdleModeCheckBox;
  public System.Windows.Forms.CheckBox ContactlessAntennaOnCheckBox;
  private System.Windows.Forms.Button OKButton;
  private System.Windows.Forms.Button CancelButton;
}
