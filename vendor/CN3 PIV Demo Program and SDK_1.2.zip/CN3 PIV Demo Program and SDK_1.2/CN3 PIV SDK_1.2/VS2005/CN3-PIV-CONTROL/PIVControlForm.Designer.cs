using Microsoft.Win32;
partial class PIVControlForm
{
  /// <summary>
  /// Required designer variable.
  /// </summary>
  private System.ComponentModel.IContainer components = null;

  /// <summary>
  /// Clean up any resources being used.
  /// </summary>
  /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
  protected override void Dispose(bool disposing)
  {
    if (disposing && (components != null))
    {
      components.Dispose();
    }
    base.Dispose(disposing);
  }

  #region Windows Form Designer generated code

  /// <summary>
  /// Required method for Designer support - do not modify
  /// the contents of this method with the code editor.
  /// </summary>
  private void InitializeComponent()
  {
    System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PIVControlForm));
    this.DBOpenCloseCheckBox = new System.Windows.Forms.CheckBox();
    this.DBSerialComboBox = new System.Windows.Forms.ComboBox();
    this.DebugTabPage = new System.Windows.Forms.TabPage();
    this.DebugClearButton = new System.Windows.Forms.Button();
    this.DebugCheckBox = new System.Windows.Forms.CheckBox();
    this.DebugTextBox = new System.Windows.Forms.TextBox();
    this.TabControl = new System.Windows.Forms.TabControl();
    this.PIVTabPage = new System.Windows.Forms.TabPage();
    this.PIVFPRSIPPictureBox = new System.Windows.Forms.PictureBox();
    this.PIVFPRFlipCheckBox = new System.Windows.Forms.CheckBox();
    this.label13 = new System.Windows.Forms.Label();
    this.label12 = new System.Windows.Forms.Label();
    this.label11 = new System.Windows.Forms.Label();
    this.PIVSCRStatusDataLabel = new System.Windows.Forms.Label();
    this.PIVSCRProtocolDataLabel = new System.Windows.Forms.Label();
    this.PIVSCRStatusLabel = new System.Windows.Forms.Label();
    this.PIVSCRProtocolLabel = new System.Windows.Forms.Label();
    this.PIVSCRATRDataTextBox = new System.Windows.Forms.TextBox();
    this.PIVSCRATRLabel = new System.Windows.Forms.Label();
    this.PIVMSRFWVersionLabel = new System.Windows.Forms.Label();
    this.PIVMSRFWLabel = new System.Windows.Forms.Label();
    this.PIVFPRClearDBButton = new System.Windows.Forms.Button();
    this.PIVFPRStatusLabel = new System.Windows.Forms.Label();
    this.PIVFPRNameLabel = new System.Windows.Forms.Label();
    this.PIVFPRTimeoutUpDown = new System.Windows.Forms.NumericUpDown();
    this.PIVFPRTimeoutCheckbox = new System.Windows.Forms.CheckBox();
    this.PIVFPRNameTextBox = new System.Windows.Forms.TextBox();
    this.PIVFPRCancelButton = new System.Windows.Forms.Button();
    this.PIVFPRGoButton = new System.Windows.Forms.Button();
    this.PIVFPREnrollRadioButton = new System.Windows.Forms.RadioButton();
    this.PIVFPRVerifyRadioButton = new System.Windows.Forms.RadioButton();
    this.PIVFPRFWVersionLabel = new System.Windows.Forms.Label();
    this.PIVFPRFWLabel = new System.Windows.Forms.Label();
    this.PIVFPRImagePictureBox = new System.Windows.Forms.PictureBox();
    this.PIVMSRTrack3DataTextBox = new System.Windows.Forms.TextBox();
    this.PIVMSRTrack2DataTextBox = new System.Windows.Forms.TextBox();
    this.PIVMSRTrack1DataTextBox = new System.Windows.Forms.TextBox();
    this.PIVMSRTrack3DataLabel = new System.Windows.Forms.Label();
    this.PIVMSRTrack2DataLabel = new System.Windows.Forms.Label();
    this.PIVMSRTrack1DataLabel = new System.Windows.Forms.Label();
    this.PIVSCRCheckBox = new System.Windows.Forms.CheckBox();
    this.PIVFPRCheckBox = new System.Windows.Forms.CheckBox();
    this.PIVMSRCheckBox = new System.Windows.Forms.CheckBox();
    this.AboutTabPage = new System.Windows.Forms.TabPage();
    this.AboutCLCheckBox = new System.Windows.Forms.CheckBox();
    this.AboutDeinitButton = new System.Windows.Forms.Button();
    this.AboutInitButton = new System.Windows.Forms.Button();
    this.AboutAntennaCheckBox = new System.Windows.Forms.CheckBox();
    this.AboutIdleCheckBox = new System.Windows.Forms.CheckBox();
    this.AboutReaderCheckBox = new System.Windows.Forms.CheckBox();
    this.AboutIdleButton = new System.Windows.Forms.Button();
    this.AboutReaderButton = new System.Windows.Forms.Button();
    this.AboutAntennaButton = new System.Windows.Forms.Button();
    this.AboutCloseButton = new System.Windows.Forms.Button();
    this.AboutOpenButton = new System.Windows.Forms.Button();
    this.AboutOKPWRCEDLLVersionLabel = new System.Windows.Forms.Label();
    this.AboutWSQDLLVersionLabel = new System.Windows.Forms.Label();
    this.AboutPortsLabel = new System.Windows.Forms.Label();
    this.AboutPortsButton = new System.Windows.Forms.Button();
    this.label10 = new System.Windows.Forms.Label();
    this.label9 = new System.Windows.Forms.Label();
    this.label8 = new System.Windows.Forms.Label();
    this.label4 = new System.Windows.Forms.Label();
    this.MSRTabPage = new System.Windows.Forms.TabPage();
    this.PowerSaveButton = new System.Windows.Forms.Button();
    this.PowerGetButton = new System.Windows.Forms.Button();
    this.Power5VStatusLabel = new System.Windows.Forms.Label();
    this.PowerCCStatusLabel = new System.Windows.Forms.Label();
    this.PowerFPStatusLabel = new System.Windows.Forms.Label();
    this.PowerSetButton = new System.Windows.Forms.Button();
    this.PowerCCCheckBox = new System.Windows.Forms.CheckBox();
    this.Power5VCheckBox = new System.Windows.Forms.CheckBox();
    this.PowerFPCheckBox = new System.Windows.Forms.CheckBox();
    this.MSRRefreshButton = new System.Windows.Forms.Button();
    this.MSRByteCountResetButton = new System.Windows.Forms.Button();
    this.MSRByteCountLabel = new System.Windows.Forms.Label();
    this.MSRByteCountButton = new System.Windows.Forms.Button();
    this.MSRPingButton = new System.Windows.Forms.Button();
    this.MSRClrLastButton = new System.Windows.Forms.Button();
    this.MSRGetLastButton = new System.Windows.Forms.Button();
    this.MSRTrack3DataTextBox = new System.Windows.Forms.TextBox();
    this.MSRTrack2DataTextBox = new System.Windows.Forms.TextBox();
    this.MSRTrack1DataTextBox = new System.Windows.Forms.TextBox();
    this.label7 = new System.Windows.Forms.Label();
    this.label6 = new System.Windows.Forms.Label();
    this.label3 = new System.Windows.Forms.Label();
    this.MSRFWLabel = new System.Windows.Forms.Label();
    this.label5 = new System.Windows.Forms.Label();
    this.MSRClearTextButton = new System.Windows.Forms.Button();
    this.MSROpenCloseCheckBox = new System.Windows.Forms.CheckBox();
    this.MSRSerialComboBox = new System.Windows.Forms.ComboBox();
    this.FPRTabPage = new System.Windows.Forms.TabPage();
    this.DBUnflipButton = new System.Windows.Forms.Button();
    this.FPRPingButton = new System.Windows.Forms.Button();
    this.SagemRefreshButton = new System.Windows.Forms.Button();
    this.DBCancelButton = new System.Windows.Forms.Button();
    this.DBTimeoutUpDown = new System.Windows.Forms.NumericUpDown();
    this.DBTimeoutCheckbox = new System.Windows.Forms.CheckBox();
    this.DBGoButton = new System.Windows.Forms.Button();
    this.DBStatusLabel = new System.Windows.Forms.Label();
    this.DBEnrollRadioButton = new System.Windows.Forms.RadioButton();
    this.DBVerifyRadioButton = new System.Windows.Forms.RadioButton();
    this.DBNameTextBox = new System.Windows.Forms.TextBox();
    this.label2 = new System.Windows.Forms.Label();
    this.SagemImagePictureBox = new System.Windows.Forms.PictureBox();
    this.SagemFWLabel = new System.Windows.Forms.Label();
    this.label1 = new System.Windows.Forms.Label();
    this.SCRTabPage = new System.Windows.Forms.TabPage();
    this.SCRContactCheckBox = new System.Windows.Forms.CheckBox();
    this.SCRStateLabel = new System.Windows.Forms.Label();
    this.SCRATRLabel = new System.Windows.Forms.Label();
    this.SCRProtocolLabel = new System.Windows.Forms.Label();
    this.SCRDeinitLabel = new System.Windows.Forms.Label();
    this.SCRDisconnectLabel = new System.Windows.Forms.Label();
    this.SCRStatusLabel = new System.Windows.Forms.Label();
    this.SCRConnectLabel = new System.Windows.Forms.Label();
    this.SCRInitLabel = new System.Windows.Forms.Label();
    this.SCRStatusButton = new System.Windows.Forms.Button();
    this.SCRDeinitButton = new System.Windows.Forms.Button();
    this.SCRDisconnectButton = new System.Windows.Forms.Button();
    this.SCRConnectButton = new System.Windows.Forms.Button();
    this.SCRInitButton = new System.Windows.Forms.Button();
    this.LAPTabPage = new System.Windows.Forms.TabPage();
    this.LAPPWLAPButton = new System.Windows.Forms.Button();
    this.LAPPIVLAPButton = new System.Windows.Forms.Button();
    this.PIVMSRDataTimer = new System.Windows.Forms.Timer();
    this.PIVSCRTimer = new System.Windows.Forms.Timer();
    this.PIVInputPanel = new Microsoft.WindowsCE.Forms.InputPanel();
    this.DebugTabPage.SuspendLayout();
    this.TabControl.SuspendLayout();
    this.PIVTabPage.SuspendLayout();
    this.AboutTabPage.SuspendLayout();
    this.MSRTabPage.SuspendLayout();
    this.FPRTabPage.SuspendLayout();
    this.SCRTabPage.SuspendLayout();
    this.LAPTabPage.SuspendLayout();
    this.SuspendLayout();
    // 
    // DBOpenCloseCheckBox
    // 
    this.DBOpenCloseCheckBox.Location = new System.Drawing.Point(103, 4);
    this.DBOpenCloseCheckBox.Name = "DBOpenCloseCheckBox";
    this.DBOpenCloseCheckBox.Size = new System.Drawing.Size(61, 21);
    this.DBOpenCloseCheckBox.TabIndex = 6;
    this.DBOpenCloseCheckBox.Text = "Open";
    this.DBOpenCloseCheckBox.CheckStateChanged += new System.EventHandler(this.OpenCloseCheckBox_CheckStateChanged);
    // 
    // DBSerialComboBox
    // 
    this.DBSerialComboBox.Location = new System.Drawing.Point(3, 3);
    this.DBSerialComboBox.Name = "DBSerialComboBox";
    this.DBSerialComboBox.Size = new System.Drawing.Size(94, 22);
    this.DBSerialComboBox.TabIndex = 5;
    this.DBSerialComboBox.GotFocus += new System.EventHandler(this.DBSerialComboBox_GotFocus);
    // 
    // DebugTabPage
    // 
    this.DebugTabPage.Controls.Add(this.DebugClearButton);
    this.DebugTabPage.Controls.Add(this.DebugCheckBox);
    this.DebugTabPage.Controls.Add(this.DebugTextBox);
    this.DebugTabPage.Location = new System.Drawing.Point(0, 0);
    this.DebugTabPage.Name = "DebugTabPage";
    this.DebugTabPage.Size = new System.Drawing.Size(232, 265);
    this.DebugTabPage.Text = "Debug";
    // 
    // DebugClearButton
    // 
    this.DebugClearButton.Location = new System.Drawing.Point(193, 7);
    this.DebugClearButton.Name = "DebugClearButton";
    this.DebugClearButton.Size = new System.Drawing.Size(40, 20);
    this.DebugClearButton.TabIndex = 2;
    this.DebugClearButton.Text = "Clear";
    this.DebugClearButton.Click += new System.EventHandler(this.DebugClearButton_Click);
    // 
    // DebugCheckBox
    // 
    this.DebugCheckBox.Location = new System.Drawing.Point(7, 7);
    this.DebugCheckBox.Name = "DebugCheckBox";
    this.DebugCheckBox.Size = new System.Drawing.Size(100, 20);
    this.DebugCheckBox.TabIndex = 1;
    this.DebugCheckBox.Text = "Debug Text";
    // 
    // DebugTextBox
    // 
    this.DebugTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                | System.Windows.Forms.AnchorStyles.Left)
                | System.Windows.Forms.AnchorStyles.Right)));
    this.DebugTextBox.Location = new System.Drawing.Point(0, 33);
    this.DebugTextBox.Multiline = true;
    this.DebugTextBox.Name = "DebugTextBox";
    this.DebugTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
    this.DebugTextBox.Size = new System.Drawing.Size(232, 232);
    this.DebugTextBox.TabIndex = 0;
    // 
    // TabControl
    // 
    this.TabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                | System.Windows.Forms.AnchorStyles.Left)
                | System.Windows.Forms.AnchorStyles.Right)));
    this.TabControl.Controls.Add(this.PIVTabPage);
    this.TabControl.Controls.Add(this.AboutTabPage);
    this.TabControl.Controls.Add(this.MSRTabPage);
    this.TabControl.Controls.Add(this.FPRTabPage);
    this.TabControl.Controls.Add(this.SCRTabPage);
    this.TabControl.Controls.Add(this.LAPTabPage);
    this.TabControl.Controls.Add(this.DebugTabPage);
    this.TabControl.Dock = System.Windows.Forms.DockStyle.None;
    this.TabControl.Location = new System.Drawing.Point(0, 3);
    this.TabControl.Name = "TabControl";
    this.TabControl.SelectedIndex = 0;
    this.TabControl.Size = new System.Drawing.Size(240, 291);
    this.TabControl.TabIndex = 7;
    this.TabControl.SelectedIndexChanged += new System.EventHandler(this.TabControl_SelectedIndexChanged);
    // 
    // PIVTabPage
    // 
    this.PIVTabPage.Controls.Add(this.PIVFPRSIPPictureBox);
    this.PIVTabPage.Controls.Add(this.PIVFPRFlipCheckBox);
    this.PIVTabPage.Controls.Add(this.label13);
    this.PIVTabPage.Controls.Add(this.label12);
    this.PIVTabPage.Controls.Add(this.label11);
    this.PIVTabPage.Controls.Add(this.PIVSCRStatusDataLabel);
    this.PIVTabPage.Controls.Add(this.PIVSCRProtocolDataLabel);
    this.PIVTabPage.Controls.Add(this.PIVSCRStatusLabel);
    this.PIVTabPage.Controls.Add(this.PIVSCRProtocolLabel);
    this.PIVTabPage.Controls.Add(this.PIVSCRATRDataTextBox);
    this.PIVTabPage.Controls.Add(this.PIVSCRATRLabel);
    this.PIVTabPage.Controls.Add(this.PIVMSRFWVersionLabel);
    this.PIVTabPage.Controls.Add(this.PIVMSRFWLabel);
    this.PIVTabPage.Controls.Add(this.PIVFPRClearDBButton);
    this.PIVTabPage.Controls.Add(this.PIVFPRStatusLabel);
    this.PIVTabPage.Controls.Add(this.PIVFPRNameLabel);
    this.PIVTabPage.Controls.Add(this.PIVFPRTimeoutUpDown);
    this.PIVTabPage.Controls.Add(this.PIVFPRTimeoutCheckbox);
    this.PIVTabPage.Controls.Add(this.PIVFPRNameTextBox);
    this.PIVTabPage.Controls.Add(this.PIVFPRCancelButton);
    this.PIVTabPage.Controls.Add(this.PIVFPRGoButton);
    this.PIVTabPage.Controls.Add(this.PIVFPREnrollRadioButton);
    this.PIVTabPage.Controls.Add(this.PIVFPRVerifyRadioButton);
    this.PIVTabPage.Controls.Add(this.PIVFPRFWVersionLabel);
    this.PIVTabPage.Controls.Add(this.PIVFPRFWLabel);
    this.PIVTabPage.Controls.Add(this.PIVFPRImagePictureBox);
    this.PIVTabPage.Controls.Add(this.PIVMSRTrack3DataTextBox);
    this.PIVTabPage.Controls.Add(this.PIVMSRTrack2DataTextBox);
    this.PIVTabPage.Controls.Add(this.PIVMSRTrack1DataTextBox);
    this.PIVTabPage.Controls.Add(this.PIVMSRTrack3DataLabel);
    this.PIVTabPage.Controls.Add(this.PIVMSRTrack2DataLabel);
    this.PIVTabPage.Controls.Add(this.PIVMSRTrack1DataLabel);
    this.PIVTabPage.Controls.Add(this.PIVSCRCheckBox);
    this.PIVTabPage.Controls.Add(this.PIVFPRCheckBox);
    this.PIVTabPage.Controls.Add(this.PIVMSRCheckBox);
    this.PIVTabPage.Location = new System.Drawing.Point(0, 0);
    this.PIVTabPage.Name = "PIVTabPage";
    this.PIVTabPage.Size = new System.Drawing.Size(240, 268);
    this.PIVTabPage.Text = "PIV";
    // 
    // PIVFPRSIPPictureBox
    // 
    this.PIVFPRSIPPictureBox.BackColor = System.Drawing.Color.Transparent;
    this.PIVFPRSIPPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("PIVFPRSIPPictureBox.Image")));
    this.PIVFPRSIPPictureBox.Location = new System.Drawing.Point(7, 143);
    this.PIVFPRSIPPictureBox.Name = "PIVFPRSIPPictureBox";
    this.PIVFPRSIPPictureBox.Size = new System.Drawing.Size(39, 27);
    this.PIVFPRSIPPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
    this.PIVFPRSIPPictureBox.Click += new System.EventHandler(this.PIVFPRSIPPictureBox_Click);
    // 
    // PIVFPRFlipCheckBox
    // 
    this.PIVFPRFlipCheckBox.Location = new System.Drawing.Point(132, 31);
    this.PIVFPRFlipCheckBox.Name = "PIVFPRFlipCheckBox";
    this.PIVFPRFlipCheckBox.Size = new System.Drawing.Size(51, 20);
    this.PIVFPRFlipCheckBox.TabIndex = 93;
    this.PIVFPRFlipCheckBox.Text = "Flip";
    // 
    // label13
    // 
    this.label13.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
    this.label13.Location = new System.Drawing.Point(180, 14);
    this.label13.Name = "label13";
    this.label13.Size = new System.Drawing.Size(40, 14);
    this.label13.Text = "Reader";
    // 
    // label12
    // 
    this.label12.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
    this.label12.Location = new System.Drawing.Point(101, 14);
    this.label12.Name = "label12";
    this.label12.Size = new System.Drawing.Size(50, 14);
    this.label12.Text = "Reader";
    // 
    // label11
    // 
    this.label11.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
    this.label11.Location = new System.Drawing.Point(25, 15);
    this.label11.Name = "label11";
    this.label11.Size = new System.Drawing.Size(56, 14);
    this.label11.Text = "Reader";
    // 
    // PIVSCRStatusDataLabel
    // 
    this.PIVSCRStatusDataLabel.Location = new System.Drawing.Point(68, 68);
    this.PIVSCRStatusDataLabel.Name = "PIVSCRStatusDataLabel";
    this.PIVSCRStatusDataLabel.Size = new System.Drawing.Size(156, 20);
    // 
    // PIVSCRProtocolDataLabel
    // 
    this.PIVSCRProtocolDataLabel.Location = new System.Drawing.Point(68, 96);
    this.PIVSCRProtocolDataLabel.Name = "PIVSCRProtocolDataLabel";
    this.PIVSCRProtocolDataLabel.Size = new System.Drawing.Size(156, 20);
    // 
    // PIVSCRStatusLabel
    // 
    this.PIVSCRStatusLabel.Location = new System.Drawing.Point(3, 68);
    this.PIVSCRStatusLabel.Name = "PIVSCRStatusLabel";
    this.PIVSCRStatusLabel.Size = new System.Drawing.Size(55, 20);
    this.PIVSCRStatusLabel.Text = "Status:";
    // 
    // PIVSCRProtocolLabel
    // 
    this.PIVSCRProtocolLabel.Location = new System.Drawing.Point(3, 96);
    this.PIVSCRProtocolLabel.Name = "PIVSCRProtocolLabel";
    this.PIVSCRProtocolLabel.Size = new System.Drawing.Size(58, 20);
    this.PIVSCRProtocolLabel.Text = "Protocol:";
    // 
    // PIVSCRATRDataTextBox
    // 
    this.PIVSCRATRDataTextBox.Location = new System.Drawing.Point(33, 119);
    this.PIVSCRATRDataTextBox.Multiline = true;
    this.PIVSCRATRDataTextBox.Name = "PIVSCRATRDataTextBox";
    this.PIVSCRATRDataTextBox.ReadOnly = true;
    this.PIVSCRATRDataTextBox.Size = new System.Drawing.Size(191, 60);
    this.PIVSCRATRDataTextBox.TabIndex = 81;
    this.PIVSCRATRDataTextBox.WordWrap = false;
    // 
    // PIVSCRATRLabel
    // 
    this.PIVSCRATRLabel.Location = new System.Drawing.Point(3, 120);
    this.PIVSCRATRLabel.Name = "PIVSCRATRLabel";
    this.PIVSCRATRLabel.Size = new System.Drawing.Size(33, 20);
    this.PIVSCRATRLabel.Text = "ATR:";
    // 
    // PIVMSRFWVersionLabel
    // 
    this.PIVMSRFWVersionLabel.Location = new System.Drawing.Point(32, 29);
    this.PIVMSRFWVersionLabel.Name = "PIVMSRFWVersionLabel";
    this.PIVMSRFWVersionLabel.Size = new System.Drawing.Size(66, 20);
    // 
    // PIVMSRFWLabel
    // 
    this.PIVMSRFWLabel.Location = new System.Drawing.Point(3, 32);
    this.PIVMSRFWLabel.Name = "PIVMSRFWLabel";
    this.PIVMSRFWLabel.Size = new System.Drawing.Size(33, 20);
    this.PIVMSRFWLabel.Text = "F/W:";
    // 
    // PIVFPRClearDBButton
    // 
    this.PIVFPRClearDBButton.Location = new System.Drawing.Point(4, 241);
    this.PIVFPRClearDBButton.Name = "PIVFPRClearDBButton";
    this.PIVFPRClearDBButton.Size = new System.Drawing.Size(58, 20);
    this.PIVFPRClearDBButton.TabIndex = 70;
    this.PIVFPRClearDBButton.Text = "Clr DB";
    this.PIVFPRClearDBButton.Click += new System.EventHandler(this.PIVFPRClearDBButton_Click);
    // 
    // PIVFPRStatusLabel
    // 
    this.PIVFPRStatusLabel.Location = new System.Drawing.Point(118, 96);
    this.PIVFPRStatusLabel.Name = "PIVFPRStatusLabel";
    this.PIVFPRStatusLabel.Size = new System.Drawing.Size(111, 20);
    // 
    // PIVFPRNameLabel
    // 
    this.PIVFPRNameLabel.Location = new System.Drawing.Point(3, 102);
    this.PIVFPRNameLabel.Name = "PIVFPRNameLabel";
    this.PIVFPRNameLabel.Size = new System.Drawing.Size(43, 17);
    this.PIVFPRNameLabel.Text = "Name";
    // 
    // PIVFPRTimeoutUpDown
    // 
    this.PIVFPRTimeoutUpDown.Location = new System.Drawing.Point(4, 74);
    this.PIVFPRTimeoutUpDown.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
    this.PIVFPRTimeoutUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
    this.PIVFPRTimeoutUpDown.Name = "PIVFPRTimeoutUpDown";
    this.PIVFPRTimeoutUpDown.Size = new System.Drawing.Size(54, 22);
    this.PIVFPRTimeoutUpDown.TabIndex = 63;
    this.PIVFPRTimeoutUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
    // 
    // PIVFPRTimeoutCheckbox
    // 
    this.PIVFPRTimeoutCheckbox.Checked = true;
    this.PIVFPRTimeoutCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
    this.PIVFPRTimeoutCheckbox.Location = new System.Drawing.Point(64, 76);
    this.PIVFPRTimeoutCheckbox.Name = "PIVFPRTimeoutCheckbox";
    this.PIVFPRTimeoutCheckbox.Size = new System.Drawing.Size(111, 20);
    this.PIVFPRTimeoutCheckbox.TabIndex = 62;
    this.PIVFPRTimeoutCheckbox.Text = "Timeout (sec)";
    this.PIVFPRTimeoutCheckbox.CheckStateChanged += new System.EventHandler(this.PIVFPRTimeoutCheckbox_CheckStateChanged);
    // 
    // PIVFPRNameTextBox
    // 
    this.PIVFPRNameTextBox.Enabled = false;
    this.PIVFPRNameTextBox.Location = new System.Drawing.Point(7, 119);
    this.PIVFPRNameTextBox.Name = "PIVFPRNameTextBox";
    this.PIVFPRNameTextBox.Size = new System.Drawing.Size(105, 21);
    this.PIVFPRNameTextBox.TabIndex = 61;
    // 
    // PIVFPRCancelButton
    // 
    this.PIVFPRCancelButton.Location = new System.Drawing.Point(166, 52);
    this.PIVFPRCancelButton.Name = "PIVFPRCancelButton";
    this.PIVFPRCancelButton.Size = new System.Drawing.Size(58, 20);
    this.PIVFPRCancelButton.TabIndex = 54;
    this.PIVFPRCancelButton.Text = "Cancel";
    this.PIVFPRCancelButton.Click += new System.EventHandler(this.PIVFPRCancelButton_Click);
    // 
    // PIVFPRGoButton
    // 
    this.PIVFPRGoButton.Location = new System.Drawing.Point(132, 52);
    this.PIVFPRGoButton.Name = "PIVFPRGoButton";
    this.PIVFPRGoButton.Size = new System.Drawing.Size(28, 20);
    this.PIVFPRGoButton.TabIndex = 53;
    this.PIVFPRGoButton.Text = "Go";
    this.PIVFPRGoButton.Click += new System.EventHandler(this.PIVFPRGoButton_Click);
    // 
    // PIVFPREnrollRadioButton
    // 
    this.PIVFPREnrollRadioButton.Checked = true;
    this.PIVFPREnrollRadioButton.Location = new System.Drawing.Point(4, 52);
    this.PIVFPREnrollRadioButton.Name = "PIVFPREnrollRadioButton";
    this.PIVFPREnrollRadioButton.Size = new System.Drawing.Size(54, 20);
    this.PIVFPREnrollRadioButton.TabIndex = 52;
    this.PIVFPREnrollRadioButton.Text = "Enroll";
    this.PIVFPREnrollRadioButton.CheckedChanged += new System.EventHandler(this.PIVFPREnrollRadioButton_CheckedChanged);
    // 
    // PIVFPRVerifyRadioButton
    // 
    this.PIVFPRVerifyRadioButton.Location = new System.Drawing.Point(64, 52);
    this.PIVFPRVerifyRadioButton.Name = "PIVFPRVerifyRadioButton";
    this.PIVFPRVerifyRadioButton.Size = new System.Drawing.Size(62, 20);
    this.PIVFPRVerifyRadioButton.TabIndex = 51;
    this.PIVFPRVerifyRadioButton.TabStop = false;
    this.PIVFPRVerifyRadioButton.Text = "Verify";
    this.PIVFPRVerifyRadioButton.CheckedChanged += new System.EventHandler(this.PIVFPRVerifyRadioButton_CheckedChanged);
    // 
    // PIVFPRFWVersionLabel
    // 
    this.PIVFPRFWVersionLabel.Location = new System.Drawing.Point(32, 29);
    this.PIVFPRFWVersionLabel.Name = "PIVFPRFWVersionLabel";
    this.PIVFPRFWVersionLabel.Size = new System.Drawing.Size(66, 20);
    // 
    // PIVFPRFWLabel
    // 
    this.PIVFPRFWLabel.Location = new System.Drawing.Point(3, 29);
    this.PIVFPRFWLabel.Name = "PIVFPRFWLabel";
    this.PIVFPRFWLabel.Size = new System.Drawing.Size(33, 20);
    this.PIVFPRFWLabel.Text = "F/W:";
    // 
    // PIVFPRImagePictureBox
    // 
    this.PIVFPRImagePictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                | System.Windows.Forms.AnchorStyles.Left)
                | System.Windows.Forms.AnchorStyles.Right)));
    this.PIVFPRImagePictureBox.BackColor = System.Drawing.Color.White;
    this.PIVFPRImagePictureBox.Location = new System.Drawing.Point(114, 119);
    this.PIVFPRImagePictureBox.Name = "PIVFPRImagePictureBox";
    this.PIVFPRImagePictureBox.Size = new System.Drawing.Size(119, 142);
    this.PIVFPRImagePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
    // 
    // PIVMSRTrack3DataTextBox
    // 
    this.PIVMSRTrack3DataTextBox.Location = new System.Drawing.Point(27, 189);
    this.PIVMSRTrack3DataTextBox.Multiline = true;
    this.PIVMSRTrack3DataTextBox.Name = "PIVMSRTrack3DataTextBox";
    this.PIVMSRTrack3DataTextBox.ReadOnly = true;
    this.PIVMSRTrack3DataTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
    this.PIVMSRTrack3DataTextBox.Size = new System.Drawing.Size(206, 60);
    this.PIVMSRTrack3DataTextBox.TabIndex = 43;
    // 
    // PIVMSRTrack2DataTextBox
    // 
    this.PIVMSRTrack2DataTextBox.Location = new System.Drawing.Point(27, 126);
    this.PIVMSRTrack2DataTextBox.Multiline = true;
    this.PIVMSRTrack2DataTextBox.Name = "PIVMSRTrack2DataTextBox";
    this.PIVMSRTrack2DataTextBox.ReadOnly = true;
    this.PIVMSRTrack2DataTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
    this.PIVMSRTrack2DataTextBox.Size = new System.Drawing.Size(206, 60);
    this.PIVMSRTrack2DataTextBox.TabIndex = 42;
    // 
    // PIVMSRTrack1DataTextBox
    // 
    this.PIVMSRTrack1DataTextBox.Location = new System.Drawing.Point(27, 62);
    this.PIVMSRTrack1DataTextBox.Multiline = true;
    this.PIVMSRTrack1DataTextBox.Name = "PIVMSRTrack1DataTextBox";
    this.PIVMSRTrack1DataTextBox.ReadOnly = true;
    this.PIVMSRTrack1DataTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
    this.PIVMSRTrack1DataTextBox.Size = new System.Drawing.Size(206, 60);
    this.PIVMSRTrack1DataTextBox.TabIndex = 36;
    // 
    // PIVMSRTrack3DataLabel
    // 
    this.PIVMSRTrack3DataLabel.Location = new System.Drawing.Point(4, 189);
    this.PIVMSRTrack3DataLabel.Name = "PIVMSRTrack3DataLabel";
    this.PIVMSRTrack3DataLabel.Size = new System.Drawing.Size(24, 20);
    this.PIVMSRTrack3DataLabel.Text = "T3:";
    // 
    // PIVMSRTrack2DataLabel
    // 
    this.PIVMSRTrack2DataLabel.Location = new System.Drawing.Point(4, 126);
    this.PIVMSRTrack2DataLabel.Name = "PIVMSRTrack2DataLabel";
    this.PIVMSRTrack2DataLabel.Size = new System.Drawing.Size(24, 20);
    this.PIVMSRTrack2DataLabel.Text = "T2:";
    // 
    // PIVMSRTrack1DataLabel
    // 
    this.PIVMSRTrack1DataLabel.Location = new System.Drawing.Point(4, 62);
    this.PIVMSRTrack1DataLabel.Name = "PIVMSRTrack1DataLabel";
    this.PIVMSRTrack1DataLabel.Size = new System.Drawing.Size(24, 20);
    this.PIVMSRTrack1DataLabel.Text = "T1:";
    // 
    // PIVSCRCheckBox
    // 
    this.PIVSCRCheckBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
    this.PIVSCRCheckBox.Location = new System.Drawing.Point(156, -2);
    this.PIVSCRCheckBox.Name = "PIVSCRCheckBox";
    this.PIVSCRCheckBox.Size = new System.Drawing.Size(88, 20);
    this.PIVSCRCheckBox.TabIndex = 2;
    this.PIVSCRCheckBox.Text = "Smart Card";
    this.PIVSCRCheckBox.CheckStateChanged += new System.EventHandler(this.PIVSCRCheckBox_CheckStateChanged);
    // 
    // PIVFPRCheckBox
    // 
    this.PIVFPRCheckBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
    this.PIVFPRCheckBox.Location = new System.Drawing.Point(77, -2);
    this.PIVFPRCheckBox.Name = "PIVFPRCheckBox";
    this.PIVFPRCheckBox.Size = new System.Drawing.Size(89, 20);
    this.PIVFPRCheckBox.TabIndex = 1;
    this.PIVFPRCheckBox.Text = "Fingerprint";
    this.PIVFPRCheckBox.CheckStateChanged += new System.EventHandler(this.PIVFPRCheckBox_CheckStateChanged);
    // 
    // PIVMSRCheckBox
    // 
    this.PIVMSRCheckBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
    this.PIVMSRCheckBox.Location = new System.Drawing.Point(1, -2);
    this.PIVMSRCheckBox.Name = "PIVMSRCheckBox";
    this.PIVMSRCheckBox.Size = new System.Drawing.Size(73, 20);
    this.PIVMSRCheckBox.TabIndex = 0;
    this.PIVMSRCheckBox.Text = "Mag Strip";
    this.PIVMSRCheckBox.CheckStateChanged += new System.EventHandler(this.PIVMSRCheckBox_CheckStateChanged);
    // 
    // AboutTabPage
    // 
    this.AboutTabPage.Controls.Add(this.AboutCLCheckBox);
    this.AboutTabPage.Controls.Add(this.AboutDeinitButton);
    this.AboutTabPage.Controls.Add(this.AboutInitButton);
    this.AboutTabPage.Controls.Add(this.AboutAntennaCheckBox);
    this.AboutTabPage.Controls.Add(this.AboutIdleCheckBox);
    this.AboutTabPage.Controls.Add(this.AboutReaderCheckBox);
    this.AboutTabPage.Controls.Add(this.AboutIdleButton);
    this.AboutTabPage.Controls.Add(this.AboutReaderButton);
    this.AboutTabPage.Controls.Add(this.AboutAntennaButton);
    this.AboutTabPage.Controls.Add(this.AboutCloseButton);
    this.AboutTabPage.Controls.Add(this.AboutOpenButton);
    this.AboutTabPage.Controls.Add(this.AboutOKPWRCEDLLVersionLabel);
    this.AboutTabPage.Controls.Add(this.AboutWSQDLLVersionLabel);
    this.AboutTabPage.Controls.Add(this.AboutPortsLabel);
    this.AboutTabPage.Controls.Add(this.AboutPortsButton);
    this.AboutTabPage.Controls.Add(this.label10);
    this.AboutTabPage.Controls.Add(this.label9);
    this.AboutTabPage.Controls.Add(this.label8);
    this.AboutTabPage.Controls.Add(this.label4);
    this.AboutTabPage.Location = new System.Drawing.Point(0, 0);
    this.AboutTabPage.Name = "AboutTabPage";
    this.AboutTabPage.Size = new System.Drawing.Size(240, 268);
    this.AboutTabPage.Text = "About";
    // 
    // AboutCLCheckBox
    // 
    this.AboutCLCheckBox.Location = new System.Drawing.Point(159, 141);
    this.AboutCLCheckBox.Name = "AboutCLCheckBox";
    this.AboutCLCheckBox.Size = new System.Drawing.Size(48, 20);
    this.AboutCLCheckBox.TabIndex = 47;
    this.AboutCLCheckBox.Text = "CL";
    this.AboutCLCheckBox.Visible = false;
    // 
    // AboutDeinitButton
    // 
    this.AboutDeinitButton.Location = new System.Drawing.Point(3, 167);
    this.AboutDeinitButton.Name = "AboutDeinitButton";
    this.AboutDeinitButton.Size = new System.Drawing.Size(72, 20);
    this.AboutDeinitButton.TabIndex = 39;
    this.AboutDeinitButton.Text = "Deinit";
    this.AboutDeinitButton.Visible = false;
    this.AboutDeinitButton.Click += new System.EventHandler(this.AboutDeinitButton_Click);
    // 
    // AboutInitButton
    // 
    this.AboutInitButton.Location = new System.Drawing.Point(3, 141);
    this.AboutInitButton.Name = "AboutInitButton";
    this.AboutInitButton.Size = new System.Drawing.Size(72, 20);
    this.AboutInitButton.TabIndex = 38;
    this.AboutInitButton.Text = "Init";
    this.AboutInitButton.Visible = false;
    this.AboutInitButton.Click += new System.EventHandler(this.AboutInitButton_Click);
    // 
    // AboutAntennaCheckBox
    // 
    this.AboutAntennaCheckBox.Location = new System.Drawing.Point(159, 167);
    this.AboutAntennaCheckBox.Name = "AboutAntennaCheckBox";
    this.AboutAntennaCheckBox.Size = new System.Drawing.Size(48, 20);
    this.AboutAntennaCheckBox.TabIndex = 30;
    this.AboutAntennaCheckBox.Text = "On";
    this.AboutAntennaCheckBox.Visible = false;
    // 
    // AboutIdleCheckBox
    // 
    this.AboutIdleCheckBox.Location = new System.Drawing.Point(159, 193);
    this.AboutIdleCheckBox.Name = "AboutIdleCheckBox";
    this.AboutIdleCheckBox.Size = new System.Drawing.Size(48, 20);
    this.AboutIdleCheckBox.TabIndex = 29;
    this.AboutIdleCheckBox.Text = "On";
    this.AboutIdleCheckBox.Visible = false;
    // 
    // AboutReaderCheckBox
    // 
    this.AboutReaderCheckBox.Location = new System.Drawing.Point(159, 219);
    this.AboutReaderCheckBox.Name = "AboutReaderCheckBox";
    this.AboutReaderCheckBox.Size = new System.Drawing.Size(48, 20);
    this.AboutReaderCheckBox.TabIndex = 28;
    this.AboutReaderCheckBox.Text = "On";
    this.AboutReaderCheckBox.Visible = false;
    // 
    // AboutIdleButton
    // 
    this.AboutIdleButton.Location = new System.Drawing.Point(81, 193);
    this.AboutIdleButton.Name = "AboutIdleButton";
    this.AboutIdleButton.Size = new System.Drawing.Size(72, 20);
    this.AboutIdleButton.TabIndex = 27;
    this.AboutIdleButton.Text = "Idle";
    this.AboutIdleButton.Visible = false;
    this.AboutIdleButton.Click += new System.EventHandler(this.AboutIdleButton_Click);
    // 
    // AboutReaderButton
    // 
    this.AboutReaderButton.Location = new System.Drawing.Point(81, 219);
    this.AboutReaderButton.Name = "AboutReaderButton";
    this.AboutReaderButton.Size = new System.Drawing.Size(72, 20);
    this.AboutReaderButton.TabIndex = 26;
    this.AboutReaderButton.Text = "Reader";
    this.AboutReaderButton.Visible = false;
    this.AboutReaderButton.Click += new System.EventHandler(this.AboutReaderButton_Click);
    // 
    // AboutAntennaButton
    // 
    this.AboutAntennaButton.Location = new System.Drawing.Point(81, 167);
    this.AboutAntennaButton.Name = "AboutAntennaButton";
    this.AboutAntennaButton.Size = new System.Drawing.Size(72, 20);
    this.AboutAntennaButton.TabIndex = 25;
    this.AboutAntennaButton.Text = "Antenna";
    this.AboutAntennaButton.Visible = false;
    this.AboutAntennaButton.Click += new System.EventHandler(this.AboutAntennaButton_Click);
    // 
    // AboutCloseButton
    // 
    this.AboutCloseButton.Location = new System.Drawing.Point(81, 245);
    this.AboutCloseButton.Name = "AboutCloseButton";
    this.AboutCloseButton.Size = new System.Drawing.Size(72, 20);
    this.AboutCloseButton.TabIndex = 17;
    this.AboutCloseButton.Text = "Close";
    this.AboutCloseButton.Visible = false;
    this.AboutCloseButton.Click += new System.EventHandler(this.AboutCloseButton_Click);
    // 
    // AboutOpenButton
    // 
    this.AboutOpenButton.Location = new System.Drawing.Point(81, 141);
    this.AboutOpenButton.Name = "AboutOpenButton";
    this.AboutOpenButton.Size = new System.Drawing.Size(72, 20);
    this.AboutOpenButton.TabIndex = 9;
    this.AboutOpenButton.Text = "Open";
    this.AboutOpenButton.Visible = false;
    this.AboutOpenButton.Click += new System.EventHandler(this.AboutOpenButton_Click);
    // 
    // AboutOKPWRCEDLLVersionLabel
    // 
    this.AboutOKPWRCEDLLVersionLabel.Location = new System.Drawing.Point(3, 100);
    this.AboutOKPWRCEDLLVersionLabel.Name = "AboutOKPWRCEDLLVersionLabel";
    this.AboutOKPWRCEDLLVersionLabel.Size = new System.Drawing.Size(226, 20);
    // 
    // AboutWSQDLLVersionLabel
    // 
    this.AboutWSQDLLVersionLabel.Location = new System.Drawing.Point(3, 80);
    this.AboutWSQDLLVersionLabel.Name = "AboutWSQDLLVersionLabel";
    this.AboutWSQDLLVersionLabel.Size = new System.Drawing.Size(226, 20);
    // 
    // AboutPortsLabel
    // 
    this.AboutPortsLabel.Location = new System.Drawing.Point(81, 245);
    this.AboutPortsLabel.Name = "AboutPortsLabel";
    this.AboutPortsLabel.Size = new System.Drawing.Size(152, 20);
    // 
    // AboutPortsButton
    // 
    this.AboutPortsButton.Location = new System.Drawing.Point(3, 245);
    this.AboutPortsButton.Name = "AboutPortsButton";
    this.AboutPortsButton.Size = new System.Drawing.Size(72, 20);
    this.AboutPortsButton.TabIndex = 4;
    this.AboutPortsButton.Text = "Ports";
    this.AboutPortsButton.Visible = false;
    this.AboutPortsButton.Click += new System.EventHandler(this.AboutPortsButton_Click);
    // 
    // label10
    // 
    this.label10.Location = new System.Drawing.Point(3, 60);
    this.label10.Name = "label10";
    this.label10.Size = new System.Drawing.Size(226, 20);
    this.label10.Text = "04-13-2010";
    // 
    // label9
    // 
    this.label9.Location = new System.Drawing.Point(3, 40);
    this.label9.Name = "label9";
    this.label9.Size = new System.Drawing.Size(226, 20);
    this.label9.Text = "Rev. A";
    // 
    // label8
    // 
    this.label8.Location = new System.Drawing.Point(3, 20);
    this.label8.Name = "label8";
    this.label8.Size = new System.Drawing.Size(226, 20);
    this.label8.Text = "CN3-PIV-CONTROL";
    // 
    // label4
    // 
    this.label4.Location = new System.Drawing.Point(3, 0);
    this.label4.Name = "label4";
    this.label4.Size = new System.Drawing.Size(226, 20);
    this.label4.Text = "EDGELINE TECHNOLOGIES";
    // 
    // MSRTabPage
    // 
    this.MSRTabPage.Controls.Add(this.PowerSaveButton);
    this.MSRTabPage.Controls.Add(this.PowerGetButton);
    this.MSRTabPage.Controls.Add(this.Power5VStatusLabel);
    this.MSRTabPage.Controls.Add(this.PowerCCStatusLabel);
    this.MSRTabPage.Controls.Add(this.PowerFPStatusLabel);
    this.MSRTabPage.Controls.Add(this.PowerSetButton);
    this.MSRTabPage.Controls.Add(this.PowerCCCheckBox);
    this.MSRTabPage.Controls.Add(this.Power5VCheckBox);
    this.MSRTabPage.Controls.Add(this.PowerFPCheckBox);
    this.MSRTabPage.Controls.Add(this.MSRRefreshButton);
    this.MSRTabPage.Controls.Add(this.MSRByteCountResetButton);
    this.MSRTabPage.Controls.Add(this.MSRByteCountLabel);
    this.MSRTabPage.Controls.Add(this.MSRByteCountButton);
    this.MSRTabPage.Controls.Add(this.MSRPingButton);
    this.MSRTabPage.Controls.Add(this.MSRClrLastButton);
    this.MSRTabPage.Controls.Add(this.MSRGetLastButton);
    this.MSRTabPage.Controls.Add(this.MSRTrack3DataTextBox);
    this.MSRTabPage.Controls.Add(this.MSRTrack2DataTextBox);
    this.MSRTabPage.Controls.Add(this.MSRTrack1DataTextBox);
    this.MSRTabPage.Controls.Add(this.label7);
    this.MSRTabPage.Controls.Add(this.label6);
    this.MSRTabPage.Controls.Add(this.label3);
    this.MSRTabPage.Controls.Add(this.MSRFWLabel);
    this.MSRTabPage.Controls.Add(this.label5);
    this.MSRTabPage.Controls.Add(this.MSRClearTextButton);
    this.MSRTabPage.Controls.Add(this.MSROpenCloseCheckBox);
    this.MSRTabPage.Controls.Add(this.MSRSerialComboBox);
    this.MSRTabPage.Location = new System.Drawing.Point(0, 0);
    this.MSRTabPage.Name = "MSRTabPage";
    this.MSRTabPage.Size = new System.Drawing.Size(232, 265);
    this.MSRTabPage.Text = "MSR";
    // 
    // PowerSaveButton
    // 
    this.PowerSaveButton.Location = new System.Drawing.Point(98, 243);
    this.PowerSaveButton.Name = "PowerSaveButton";
    this.PowerSaveButton.Size = new System.Drawing.Size(48, 20);
    this.PowerSaveButton.TabIndex = 94;
    this.PowerSaveButton.Text = "Save";
    this.PowerSaveButton.Click += new System.EventHandler(this.PowerSaveButton_Click);
    // 
    // PowerGetButton
    // 
    this.PowerGetButton.Location = new System.Drawing.Point(52, 243);
    this.PowerGetButton.Name = "PowerGetButton";
    this.PowerGetButton.Size = new System.Drawing.Size(30, 20);
    this.PowerGetButton.TabIndex = 84;
    this.PowerGetButton.Text = "Get";
    this.PowerGetButton.Click += new System.EventHandler(this.PowerAllGetButton_Click);
    // 
    // Power5VStatusLabel
    // 
    this.Power5VStatusLabel.Location = new System.Drawing.Point(61, 217);
    this.Power5VStatusLabel.Name = "Power5VStatusLabel";
    this.Power5VStatusLabel.Size = new System.Drawing.Size(85, 20);
    // 
    // PowerCCStatusLabel
    // 
    this.PowerCCStatusLabel.Location = new System.Drawing.Point(61, 195);
    this.PowerCCStatusLabel.Name = "PowerCCStatusLabel";
    this.PowerCCStatusLabel.Size = new System.Drawing.Size(85, 20);
    // 
    // PowerFPStatusLabel
    // 
    this.PowerFPStatusLabel.Location = new System.Drawing.Point(61, 173);
    this.PowerFPStatusLabel.Name = "PowerFPStatusLabel";
    this.PowerFPStatusLabel.Size = new System.Drawing.Size(85, 20);
    // 
    // PowerSetButton
    // 
    this.PowerSetButton.Location = new System.Drawing.Point(7, 243);
    this.PowerSetButton.Name = "PowerSetButton";
    this.PowerSetButton.Size = new System.Drawing.Size(30, 20);
    this.PowerSetButton.TabIndex = 77;
    this.PowerSetButton.Text = "Set";
    this.PowerSetButton.Click += new System.EventHandler(this.PowerAllGoButton_Click);
    // 
    // PowerCCCheckBox
    // 
    this.PowerCCCheckBox.Location = new System.Drawing.Point(7, 195);
    this.PowerCCCheckBox.Name = "PowerCCCheckBox";
    this.PowerCCCheckBox.Size = new System.Drawing.Size(45, 20);
    this.PowerCCCheckBox.TabIndex = 73;
    this.PowerCCCheckBox.Text = "CC";
    this.PowerCCCheckBox.CheckStateChanged += new System.EventHandler(this.PowerCCCheckBox_CheckStateChanged);
    // 
    // Power5VCheckBox
    // 
    this.Power5VCheckBox.Location = new System.Drawing.Point(7, 217);
    this.Power5VCheckBox.Name = "Power5VCheckBox";
    this.Power5VCheckBox.Size = new System.Drawing.Size(45, 20);
    this.Power5VCheckBox.TabIndex = 72;
    this.Power5VCheckBox.Text = "5V";
    // 
    // PowerFPCheckBox
    // 
    this.PowerFPCheckBox.Location = new System.Drawing.Point(7, 173);
    this.PowerFPCheckBox.Name = "PowerFPCheckBox";
    this.PowerFPCheckBox.Size = new System.Drawing.Size(45, 20);
    this.PowerFPCheckBox.TabIndex = 71;
    this.PowerFPCheckBox.Text = "FP";
    this.PowerFPCheckBox.CheckStateChanged += new System.EventHandler(this.PowerFPCheckBox_CheckStateChanged);
    // 
    // MSRRefreshButton
    // 
    this.MSRRefreshButton.Location = new System.Drawing.Point(160, 4);
    this.MSRRefreshButton.Name = "MSRRefreshButton";
    this.MSRRefreshButton.Size = new System.Drawing.Size(19, 20);
    this.MSRRefreshButton.TabIndex = 64;
    this.MSRRefreshButton.Text = "R";
    this.MSRRefreshButton.Click += new System.EventHandler(this.MSRRefreshButton_Click);
    // 
    // MSRByteCountResetButton
    // 
    this.MSRByteCountResetButton.Location = new System.Drawing.Point(214, 245);
    this.MSRByteCountResetButton.Name = "MSRByteCountResetButton";
    this.MSRByteCountResetButton.Size = new System.Drawing.Size(19, 20);
    this.MSRByteCountResetButton.TabIndex = 57;
    this.MSRByteCountResetButton.Text = "R";
    this.MSRByteCountResetButton.Visible = false;
    this.MSRByteCountResetButton.Click += new System.EventHandler(this.MSRByteCountResetButton_Click);
    // 
    // MSRByteCountLabel
    // 
    this.MSRByteCountLabel.Location = new System.Drawing.Point(28, 245);
    this.MSRByteCountLabel.Name = "MSRByteCountLabel";
    this.MSRByteCountLabel.Size = new System.Drawing.Size(100, 20);
    // 
    // MSRByteCountButton
    // 
    this.MSRByteCountButton.Location = new System.Drawing.Point(189, 245);
    this.MSRByteCountButton.Name = "MSRByteCountButton";
    this.MSRByteCountButton.Size = new System.Drawing.Size(19, 20);
    this.MSRByteCountButton.TabIndex = 51;
    this.MSRByteCountButton.Text = "B";
    this.MSRByteCountButton.Visible = false;
    this.MSRByteCountButton.Click += new System.EventHandler(this.MSRByteCountButton_Click);
    // 
    // MSRPingButton
    // 
    this.MSRPingButton.Location = new System.Drawing.Point(6, 45);
    this.MSRPingButton.Name = "MSRPingButton";
    this.MSRPingButton.Size = new System.Drawing.Size(19, 20);
    this.MSRPingButton.TabIndex = 45;
    this.MSRPingButton.Text = "P";
    this.MSRPingButton.Click += new System.EventHandler(this.MSRPingButton_Click);
    // 
    // MSRClrLastButton
    // 
    this.MSRClrLastButton.Location = new System.Drawing.Point(71, 147);
    this.MSRClrLastButton.Name = "MSRClrLastButton";
    this.MSRClrLastButton.Size = new System.Drawing.Size(58, 20);
    this.MSRClrLastButton.TabIndex = 39;
    this.MSRClrLastButton.Text = "Clr Last";
    this.MSRClrLastButton.Click += new System.EventHandler(this.MSRClrLastButton_Click);
    // 
    // MSRGetLastButton
    // 
    this.MSRGetLastButton.Location = new System.Drawing.Point(7, 147);
    this.MSRGetLastButton.Name = "MSRGetLastButton";
    this.MSRGetLastButton.Size = new System.Drawing.Size(58, 20);
    this.MSRGetLastButton.TabIndex = 38;
    this.MSRGetLastButton.Text = "Get Last";
    this.MSRGetLastButton.Click += new System.EventHandler(this.MSRGetLastButton_Click);
    // 
    // MSRTrack3DataTextBox
    // 
    this.MSRTrack3DataTextBox.Location = new System.Drawing.Point(31, 120);
    this.MSRTrack3DataTextBox.Name = "MSRTrack3DataTextBox";
    this.MSRTrack3DataTextBox.ReadOnly = true;
    this.MSRTrack3DataTextBox.Size = new System.Drawing.Size(177, 21);
    this.MSRTrack3DataTextBox.TabIndex = 32;
    // 
    // MSRTrack2DataTextBox
    // 
    this.MSRTrack2DataTextBox.Location = new System.Drawing.Point(31, 94);
    this.MSRTrack2DataTextBox.Name = "MSRTrack2DataTextBox";
    this.MSRTrack2DataTextBox.ReadOnly = true;
    this.MSRTrack2DataTextBox.Size = new System.Drawing.Size(177, 21);
    this.MSRTrack2DataTextBox.TabIndex = 31;
    // 
    // MSRTrack1DataTextBox
    // 
    this.MSRTrack1DataTextBox.Location = new System.Drawing.Point(31, 67);
    this.MSRTrack1DataTextBox.Name = "MSRTrack1DataTextBox";
    this.MSRTrack1DataTextBox.ReadOnly = true;
    this.MSRTrack1DataTextBox.Size = new System.Drawing.Size(177, 21);
    this.MSRTrack1DataTextBox.TabIndex = 30;
    // 
    // label7
    // 
    this.label7.Location = new System.Drawing.Point(3, 121);
    this.label7.Name = "label7";
    this.label7.Size = new System.Drawing.Size(24, 20);
    this.label7.Text = "T3:";
    // 
    // label6
    // 
    this.label6.Location = new System.Drawing.Point(3, 95);
    this.label6.Name = "label6";
    this.label6.Size = new System.Drawing.Size(24, 20);
    this.label6.Text = "T2:";
    // 
    // label3
    // 
    this.label3.Location = new System.Drawing.Point(3, 68);
    this.label3.Name = "label3";
    this.label3.Size = new System.Drawing.Size(24, 20);
    this.label3.Text = "T1:";
    // 
    // MSRFWLabel
    // 
    this.MSRFWLabel.Location = new System.Drawing.Point(31, 28);
    this.MSRFWLabel.Name = "MSRFWLabel";
    this.MSRFWLabel.Size = new System.Drawing.Size(66, 20);
    // 
    // label5
    // 
    this.label5.Location = new System.Drawing.Point(3, 28);
    this.label5.Name = "label5";
    this.label5.Size = new System.Drawing.Size(33, 20);
    this.label5.Text = "F/W:";
    // 
    // MSRClearTextButton
    // 
    this.MSRClearTextButton.Location = new System.Drawing.Point(214, 95);
    this.MSRClearTextButton.Name = "MSRClearTextButton";
    this.MSRClearTextButton.Size = new System.Drawing.Size(19, 20);
    this.MSRClearTextButton.TabIndex = 23;
    this.MSRClearTextButton.Text = "C";
    this.MSRClearTextButton.Click += new System.EventHandler(this.MSRClearTextButton_Click);
    // 
    // MSROpenCloseCheckBox
    // 
    this.MSROpenCloseCheckBox.Location = new System.Drawing.Point(103, 4);
    this.MSROpenCloseCheckBox.Name = "MSROpenCloseCheckBox";
    this.MSROpenCloseCheckBox.Size = new System.Drawing.Size(61, 21);
    this.MSROpenCloseCheckBox.TabIndex = 20;
    this.MSROpenCloseCheckBox.Text = "Open";
    this.MSROpenCloseCheckBox.CheckStateChanged += new System.EventHandler(this.MSROpenCloseCheckBox_CheckStateChanged);
    // 
    // MSRSerialComboBox
    // 
    this.MSRSerialComboBox.Location = new System.Drawing.Point(3, 3);
    this.MSRSerialComboBox.Name = "MSRSerialComboBox";
    this.MSRSerialComboBox.Size = new System.Drawing.Size(94, 22);
    this.MSRSerialComboBox.TabIndex = 19;
    this.MSRSerialComboBox.GotFocus += new System.EventHandler(this.MSRSerialComboBox_GotFocus);
    // 
    // FPRTabPage
    // 
    this.FPRTabPage.Controls.Add(this.DBUnflipButton);
    this.FPRTabPage.Controls.Add(this.FPRPingButton);
    this.FPRTabPage.Controls.Add(this.SagemRefreshButton);
    this.FPRTabPage.Controls.Add(this.DBCancelButton);
    this.FPRTabPage.Controls.Add(this.DBTimeoutUpDown);
    this.FPRTabPage.Controls.Add(this.DBOpenCloseCheckBox);
    this.FPRTabPage.Controls.Add(this.DBTimeoutCheckbox);
    this.FPRTabPage.Controls.Add(this.DBSerialComboBox);
    this.FPRTabPage.Controls.Add(this.DBGoButton);
    this.FPRTabPage.Controls.Add(this.DBStatusLabel);
    this.FPRTabPage.Controls.Add(this.DBEnrollRadioButton);
    this.FPRTabPage.Controls.Add(this.DBVerifyRadioButton);
    this.FPRTabPage.Controls.Add(this.DBNameTextBox);
    this.FPRTabPage.Controls.Add(this.label2);
    this.FPRTabPage.Controls.Add(this.SagemImagePictureBox);
    this.FPRTabPage.Controls.Add(this.SagemFWLabel);
    this.FPRTabPage.Controls.Add(this.label1);
    this.FPRTabPage.Location = new System.Drawing.Point(0, 0);
    this.FPRTabPage.Name = "FPRTabPage";
    this.FPRTabPage.Size = new System.Drawing.Size(232, 265);
    this.FPRTabPage.Text = "FPR";
    // 
    // DBUnflipButton
    // 
    this.DBUnflipButton.Location = new System.Drawing.Point(151, 30);
    this.DBUnflipButton.Name = "DBUnflipButton";
    this.DBUnflipButton.Size = new System.Drawing.Size(72, 20);
    this.DBUnflipButton.TabIndex = 77;
    this.DBUnflipButton.Text = "Unflip";
    this.DBUnflipButton.Click += new System.EventHandler(this.DBUnflipButton_Click);
    // 
    // FPRPingButton
    // 
    this.FPRPingButton.Location = new System.Drawing.Point(103, 27);
    this.FPRPingButton.Name = "FPRPingButton";
    this.FPRPingButton.Size = new System.Drawing.Size(19, 20);
    this.FPRPingButton.TabIndex = 71;
    this.FPRPingButton.Text = "P";
    this.FPRPingButton.Click += new System.EventHandler(this.FPRPingButton_Click);
    // 
    // SagemRefreshButton
    // 
    this.SagemRefreshButton.Location = new System.Drawing.Point(160, 4);
    this.SagemRefreshButton.Name = "SagemRefreshButton";
    this.SagemRefreshButton.Size = new System.Drawing.Size(19, 20);
    this.SagemRefreshButton.TabIndex = 65;
    this.SagemRefreshButton.Text = "R";
    this.SagemRefreshButton.Click += new System.EventHandler(this.SagemRefreshButton_Click);
    // 
    // DBCancelButton
    // 
    this.DBCancelButton.Location = new System.Drawing.Point(165, 53);
    this.DBCancelButton.Name = "DBCancelButton";
    this.DBCancelButton.Size = new System.Drawing.Size(58, 20);
    this.DBCancelButton.TabIndex = 30;
    this.DBCancelButton.Text = "Cancel";
    this.DBCancelButton.Click += new System.EventHandler(this.DBCancelButton_Click);
    // 
    // DBTimeoutUpDown
    // 
    this.DBTimeoutUpDown.Location = new System.Drawing.Point(3, 79);
    this.DBTimeoutUpDown.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
    this.DBTimeoutUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
    this.DBTimeoutUpDown.Name = "DBTimeoutUpDown";
    this.DBTimeoutUpDown.Size = new System.Drawing.Size(54, 22);
    this.DBTimeoutUpDown.TabIndex = 24;
    this.DBTimeoutUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
    // 
    // DBTimeoutCheckbox
    // 
    this.DBTimeoutCheckbox.Checked = true;
    this.DBTimeoutCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
    this.DBTimeoutCheckbox.Location = new System.Drawing.Point(63, 81);
    this.DBTimeoutCheckbox.Name = "DBTimeoutCheckbox";
    this.DBTimeoutCheckbox.Size = new System.Drawing.Size(111, 20);
    this.DBTimeoutCheckbox.TabIndex = 18;
    this.DBTimeoutCheckbox.Text = "Timeout (sec)";
    this.DBTimeoutCheckbox.CheckStateChanged += new System.EventHandler(this.DBTimeoutCheckbox_CheckStateChanged);
    // 
    // DBGoButton
    // 
    this.DBGoButton.Location = new System.Drawing.Point(131, 53);
    this.DBGoButton.Name = "DBGoButton";
    this.DBGoButton.Size = new System.Drawing.Size(28, 20);
    this.DBGoButton.TabIndex = 12;
    this.DBGoButton.Text = "Go";
    this.DBGoButton.Click += new System.EventHandler(this.DBGoButton_Click);
    // 
    // DBStatusLabel
    // 
    this.DBStatusLabel.Location = new System.Drawing.Point(126, 103);
    this.DBStatusLabel.Name = "DBStatusLabel";
    this.DBStatusLabel.Size = new System.Drawing.Size(111, 20);
    // 
    // DBEnrollRadioButton
    // 
    this.DBEnrollRadioButton.Checked = true;
    this.DBEnrollRadioButton.Location = new System.Drawing.Point(3, 53);
    this.DBEnrollRadioButton.Name = "DBEnrollRadioButton";
    this.DBEnrollRadioButton.Size = new System.Drawing.Size(54, 20);
    this.DBEnrollRadioButton.TabIndex = 10;
    this.DBEnrollRadioButton.Text = "Enroll";
    this.DBEnrollRadioButton.CheckedChanged += new System.EventHandler(this.DBEnrollRadioButton_CheckedChanged);
    // 
    // DBVerifyRadioButton
    // 
    this.DBVerifyRadioButton.Location = new System.Drawing.Point(63, 53);
    this.DBVerifyRadioButton.Name = "DBVerifyRadioButton";
    this.DBVerifyRadioButton.Size = new System.Drawing.Size(62, 20);
    this.DBVerifyRadioButton.TabIndex = 9;
    this.DBVerifyRadioButton.TabStop = false;
    this.DBVerifyRadioButton.Text = "Verify";
    this.DBVerifyRadioButton.CheckedChanged += new System.EventHandler(this.DBVerifyRadioButton_CheckedChanged);
    // 
    // DBNameTextBox
    // 
    this.DBNameTextBox.Enabled = false;
    this.DBNameTextBox.Location = new System.Drawing.Point(3, 130);
    this.DBNameTextBox.Name = "DBNameTextBox";
    this.DBNameTextBox.Size = new System.Drawing.Size(113, 21);
    this.DBNameTextBox.TabIndex = 8;
    // 
    // label2
    // 
    this.label2.Location = new System.Drawing.Point(3, 116);
    this.label2.Name = "label2";
    this.label2.Size = new System.Drawing.Size(43, 20);
    this.label2.Text = "Name";
    // 
    // SagemImagePictureBox
    // 
    this.SagemImagePictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                | System.Windows.Forms.AnchorStyles.Left)
                | System.Windows.Forms.AnchorStyles.Right)));
    this.SagemImagePictureBox.BackColor = System.Drawing.Color.White;
    this.SagemImagePictureBox.Location = new System.Drawing.Point(126, 126);
    this.SagemImagePictureBox.Name = "SagemImagePictureBox";
    this.SagemImagePictureBox.Size = new System.Drawing.Size(111, 139);
    this.SagemImagePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
    // 
    // SagemFWLabel
    // 
    this.SagemFWLabel.Location = new System.Drawing.Point(31, 28);
    this.SagemFWLabel.Name = "SagemFWLabel";
    this.SagemFWLabel.Size = new System.Drawing.Size(66, 20);
    // 
    // label1
    // 
    this.label1.Location = new System.Drawing.Point(3, 28);
    this.label1.Name = "label1";
    this.label1.Size = new System.Drawing.Size(33, 20);
    this.label1.Text = "F/W:";
    // 
    // SCRTabPage
    // 
    this.SCRTabPage.Controls.Add(this.SCRContactCheckBox);
    this.SCRTabPage.Controls.Add(this.SCRStateLabel);
    this.SCRTabPage.Controls.Add(this.SCRATRLabel);
    this.SCRTabPage.Controls.Add(this.SCRProtocolLabel);
    this.SCRTabPage.Controls.Add(this.SCRDeinitLabel);
    this.SCRTabPage.Controls.Add(this.SCRDisconnectLabel);
    this.SCRTabPage.Controls.Add(this.SCRStatusLabel);
    this.SCRTabPage.Controls.Add(this.SCRConnectLabel);
    this.SCRTabPage.Controls.Add(this.SCRInitLabel);
    this.SCRTabPage.Controls.Add(this.SCRStatusButton);
    this.SCRTabPage.Controls.Add(this.SCRDeinitButton);
    this.SCRTabPage.Controls.Add(this.SCRDisconnectButton);
    this.SCRTabPage.Controls.Add(this.SCRConnectButton);
    this.SCRTabPage.Controls.Add(this.SCRInitButton);
    this.SCRTabPage.Location = new System.Drawing.Point(0, 0);
    this.SCRTabPage.Name = "SCRTabPage";
    this.SCRTabPage.Size = new System.Drawing.Size(232, 265);
    this.SCRTabPage.Text = "SCR";
    // 
    // SCRContactCheckBox
    // 
    this.SCRContactCheckBox.Checked = true;
    this.SCRContactCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
    this.SCRContactCheckBox.Location = new System.Drawing.Point(4, 75);
    this.SCRContactCheckBox.Name = "SCRContactCheckBox";
    this.SCRContactCheckBox.Size = new System.Drawing.Size(73, 20);
    this.SCRContactCheckBox.TabIndex = 11;
    this.SCRContactCheckBox.Text = "Contact";
    // 
    // SCRStateLabel
    // 
    this.SCRStateLabel.Font = new System.Drawing.Font("Courier New", 8F, System.Drawing.FontStyle.Regular);
    this.SCRStateLabel.Location = new System.Drawing.Point(7, 153);
    this.SCRStateLabel.Name = "SCRStateLabel";
    this.SCRStateLabel.Size = new System.Drawing.Size(226, 20);
    // 
    // SCRATRLabel
    // 
    this.SCRATRLabel.Font = new System.Drawing.Font("Courier New", 8F, System.Drawing.FontStyle.Regular);
    this.SCRATRLabel.Location = new System.Drawing.Point(7, 127);
    this.SCRATRLabel.Name = "SCRATRLabel";
    this.SCRATRLabel.Size = new System.Drawing.Size(226, 20);
    // 
    // SCRProtocolLabel
    // 
    this.SCRProtocolLabel.Font = new System.Drawing.Font("Courier New", 8F, System.Drawing.FontStyle.Regular);
    this.SCRProtocolLabel.Location = new System.Drawing.Point(83, 75);
    this.SCRProtocolLabel.Name = "SCRProtocolLabel";
    this.SCRProtocolLabel.Size = new System.Drawing.Size(150, 20);
    // 
    // SCRDeinitLabel
    // 
    this.SCRDeinitLabel.Font = new System.Drawing.Font("Courier New", 8F, System.Drawing.FontStyle.Regular);
    this.SCRDeinitLabel.Location = new System.Drawing.Point(69, 205);
    this.SCRDeinitLabel.Name = "SCRDeinitLabel";
    this.SCRDeinitLabel.Size = new System.Drawing.Size(164, 20);
    // 
    // SCRDisconnectLabel
    // 
    this.SCRDisconnectLabel.Font = new System.Drawing.Font("Courier New", 8F, System.Drawing.FontStyle.Regular);
    this.SCRDisconnectLabel.Location = new System.Drawing.Point(69, 179);
    this.SCRDisconnectLabel.Name = "SCRDisconnectLabel";
    this.SCRDisconnectLabel.Size = new System.Drawing.Size(164, 20);
    // 
    // SCRStatusLabel
    // 
    this.SCRStatusLabel.Font = new System.Drawing.Font("Courier New", 8F, System.Drawing.FontStyle.Regular);
    this.SCRStatusLabel.Location = new System.Drawing.Point(69, 101);
    this.SCRStatusLabel.Name = "SCRStatusLabel";
    this.SCRStatusLabel.Size = new System.Drawing.Size(164, 20);
    // 
    // SCRConnectLabel
    // 
    this.SCRConnectLabel.Font = new System.Drawing.Font("Courier New", 8F, System.Drawing.FontStyle.Regular);
    this.SCRConnectLabel.Location = new System.Drawing.Point(69, 49);
    this.SCRConnectLabel.Name = "SCRConnectLabel";
    this.SCRConnectLabel.Size = new System.Drawing.Size(164, 20);
    // 
    // SCRInitLabel
    // 
    this.SCRInitLabel.Font = new System.Drawing.Font("Courier New", 8F, System.Drawing.FontStyle.Regular);
    this.SCRInitLabel.Location = new System.Drawing.Point(69, 23);
    this.SCRInitLabel.Name = "SCRInitLabel";
    this.SCRInitLabel.Size = new System.Drawing.Size(164, 20);
    // 
    // SCRStatusButton
    // 
    this.SCRStatusButton.Location = new System.Drawing.Point(7, 101);
    this.SCRStatusButton.Name = "SCRStatusButton";
    this.SCRStatusButton.Size = new System.Drawing.Size(56, 20);
    this.SCRStatusButton.TabIndex = 10;
    this.SCRStatusButton.Text = "Status";
    this.SCRStatusButton.Click += new System.EventHandler(this.SCRStatusButton_Click);
    // 
    // SCRDeinitButton
    // 
    this.SCRDeinitButton.Location = new System.Drawing.Point(7, 205);
    this.SCRDeinitButton.Name = "SCRDeinitButton";
    this.SCRDeinitButton.Size = new System.Drawing.Size(56, 20);
    this.SCRDeinitButton.TabIndex = 9;
    this.SCRDeinitButton.Text = "Deinit";
    this.SCRDeinitButton.Click += new System.EventHandler(this.SCRDeinitButton_Click);
    // 
    // SCRDisconnectButton
    // 
    this.SCRDisconnectButton.Location = new System.Drawing.Point(7, 179);
    this.SCRDisconnectButton.Name = "SCRDisconnectButton";
    this.SCRDisconnectButton.Size = new System.Drawing.Size(56, 20);
    this.SCRDisconnectButton.TabIndex = 8;
    this.SCRDisconnectButton.Text = "Dscnct";
    this.SCRDisconnectButton.Click += new System.EventHandler(this.SCRDisconnectButton_Click);
    // 
    // SCRConnectButton
    // 
    this.SCRConnectButton.Location = new System.Drawing.Point(7, 49);
    this.SCRConnectButton.Name = "SCRConnectButton";
    this.SCRConnectButton.Size = new System.Drawing.Size(56, 20);
    this.SCRConnectButton.TabIndex = 7;
    this.SCRConnectButton.Text = "Connect";
    this.SCRConnectButton.Click += new System.EventHandler(this.SCRConnectButton_Click);
    // 
    // SCRInitButton
    // 
    this.SCRInitButton.Location = new System.Drawing.Point(7, 23);
    this.SCRInitButton.Name = "SCRInitButton";
    this.SCRInitButton.Size = new System.Drawing.Size(56, 20);
    this.SCRInitButton.TabIndex = 6;
    this.SCRInitButton.Text = "Init";
    this.SCRInitButton.Click += new System.EventHandler(this.SCRInitButton_Click);
    // 
    // LAPTabPage
    // 
    this.LAPTabPage.Controls.Add(this.LAPPWLAPButton);
    this.LAPTabPage.Controls.Add(this.LAPPIVLAPButton);
    this.LAPTabPage.Location = new System.Drawing.Point(0, 0);
    this.LAPTabPage.Name = "LAPTabPage";
    this.LAPTabPage.Size = new System.Drawing.Size(232, 265);
    this.LAPTabPage.Text = "LAP";
    // 
    // LAPPWLAPButton
    // 
    this.LAPPWLAPButton.Location = new System.Drawing.Point(45, 124);
    this.LAPPWLAPButton.Name = "LAPPWLAPButton";
    this.LAPPWLAPButton.Size = new System.Drawing.Size(72, 20);
    this.LAPPWLAPButton.TabIndex = 1;
    this.LAPPWLAPButton.Text = "Disable";
    this.LAPPWLAPButton.Click += new System.EventHandler(this.LAPPWLAPButton_Click);
    // 
    // LAPPIVLAPButton
    // 
    this.LAPPIVLAPButton.Location = new System.Drawing.Point(45, 62);
    this.LAPPIVLAPButton.Name = "LAPPIVLAPButton";
    this.LAPPIVLAPButton.Size = new System.Drawing.Size(72, 20);
    this.LAPPIVLAPButton.TabIndex = 0;
    this.LAPPIVLAPButton.Text = "Enable";
    this.LAPPIVLAPButton.Click += new System.EventHandler(this.LAPPIVLAPButton_Click);
    // 
    // PIVMSRDataTimer
    // 
    this.PIVMSRDataTimer.Tick += new System.EventHandler(this.PIVMSRDataTimer_Tick);
    // 
    // PIVSCRTimer
    // 
    this.PIVSCRTimer.Tick += new System.EventHandler(this.PIVSCRTimer_Tick);
    // 
    // PIVControlForm
    // 
    this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
    this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
    this.AutoScroll = true;
    this.ClientSize = new System.Drawing.Size(240, 294);
    this.Controls.Add(this.TabControl);
    this.Name = "PIVControlForm";
    this.Text = "CN3-PIV-CONTROL";
    this.Load += new System.EventHandler(this.PIVControlForm_Load);
    this.Closing += new System.ComponentModel.CancelEventHandler(this.PIVControlForm_Closing);
    this.DebugTabPage.ResumeLayout(false);
    this.TabControl.ResumeLayout(false);
    this.PIVTabPage.ResumeLayout(false);
    this.AboutTabPage.ResumeLayout(false);
    this.MSRTabPage.ResumeLayout(false);
    this.FPRTabPage.ResumeLayout(false);
    this.SCRTabPage.ResumeLayout(false);
    this.LAPTabPage.ResumeLayout(false);
    this.ResumeLayout(false);

  }

  #endregion

  private System.Windows.Forms.CheckBox DBOpenCloseCheckBox;
  private System.Windows.Forms.ComboBox DBSerialComboBox;
  private System.Windows.Forms.TabPage DebugTabPage;
  private System.Windows.Forms.TabControl TabControl;
  private System.Windows.Forms.TextBox DebugTextBox;
  private System.Windows.Forms.TabPage FPRTabPage;
  private System.Windows.Forms.Label label1;
  private System.Windows.Forms.Label SagemFWLabel;
  private System.Windows.Forms.CheckBox DebugCheckBox;
  private System.Windows.Forms.PictureBox SagemImagePictureBox;
  private System.Windows.Forms.RadioButton DBEnrollRadioButton;
  private System.Windows.Forms.RadioButton DBVerifyRadioButton;
  private System.Windows.Forms.TextBox DBNameTextBox;
  private System.Windows.Forms.Label label2;
  private System.Windows.Forms.Label DBStatusLabel;
  private System.Windows.Forms.Button DBGoButton;
  private System.Windows.Forms.TabPage AboutTabPage;
  private System.Windows.Forms.Label label4;
  private System.Windows.Forms.CheckBox DBTimeoutCheckbox;
  private System.Windows.Forms.NumericUpDown DBTimeoutUpDown;
  private System.Windows.Forms.Button DBCancelButton;
  private System.Windows.Forms.TabPage MSRTabPage;
  private System.Windows.Forms.CheckBox MSROpenCloseCheckBox;
  private System.Windows.Forms.ComboBox MSRSerialComboBox;
  private System.Windows.Forms.Button MSRClearTextButton;
  private System.Windows.Forms.Label MSRFWLabel;
  private System.Windows.Forms.Label label5;
  private System.Windows.Forms.TextBox MSRTrack3DataTextBox;
  private System.Windows.Forms.TextBox MSRTrack2DataTextBox;
  private System.Windows.Forms.TextBox MSRTrack1DataTextBox;
  private System.Windows.Forms.Label label7;
  private System.Windows.Forms.Label label6;
  private System.Windows.Forms.Label label3;
  private System.Windows.Forms.Button MSRClrLastButton;
  private System.Windows.Forms.Button MSRGetLastButton;
  private System.Windows.Forms.Button MSRPingButton;
  private System.Windows.Forms.Label MSRByteCountLabel;
  private System.Windows.Forms.Button MSRByteCountButton;
  private System.Windows.Forms.Button MSRByteCountResetButton;
  private System.Windows.Forms.Button MSRRefreshButton;
  private System.Windows.Forms.Button SagemRefreshButton;
  private System.Windows.Forms.Label Power5VStatusLabel;
  private System.Windows.Forms.Label PowerCCStatusLabel;
  private System.Windows.Forms.Label PowerFPStatusLabel;
  private System.Windows.Forms.Button PowerSetButton;
  private System.Windows.Forms.CheckBox PowerCCCheckBox;
  private System.Windows.Forms.CheckBox Power5VCheckBox;
  private System.Windows.Forms.CheckBox PowerFPCheckBox;
  private System.Windows.Forms.Button PowerGetButton;
  private System.Windows.Forms.TabPage SCRTabPage;
  private System.Windows.Forms.Label label10;
  private System.Windows.Forms.Label label9;
  private System.Windows.Forms.Label label8;
  private System.Windows.Forms.Button FPRPingButton;
  private System.Windows.Forms.Button SCRInitButton;
  private System.Windows.Forms.Button SCRConnectButton;
  private System.Windows.Forms.Button SCRDisconnectButton;
  private System.Windows.Forms.Button SCRDeinitButton;
  private System.Windows.Forms.Button SCRStatusButton;
  private System.Windows.Forms.Label SCRDeinitLabel;
  private System.Windows.Forms.Label SCRDisconnectLabel;
  private System.Windows.Forms.Label SCRStatusLabel;
  private System.Windows.Forms.Label SCRConnectLabel;
  private System.Windows.Forms.Label SCRInitLabel;
  private System.Windows.Forms.Label SCRProtocolLabel;
  private System.Windows.Forms.Label SCRATRLabel;
  private System.Windows.Forms.Label SCRStateLabel;
  private System.Windows.Forms.TabPage PIVTabPage;
  private System.Windows.Forms.CheckBox PIVSCRCheckBox;
  private System.Windows.Forms.CheckBox PIVFPRCheckBox;
  private System.Windows.Forms.CheckBox PIVMSRCheckBox;
  private System.Windows.Forms.TextBox PIVMSRTrack1DataTextBox;
  private System.Windows.Forms.Label PIVMSRTrack3DataLabel;
  private System.Windows.Forms.Label PIVMSRTrack2DataLabel;
  private System.Windows.Forms.Label PIVMSRTrack1DataLabel;
  private System.Windows.Forms.Timer PIVMSRDataTimer;
  private System.Windows.Forms.TextBox PIVMSRTrack3DataTextBox;
  private System.Windows.Forms.TextBox PIVMSRTrack2DataTextBox;
  private System.Windows.Forms.PictureBox PIVFPRImagePictureBox;
  private System.Windows.Forms.Label PIVFPRFWVersionLabel;
  private System.Windows.Forms.Label PIVFPRFWLabel;
  private System.Windows.Forms.Button PIVFPRCancelButton;
  private System.Windows.Forms.Button PIVFPRGoButton;
  private System.Windows.Forms.RadioButton PIVFPREnrollRadioButton;
  private System.Windows.Forms.RadioButton PIVFPRVerifyRadioButton;
  private System.Windows.Forms.Label PIVFPRNameLabel;
  private System.Windows.Forms.NumericUpDown PIVFPRTimeoutUpDown;
  private System.Windows.Forms.CheckBox PIVFPRTimeoutCheckbox;
  private System.Windows.Forms.TextBox PIVFPRNameTextBox;
  private System.Windows.Forms.Label PIVFPRStatusLabel;
  private System.Windows.Forms.Button PIVFPRClearDBButton;
  private System.Windows.Forms.Button AboutPortsButton;
  private System.Windows.Forms.Label AboutPortsLabel;
  private System.Windows.Forms.Label PIVMSRFWVersionLabel;
  private System.Windows.Forms.Label PIVMSRFWLabel;
  private System.Windows.Forms.TextBox PIVSCRATRDataTextBox;
  private System.Windows.Forms.Label PIVSCRATRLabel;
  private System.Windows.Forms.Timer PIVSCRTimer;
  private System.Windows.Forms.Label PIVSCRStatusLabel;
  private System.Windows.Forms.Label PIVSCRProtocolLabel;
  private System.Windows.Forms.Label PIVSCRProtocolDataLabel;
  private System.Windows.Forms.Label PIVSCRStatusDataLabel;
  private System.Windows.Forms.Label AboutWSQDLLVersionLabel;
  private System.Windows.Forms.TabPage LAPTabPage;
  private System.Windows.Forms.Button LAPPWLAPButton;
  private System.Windows.Forms.Button LAPPIVLAPButton;
  private System.Windows.Forms.Label label11;
  private System.Windows.Forms.Label label13;
  private System.Windows.Forms.Label label12;
  private Microsoft.WindowsCE.Forms.InputPanel PIVInputPanel;
  private System.Windows.Forms.CheckBox PIVFPRFlipCheckBox;
  private System.Windows.Forms.PictureBox PIVFPRSIPPictureBox;
  private System.Windows.Forms.Button DBUnflipButton;
  private System.Windows.Forms.CheckBox SCRContactCheckBox;
  private System.Windows.Forms.Button DebugClearButton;
  private System.Windows.Forms.Label AboutOKPWRCEDLLVersionLabel;
  private System.Windows.Forms.Button AboutOpenButton;
  private System.Windows.Forms.Button AboutCloseButton;
  private System.Windows.Forms.Button AboutAntennaButton;
  private System.Windows.Forms.Button AboutReaderButton;
  private System.Windows.Forms.CheckBox AboutReaderCheckBox;
  private System.Windows.Forms.Button AboutIdleButton;
  private System.Windows.Forms.CheckBox AboutAntennaCheckBox;
  private System.Windows.Forms.CheckBox AboutIdleCheckBox;
  private System.Windows.Forms.Button PowerSaveButton;
  private System.Windows.Forms.Button AboutDeinitButton;
  private System.Windows.Forms.Button AboutInitButton;
  private System.Windows.Forms.CheckBox AboutCLCheckBox;
}
