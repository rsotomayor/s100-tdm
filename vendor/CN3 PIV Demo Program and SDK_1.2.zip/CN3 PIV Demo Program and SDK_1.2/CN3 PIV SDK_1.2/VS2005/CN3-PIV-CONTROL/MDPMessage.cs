//
////////////////////////////////////////////////////////////////////////////////
//
/// \file MDPMessage.cs
/// \brief Implementation file for the MDPMessage object and its parser,
///        MDPMessageParser.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009 Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//
using System;
using System.Collections;
using System.Diagnostics;

#region public class MDPMessage
/// <summary>
/// MDPMessage is an object which encapsulates the MDP protocol messages as a
/// deriviation of ParseableMessage.
/// 
/// The MDP (Minimum Datagram Protocol) consists of the just a sync byte (0x21
/// or ASCII '!'), a one-byte 'port' number, a one-byte message length and up
/// to 0xFF bytes of message data, like so...
/// 
/// [0x21] -- sync byte ASCII '!'
/// 
/// [0x82] -- message 'port'
/// 
/// [0x06] -- data length
/// 
/// [0xAB] -- first data byte
/// 
/// [0xCD]
/// 
/// [0xEF]
/// 
/// [0xFE]
/// 
/// [0xDC]
/// 
/// [0xBA] -- last data byte
/// 
/// The 'port' value can be used to multiples up to 255 'ports' on a single
/// data channel or can be used as a simple message ID value.  This is
/// application-specific.
/// 
/// Any data error checking values such as checksums or CRCs must be added to
/// the 'data' field along with message data.  This is also
/// application-specific.
/// </summary>
public class MDPMessage : ParseableMessage
{
  #region Constants

  /// <summary>
  /// Sync byte - '!'.
  /// </summary>
  public const byte SyncByte = 0x21;

  /// <summary>
  /// Index of sync byte in MDP message.
  /// </summary>
  public const int IndexSyncByte = 0;

  /// <summary>
  /// Index of port in MDP message.
  /// </summary>
  public const int IndexPort = 1;

  /// <summary>
  /// Index of length byte in MDP message.
  /// </summary>
  public const int IndexLength = 2;

  /// <summary>
  /// Index of first data byte in MDP message.
  /// </summary>
  public const int IndexData = 3;

  #endregion

  #region Constructors

  #region MDPMessage()
  /// <summary>
  /// Default constructor - sets up empty but valid message, port 0.
  /// </summary>
  public MDPMessage()
  {
    Create(0, null);
  }
  #endregion

  #region MDPMessage(byte port)
  /// <summary>
  /// Port-only constructor.  Use this to create a message by
  /// specifying the port and data 0 bytes.
  /// </summary>
  /// <param name="port"></param>
  public MDPMessage(byte port)
  {
    Create(port, null);
  }
  #endregion

  #region MDPMessage(byte port, byte[] data)
  /// <summary>
  /// Port and data constructor.  Use this to create a message
  /// specifying the port and data.
  /// </summary>
  /// <param name="port">MDP message port value.</param>
  /// <param name="data">Byte array containing MDP message data.</param>
  public MDPMessage(byte port, byte[] data)
  {
    Create(port, data);
  }
  #endregion

  #region MDPMessage(MDPMessage msg)
  /// <summary>
  /// Copy constructor.  Use this to create a message specifying
  /// an MDPMessage object from which this one will be copied.
  /// </summary>
  /// <param name="msg">MDPMessage from which to copy.</param>
  public MDPMessage(MDPMessage msg)
  {
    Create(msg.Port, msg.Data);
  }
  #endregion

  #endregion Constructors

  #region Methods

  #region protected void Create(byte port, byte[] data)
  /// <summary>
  /// Helper function which constructors can call to populate message.
  /// </summary>
  /// <param name="port">MDP message port value.</param>
  /// <param name="data">Byte array containing MDP message data.</param>
  protected void Create(byte port, byte[] data)
  {
    int len = MDPMessage.IndexData;

    //
    // create the message - null is allowed for no data
    //
    if(data != null)
    {
      len += data.Length;
    }
    m_pui8Message = new byte[len];
    m_pui8Message[MDPMessage.IndexSyncByte] = MDPMessage.SyncByte;
    m_pui8Message[MDPMessage.IndexPort] = port;
    if(data != null)
    {
      m_pui8Message[MDPMessage.IndexLength] = (byte)data.Length;
      for(int i=0; i<data.Length; i++)
      {
        m_pui8Message[MDPMessage.IndexData + i] = data[i];
      }
    }
    else
    {
      m_pui8Message[MDPMessage.IndexLength] = 0;
    }

    //
    // void return from helper - message created
    //
    return;
  }
  #endregion

  #endregion

  #region Properties

  #region public byte[] Data
  /// <summary>
  /// Returns the data section of the MDP message, without sync byte, port, or length.
  /// </summary>
  public byte[] Data
  {
    get
    {
      byte[] b=null;
      if(m_pui8Message != null)
      {
        b = new byte[m_pui8Message.Length - MDPMessage.IndexData];
        for(int i=0; i<b.Length; i++)
        {
          b[i] = m_pui8Message[MDPMessage.IndexData + i];
        }
      }
      return b;
    }
  }
  #endregion

  #region public byte Port
  /// <summary>
  /// Returns the message port value.
  /// </summary>
  public byte Port
  {
    get
    {
      return m_pui8Message[IndexPort];
    }
  }
  #endregion public byte Port

  #region public int DataLength
  /// <summary>
  /// Returns the length of the MDP message data.
  /// </summary>
  public int DataLength
  {
    get
    {
      return m_pui8Message.Length - IndexData;
    }
  }
  #endregion public int DataLength

  #endregion
}
#endregion

#region public class MDPMessageParser
/// <summary>
/// MSRMessageParser is an object which parses MDPMessage objects.
/// </summary>
public class MDPMessageParser : MessageParser
{
  #region Constants

  #region public enum State
  /// <summary>
  /// MDP message parsing state machine states.
  /// </summary>
  #warning <Rename This For Doxygen>
  enum State
  {
    /// <summary>
    /// Waiting for sync byte.
    /// </summary>
    WaitSync,

    /// <summary>
    /// Waiting for message port.
    /// </summary>
    WaitPort,

    /// <summary>
    /// Waiting for message length.
    /// </summary>
    WaitLength,

    /// <summary>
    /// Waiting for data.
    /// </summary>
    WaitData,
  }
  #endregion

  #endregion

  #region Members

  /// <summary>
  /// State machine state variable
  /// </summary>
  State m_eState = State.WaitSync;

  /// <summary>
  /// Port of message currently being parsed.
  /// </summary>
  byte m_ui8Port;

  /// <summary>
  /// Length of data in message currently being parsed.
  /// </summary>
  byte m_ui8Length;

  /// <summary>
  /// Length of data already read into message.
  /// </summary>
  byte m_ui8LengthRead;

  /// <summary>
  /// Byte array holding message currently being parsed.
  /// </summary>
  byte[] m_pui8Data;

  #endregion

  #region Constructors

  #region public MDPMessageParser()
  /// <summary>
  /// Default constructor does nothing; this object exists to parse messages.
  /// </summary>
  public MDPMessageParser()
  {
  }
  #endregion

  #endregion Constructors

  #region Methods

  #region public virtual void Init()
  /// <summary>
  /// Parsing engine initialization function, called by
  /// ParsingSerialPort::PreOpen() at port open time.  It just sets the
  /// MDP message framing state machine to 'waiting for sync byte'.
  /// </summary>
  public override void Init()
  {
    m_eState = State.WaitSync;
  }
  #endregion

  #region public override ParseableMessage Parse(byte b)
  /// <summary>
  /// Message-parsing state machine method.  Call this method once for each
  /// byte received on the data channel.  This method will return an 
  /// MDPMessage object each time one is well-framed.
  /// </summary>
  /// <param name="b">Byte from data channel.</param>
  /// <returns>ParseableMessage when one is framed; null otherwise.</returns>
  public override ParseableMessage Parse(byte b)
  {
    MDPMessage msg = null;

    //
    // parsing depends on state and then red from data channel
    //
    switch(m_eState)
    {
      //
      // by default and when waiting for sync byte, move to
      // 'wait for port' when sync byte found.
      //
      default:
      case State.WaitSync:
      {
        m_eState = State.WaitSync;
        if(b == MDPMessage.SyncByte)
        {
          m_eState = State.WaitPort;
        }
      }
      break;

      //
      // when waiting for port, just save it off and move to
      // 'waiting for length' state.
      //
      case State.WaitPort:
      {
        m_ui8Port = b;
        m_eState = State.WaitLength;
      }
      break;

      //
      // when waiting for length, save it off and move to
      // 'waiting for data' if its > 0, else create no-data
      // message and move to 'waiting for sync'.
      //
      case State.WaitLength:
      {
        m_ui8Length = b;
        if(m_ui8Length > 0)
        {
          m_pui8Data = new byte[m_ui8Length];
          m_ui8LengthRead = 0;
          m_eState = State.WaitData;
        }
        else
        {
          msg = new MDPMessage(m_ui8Port);
          m_eState = State.WaitSync;
        }
      }
      break;

      //
      // when waiting for data, save it off into array until
      // all data read, then create message and move to 'waiting
      // for sync' state.
      //
      case State.WaitData:
      {
        m_pui8Data[m_ui8LengthRead++] = b;
        if(m_ui8LengthRead == m_ui8Length)
        {
          msg = new MDPMessage(m_ui8Port, m_pui8Data);
          m_eState = State.WaitSync;
        }
      }
      break;
    }

    //
    // return value is message object when parsed, null otherwise
    //
    return msg;
  }
  #endregion

  #endregion Methods
}
#endregion
