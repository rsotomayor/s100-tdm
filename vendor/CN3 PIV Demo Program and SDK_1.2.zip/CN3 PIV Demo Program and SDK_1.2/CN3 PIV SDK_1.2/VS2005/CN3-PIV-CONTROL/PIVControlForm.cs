//
////////////////////////////////////////////////////////////////////////////////
//
/// \file PIVControlForm.cs
/// \brief Implementation file for the PIVControlForm form.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009 Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//
using System;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Xml.Serialization;
using System.Windows.Forms;
using Microsoft.Win32;
using Microsoft.WindowsCE.Forms;

/// <summary>
/// Main application form.  Contains UI elements to exercise all functions
/// of CN3PIV.
/// </summary>
public partial class PIVControlForm : Form
{
  #region Dll Imports

  /// <summary>
  /// See http://msdn.microsoft.com/en-us/library/aa922914.aspx.
  /// </summary>
  [DllImport("coredll.dll")]
  private static extern int LASSReloadConfig();

  /// <summary>
  /// See http://msdn.microsoft.com/en-us/library/ms885627.aspx.
  /// </summary>
  /// <returns>Last error code set by Windows API.</returns>
  [DllImport("coredll.dll")]
  private static extern uint GetLastError();

  #endregion

  #region Members

  /// <summary>
  /// The one and only CN3 PIV object encapsulates all the hardware.
  /// </summary>
  CN3PIV m_cn3piv;

  /// <summary>
  /// String which holds the MS unit firmware version
  /// </summary>
  string m_msusbVersionString;

  /// <summary>
  /// Array list of 'database' entries.
  /// </summary>
  ArrayList m_entries;

  /// <summary>
  /// MSUSB message containing ILV with minutiae we're tyring to match.
  /// </summary>
  MSUSBMessage m_searchTemplate;

  /// <summary>
  /// Index into database of match we're currently trying.
  /// </summary>
  int m_verifyMatchIndex;

  /// <summary>
  /// This lets us check the contact and contactless readers in pingpong fashion.
  /// </summary>
  bool bContact=false;

  /// <summary>
  /// Options dialog for card reader turn-on.
  /// </summary>
  SCROptions m_scrOptions;

  int m_hReader=0;

  #endregion

  #region Constructors

  #region public PIVControlForm()
  /// <summary>
  /// Default constructor.  Creates form, instantiates and initializes
  /// CN3PIV object, creates empty database if none existss, reads database,
  /// sets UI according to database contents.
  /// </summary>
  public PIVControlForm()
  {
    InitializeComponent();

    m_scrOptions = new SCROptions();
    m_scrOptions.ContactAntennaOnCheckBox.Checked = true;
    m_scrOptions.ContactIdleModeCheckBox.Checked = false;
    m_scrOptions.ContactReaderOnCheckBox.Checked = true;
    m_scrOptions.ContactlessAntennaOnCheckBox.Checked = true;
    m_scrOptions.ContactlessIdleModeCheckBox.Checked = false;
    m_scrOptions.ContactlessReaderOnCheckBox.Checked = true;

    m_cn3piv = new CN3PIV(this);

    m_cn3piv.HandleMSRMessage += HandleMSRMessage;

    m_cn3piv.HandleMSRMessagePing += HandleMSRMessagePing;

    m_cn3piv.HandleMSRMessageDataClear += HandleMSRMessageDataClear;

    m_cn3piv.HandleMSRMessageTrack1Data += HandleMSRMessageTrack1Data;
    m_cn3piv.HandleMSRMessageTrack2Data += HandleMSRMessageTrack2Data;
    m_cn3piv.HandleMSRMessageTrack3Data += HandleMSRMessageTrack3Data;

    m_cn3piv.HandleMSRMessagePower += HandleMSRMessagePower;

    m_cn3piv.HandleMSRReadException += HandleMSRReadException;

    m_cn3piv.HandleSagemMessage += HandleSagemMessage;
    m_cn3piv.HandleILVGetDescriptor += HandleILVGetDescriptor;
    m_cn3piv.HandleILVAsynchronousMessage += HandleILVAsynchronousMessage;
    m_cn3piv.HandleILVVerifyMatch += HandleILVVerifyMatch;
    m_cn3piv.HandleILVOther += HandleILVOther;

    m_cn3piv.HandleSagemReadException += HandleSagemReadException;

    m_cn3piv.HandleResume += HandleResume;

    int iVersion=0;
    try
    {
      iVersion = m_cn3piv.GetWSQDLLVersion();
    }
    catch
    {
    }
    if(iVersion != 0)
    {
      string s="";
      byte b = (byte)((iVersion >> 24) & 0x000000FF);
      if(b != 0)
      {
        s += b.ToString();
      }
      b = (byte)((iVersion >> 16) & 0x000000FF);
      s += b.ToString() + ".";
      b = (byte)((iVersion >> 8) & 0x000000FF);
      s += b.ToString();
      b = (byte)((iVersion) & 0x000000FF);
      s += b.ToString();
      AboutWSQDLLVersionLabel.Text = "wsq.dll " + s;
    }
    else
    {
      AboutWSQDLLVersionLabel.Text = "wsq.dll not found";
    }

#if false
    iVersion=0;
    try
    {
      iVersion = m_cn3piv.GetOKPWRCEDLLVersion();
    }
    catch (Exception ex)
    {
      MessageBox.Show(ex.Message);
    }
    if(iVersion != 0)
    {
      string s="";
      byte b = (byte)((iVersion >> 24) & 0x000000FF);
      if(b != 0)
      {
        s += b.ToString();
      }
      b = (byte)((iVersion >> 16) & 0x000000FF);
      s += b.ToString() + ".";
      b = (byte)((iVersion >> 8) & 0x000000FF);
      s += b.ToString();
      b = (byte)((iVersion) & 0x000000FF);
      s += b.ToString();
      AboutOKPWRCEDLLVersionLabel.Text = "okpwrce.dll " + s;
    }
    else
    {
      AboutOKPWRCEDLLVersionLabel.Text = "okpwrce.dll not found";
    }
#endif

    try
    {
      ReadDB();
    }
    catch
    {
      m_entries = new ArrayList();
      SaveDB();
    }

    System.OperatingSystem osInfo = System.Environment.OSVersion;
    if(osInfo.Platform == PlatformID.WinCE)
    {
      TabControl.TabPages.RemoveAt(6);
    }
    TabControl.SelectedIndex = 0;

    UpdateDBUI();
    UpdateMSRUI();
    UpdatePIVUI();
  }
  #endregion

  #endregion

  #region Methods

  #region private void HandleResume(PowerState state)
  /// <summary>
  /// "Resume" power control event handler, called when the \ref
  /// ResumeNotifier object detects a resume event.
  /// </summary>
  /// <param name="state">\ref PowerState variable as sent from \ref
  /// ResumeNotifier object.</param>
  private void HandleResume(PowerState state)
  {
    DebugLine("Resume");
    DebugLine(" PowerState " + ((uint)(state)).ToString("X8"));
    if((state & PowerState.POWER_STATE_ON) == PowerState.POWER_STATE_ON)
    {
      DebugLine("  On");
    }
    if((state & PowerState.POWER_STATE_OFF) == PowerState.POWER_STATE_OFF)
    {
      DebugLine("  Off");
    }
    if((state & PowerState.POWER_STATE_CRITICAL) == PowerState.POWER_STATE_CRITICAL)
    {
      DebugLine("  Crit");
    }
    if((state & PowerState.POWER_STATE_BOOT) == PowerState.POWER_STATE_BOOT)
    {
      DebugLine("  Boot");
    }
    if((state & PowerState.POWER_STATE_IDLE) == PowerState.POWER_STATE_IDLE)
    {
      DebugLine("  Idle");
    }
    if((state & PowerState.POWER_STATE_SUSPEND) == PowerState.POWER_STATE_SUSPEND)
    {
      DebugLine("  Suspend");
    }
    if((state & PowerState.POWER_STATE_RESET) == PowerState.POWER_STATE_RESET)
    {
      DebugLine("  Reset");
    }
    DebugLine("");

    UpdateSagemPortList();
    UpdateMSRPortList();
    UpdateDBUI();
    UpdateMSRUI();
    PIVMSRCheckBox.Checked = false;
    PIVFPRCheckBox.Checked = false;
    PIVSCRCheckBox.Checked = false;
    UpdatePIVUI();
  }
  #endregion

  #region private void DebugString() DebugLine()
  /// <summary>
  /// Adds a string to the debug text box, if debug check box is checked.
  /// </summary>
  /// <param name="s">String to add to text box.</param>
  private void DebugString(string s)
  {
    if(DebugCheckBox.Checked)
    {
      DebugTextBox.Text += s;
      DebugTextBox.SelectionStart = DebugTextBox.Text.Length;
      DebugTextBox.ScrollToCaret();
    }
  }
  /// <summary>
  /// Adds a line to the debug text box, if debug check box is checked.
  /// </summary>
  /// <param name="s">String to add to text box.</param>
  private void DebugLine(string s)
  {
    if(DebugCheckBox.Checked) DebugString(s + "\r\n");
  }
  #endregion

  #region private void DisableDBUI()
  /// <summary>
  /// Disables UI elements on the 'Sagem' tab so user cannot modify
  /// parameters during, say, an ENROLL or VERIFY cycle.
  /// </summary>
  private void DisableDBUI()
  {
    DBOpenCloseCheckBox.Enabled = false;
    DBEnrollRadioButton.Enabled = false;
    DBVerifyRadioButton.Enabled = false;
    DBGoButton.Enabled = false;
    DBTimeoutUpDown.Enabled = false;
    DBTimeoutCheckbox.Enabled = false;
    DBNameTextBox.Enabled = false;
    DBCancelButton.Enabled = true;

    PIVFPREnrollRadioButton.Enabled = false;
    PIVFPRVerifyRadioButton.Enabled = false;
    PIVFPRGoButton.Enabled = false;
    PIVFPRTimeoutUpDown.Enabled = false;
    PIVFPRTimeoutCheckbox.Enabled = false;
    PIVFPRNameTextBox.Enabled = false;
    PIVFPRCancelButton.Enabled = true;
}
  #endregion

  #region private void UpdateDBUI()
  /// <summary>
  /// Updates UI elements on the 'Sagem' tab according to system state.
  /// </summary>
  private void UpdateDBUI()
  {
    DBOpenCloseCheckBox.Enabled = true;
    SagemRefreshButton.Enabled = !m_cn3piv.SagemIsOpen;
    DBSerialComboBox.Enabled = !m_cn3piv.SagemIsOpen;
    FPRPingButton.Enabled = m_cn3piv.SagemIsOpen;
    DBGoButton.Enabled = m_cn3piv.SagemIsOpen;
    DBEnrollRadioButton.Enabled = m_cn3piv.SagemIsOpen;
    DBVerifyRadioButton.Enabled = m_cn3piv.SagemIsOpen /*&& (m_entries.Count > 0)*/;
    DBTimeoutCheckbox.Enabled = m_cn3piv.SagemIsOpen;
    DBTimeoutUpDown.Enabled = m_cn3piv.SagemIsOpen && DBTimeoutCheckbox.Checked;
    DBCancelButton.Enabled = false;
    DBNameTextBox.Enabled = m_cn3piv.SagemIsOpen && DBEnrollRadioButton.Checked;
    if(DBVerifyRadioButton.Checked) DBNameTextBox.Text = "";
    if(!m_cn3piv.SagemIsOpen && DBOpenCloseCheckBox.Checked)
    {
      DBOpenCloseCheckBox.Checked = false;
    }

    PIVFPRFlipCheckBox.Enabled = m_cn3piv.SagemIsOpen;
    PIVFPRGoButton.Enabled = m_cn3piv.SagemIsOpen;
    PIVFPREnrollRadioButton.Enabled = m_cn3piv.SagemIsOpen;
    PIVFPRVerifyRadioButton.Enabled = m_cn3piv.SagemIsOpen /*&& (m_entries.Count > 0)*/;
    PIVFPRTimeoutCheckbox.Enabled = m_cn3piv.SagemIsOpen;
    PIVFPRTimeoutUpDown.Enabled = m_cn3piv.SagemIsOpen && PIVFPRTimeoutCheckbox.Checked;
    PIVFPRCancelButton.Enabled = false;
    PIVFPRNameTextBox.Enabled = m_cn3piv.SagemIsOpen && PIVFPREnrollRadioButton.Checked;
    if(PIVFPRVerifyRadioButton.Checked) PIVFPRNameTextBox.Text = "";
  }
  #endregion

  #region private void ReadDB()
  /// <summary>
  /// Reads the XML database into memory.
  /// </summary>
  private void ReadDB()
  {
    XmlSerializer deser = new XmlSerializer(typeof(ArrayList), new Type[] {typeof(DBEntry)});
    FileStream fs = new FileStream("DB.xml", FileMode.Open, FileAccess.Read);
    m_entries = deser.Deserialize(fs) as ArrayList;
    fs.Close();
  }
  #endregion

  #region private void SaveDB()
  /// <summary>
  /// Writes the database to the XML file 'DB.xml'.
  /// </summary>
  private void SaveDB()
  {
    XmlSerializer ser = new XmlSerializer(typeof(ArrayList), new Type[] {typeof(DBEntry)});
    FileStream fs = new FileStream("DB.xml", FileMode.Create, FileAccess.Write);
    ser.Serialize(fs, m_entries);
    fs.Close();
  }
  #endregion

  #region private void ClearDB()
  /// <summary>
  /// Clears the existing database and saves it.
  /// </summary>
  private void ClearDB()
  {
    m_entries.Clear();
    SaveDB();
  }
  #endregion

  #region private void DisplayDBEntry(DBEntry entry)
  /// <summary>
  /// Displays a database entry in the 'Sagem' tab UI elements.
  /// </summary>
  /// <param name="entry">Database entry to display.</param>
  private void DisplayDBEntry(DBEntry entry)
  {
    DBNameTextBox.Text = entry.m_name;
    PIVFPRNameTextBox.Text = entry.m_name;
    //byte[] bmp = m_cn3piv.WSQ2BMP(entry.m_wsq, 1024*256, 0, 0);
    //MemoryStream bmpStream = new MemoryStream(bmp);
    //SagemImagePictureBox.Image = new Bitmap(bmpStream);
  }
  #endregion

  #region private void UpdateSagemPortList()
  /// <summary>
  /// Updates the dropdown list of serial ports on the 'Sagem'
  /// tab so it accurately reflects the system state.
  /// </summary>
  #warning <This Should Be Renamed>
  private void UpdateSagemPortList()
  {
    string[] ports = System.IO.Ports.SerialPort.GetPortNames();

    DBSerialComboBox.Items.Clear();
    for(int i = 0; i < ports.Length; i++)
    {
      DBSerialComboBox.Items.Add(ports[i]);
    }
    if(DBSerialComboBox.Items.Count > 0)
    {
      DBSerialComboBox.Text = (string)DBSerialComboBox.Items[0];
    }
  }
  #endregion

  #region private void UpdateMSRPortList()
  /// <summary>
  /// Updates the dropdown list of serial ports on the 'MSR'
  /// tab so it accurately reflects the system state.
  /// </summary>
  private void UpdateMSRPortList()
  {
    string[] ports = System.IO.Ports.SerialPort.GetPortNames();

    MSRSerialComboBox.Items.Clear();
    for(int i = 0; i < ports.Length; i++)
    {
      MSRSerialComboBox.Items.Add(ports[i]);
    }
    if(MSRSerialComboBox.Items.Count > 0)
    {
      MSRSerialComboBox.Text = (string)MSRSerialComboBox.Items[0];
    }
  }
  #endregion

  #region private void PIVControlForm_Load(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Load event on PIVControlForm.  Just updates the
  /// serial port dropdown list boxes on the 'Sagem' and 'MSR' tabs.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVControlForm_Load(object sender, EventArgs e)
  {
    UpdateSagemPortList();
    UpdateMSRPortList();
  }
  #endregion

  #region private void OpenCloseCheckBox_CheckStateChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for CheckStateChanged event on OpenCloseCheckBox.
  /// Attempts to open the serial port selected on the 'Sagem' tab and, if
  /// successful, sends a 'Get Descriptor' command to retrieve the Sagem
  /// device's firmware version.  Also updates UI elements according to
  /// serial port state.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void OpenCloseCheckBox_CheckStateChanged(object sender, EventArgs e)
  {
    SagemFWLabel.Text = "";
    if(DBOpenCloseCheckBox.Checked)
    {
      //
      // the OpenSagem() call may change the SagemPortName parameter to what
      // it finds the COM port should be, so we change the text in the dropdown
      // to match after the call.
      //
      m_cn3piv.OpenSagem();
      DBSerialComboBox.Text = m_cn3piv.SagemPortName;
      if(m_cn3piv.SagemIsOpen)
      {
        m_cn3piv.SendILVGetDescriptor(MSUSBMessage.ILV.ID_FORMAT_BIN_VERSION);
      }
      else
      {
        MessageBox.Show("Error opening " + DBSerialComboBox.Text);
        DBOpenCloseCheckBox.Checked = false;
      }
    }
    else
    {
      m_cn3piv.CloseSagem();
    }
    UpdateDBUI();
  }
  #endregion

  #region private void DBSerialComboBox_GotFocus(object sender, EventArgs e)
  /// <summary>
  /// Event handler for GotFocus event on DBSerialComboBox.  Updates port
  /// list when the control gets focus, so a 'refresh' button is not
  /// necessary.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void DBSerialComboBox_GotFocus(object sender, EventArgs e)
  {
    #warning <Fix This>
    //UpdateSagemPortList();
  }
  #endregion

  #region private void MSRSerialComboBox_GotFocus(object sender, EventArgs e)
  /// <summary>
  /// Event handler for GotFocus event on MSRSerialComboBox.  Updates port
  /// list when the control gets focus, so a 'refresh' button is not
  /// necessary.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void MSRSerialComboBox_GotFocus(object sender, EventArgs e)
  {
    #warning <Fix This>
    //UpdateMSRPortList();
  }
  #endregion

  #region private void DoVerifyMatchNext()
  /// <summary>
  /// Compares the 'next' entry in the database to the current search
  /// template by sending the VERIFY/MATCH command.
  /// </summary>
  private void DoVerifyMatchNext()
  {
    m_verifyMatchIndex++;
    DBEntry entry = (DBEntry)(m_entries[m_verifyMatchIndex]);
    MSUSBMessage referenceTemplate = new MSUSBMessage(entry.m_minutiae, MSUSBMessageParser.Error.MSUSB_ERROR_NONE);

    ArrayList referenceTemplates = new ArrayList();
    referenceTemplates.Add(referenceTemplate);
    
    m_cn3piv.SendILVVerifyMatch(0x0005, m_searchTemplate, referenceTemplates, true);
  }
  #endregion

  #region private void DoVerifyMatch(MSUSBMessage searchTemplate)
  /// <summary>
  /// Helper function which initiates a search through the database for a
  /// match of the searchTemplate data.  The searchTemplate parameter will
  /// be compared to each entry in the database using the VERIFY MATCH
  /// command in repeated succession.
  /// </summary>
  /// <param name="searchTemplate">MSUSBMessage containing a Biometric Data ILV as returned from an ENROLL message (say).</param>
  private void DoVerifyMatch(MSUSBMessage searchTemplate)
  {
    if(m_entries.Count > 0)
    {
      m_searchTemplate = searchTemplate;
      m_verifyMatchIndex = -1;
      DoVerifyMatchNext();
    }
    else
    {
      UpdateDBUI();
    }
  }
  #endregion

  #region private void DoEnroll()
  /// <summary>
  /// Helper function which checks UI elements and begins an 'ENROLL'
  /// cycle, which grabs a fingerprint from the Sagem device.  Registers
  /// 'handle enroll message by adding to database' handler with the
  /// CN3PIV 'HandleILVEnroll' delegate to handle fingerprint response,
  /// so that fingerprint data is added to database.
  /// </summary>
  #warning <This Should Be Renamed>
  private CN3PIV.Error DoEnroll(ushort ui16Timeout)
  {
    //if(DBNameTextBox.Text.Length > 0)
    //{
      //DisableDBUI();
      m_cn3piv.HandleILVEnroll += HandleILVEnrollAddToDatabase;
      //ushort ui16Timeout = 0;
      //if(DBTimeoutCheckbox.Checked)
      //{
      //  ui16Timeout = (ushort)(DBTimeoutUpDown.Value);
      //}
      CN3PIV.Error err = m_cn3piv.SendILVEnroll(ui16Timeout, 1, 1,
        MSUSBMessage.ILV.MESSAGE_COMMAND_CMD | MSUSBMessage.ILV.MESSAGE_IMAGE_CMD,
        (byte)MSUSBMessage.ILV.BiometricAlgorithmParameter.PK_COMP, true);
      if(err != CN3PIV.Error.None)
      {
        //MessageBox.Show("Error sending FPR command", err.ToString());
        m_cn3piv.HandleILVEnroll -= HandleILVEnrollAddToDatabase;
        //UpdateDBUI();
      }
    //}
    //else
    //{
    //  MessageBox.Show("Name cannot be emtpy.", "Error");
    //}
    return err;
  }
  #endregion

  #region private void DoVerify()
  /// <summary>
  /// Helper function which checks UI elements and begins an 'ENROLL'
  /// cycle, which grabs a fingerprint from the Sagem device.  Registers
  /// 'handle enroll message by searching database' handler with the
  /// CN3PIV 'HandleILVEnroll' delegate to handle fingerprint response,
  /// so that fingerprint minutiae data is searched for in database.
  /// </summary>
  #warning <This Should Be Renamed>
  private CN3PIV.Error DoVerify(ushort ui16Timeout)
  {
    //DisableDBUI();
    //DBNameTextBox.Text = "";
    m_cn3piv.HandleILVEnroll += HandleILVEnrollSearchDatabase;
    //ushort ui16Timeout = 0;
    //if(DBTimeoutCheckbox.Checked)
    //{
    //  ui16Timeout = (ushort)(DBTimeoutUpDown.Value);
    //}
    CN3PIV.Error err = m_cn3piv.SendILVEnroll(ui16Timeout, 1, 1,
      MSUSBMessage.ILV.MESSAGE_COMMAND_CMD | MSUSBMessage.ILV.MESSAGE_IMAGE_CMD,
      (byte)MSUSBMessage.ILV.BiometricAlgorithmParameter.PK_COMP, true);
    if(err != CN3PIV.Error.None)
    {
      //MessageBox.Show("Error sending FPR command", err.ToString());
      m_cn3piv.HandleILVEnroll -= HandleILVEnrollSearchDatabase;
      //UpdateDBUI();
    }
    return err;
  }
  #endregion

  #region private ArrayList ExtractEnroll(MSUSBMessage msg)
  /// <summary>
  /// Helper function which examines an ENROLL message reply and, if it
  /// looks OK, extracts internal ILV messages into an ArrayList.
  /// </summary>
  /// <param name="msg">ENROLL ILV reply message.</param>
  /// <returns>ArrayList containing MSUSBMessage objects which represent
  /// ILV messages contained in ENROLL ILV reply.  Null if ENROLL ILV
  /// message was inappropriate or contained no ILVs.</returns>
  private ArrayList ExtractEnroll(MSUSBMessage msg)
  {
    ArrayList ilvs=null;

    DebugLine("ExtractEnroll+");
    ulong ui64L = msg.L;
    uint ui32L = (uint)ui64L;
    uint ui32LBytes = (uint)(ui64L>>32);

    byte requestStatus = msg.V[0];
    DebugLine("request status " + requestStatus.ToString("X2"));
    if(requestStatus == MSUSBMessage.ILV.ILV_OK)
    {
      byte enrollStatus = msg.V[1];
      DebugLine("enroll status" + enrollStatus.ToString("X2"));
      if(enrollStatus == MSUSBMessage.ILV.ILVSTS_OK)
      {
        DebugLine("enroll successful");
        ilvs = msg.GetILVList(6);
        DebugLine(ilvs.Count.ToString() + " ILVs");
      }
    }

    DebugLine("ExtractEnroll-");
    return ilvs;
  }
  #endregion

  #region private void HandleILVOther(MSUSBMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleILVOther delegate.  This
  /// function is invoked on the application UI thread by the CN3PIV object
  /// when a Sagem message other than those defined by their own delegate
  /// is received.
  /// </summary>
  /// <param name="msg">MSUSBMessage received by CN3PIV object.</param>
  private void HandleILVOther(MSUSBMessage msg)
  {
    ulong ui64L=msg.L;
    uint ui32L = (uint)ui64L;
    uint ui32LBytes = (uint)(ui64L >> 32);
    DebugLine("Other: " + msg.I.ToString("X2") + " " + ui32L.ToString("X8") + " (" + ui32LBytes.ToString() + ")");
  }
  #endregion

  #region private void HandleILVMessageCommandCMD(MSUSBMessage msg)
  /// <summary>
  /// Helper function called when a MESSAGE_COMMAND_CMD is found within an
  /// Asynchronous Message ILV recevied by the CN3PIV object.  Adjusts UI
  /// to tell user what to do with his finger to complete the fingerprint
  /// grab.
  /// </summary>
  /// <param name="msg">MSUSBMessage containing MESSAGE_COMMAND_CMD ILV.</param>
  private void HandleILVMessageCommandCMD(MSUSBMessage msg)
  {
    DebugLine("HandleILVMessageCommandCMD+");
    byte[] pui8V = msg.V;

    uint ui32Command = pui8V[3];
    ui32Command <<= 8;
    ui32Command += pui8V[2];
    ui32Command <<= 8;
    ui32Command += pui8V[1];
    ui32Command <<= 8;
    ui32Command += pui8V[0];
    switch(ui32Command)
    {
      case MSUSBMessage.ILV.MessageCommandCmd.MORPHO_MOVE_NO_FINGER:
        DBStatusLabel.Text = "No Finger";
        PIVFPRStatusLabel.Text = "No Finger";
        break;
      case MSUSBMessage.ILV.MessageCommandCmd.MORPHO_MOVE_FINGER_UP:
        DBStatusLabel.Text = "Move Up";
        PIVFPRStatusLabel.Text = "Move Up";
        break;
      case MSUSBMessage.ILV.MessageCommandCmd.MORPHO_MOVE_FINGER_DOWN:
        DBStatusLabel.Text = "Move Down";
        PIVFPRStatusLabel.Text = "Move Down";
        break;
      case MSUSBMessage.ILV.MessageCommandCmd.MORPHO_MOVE_FINGER_LEFT:
        DBStatusLabel.Text = "Move Left";
        PIVFPRStatusLabel.Text = "Move Left";
        break;
      case MSUSBMessage.ILV.MessageCommandCmd.MORPHO_MOVE_FINGER_RIGHT:
        DBStatusLabel.Text = "Move Right";
        PIVFPRStatusLabel.Text = "Move Right";
        break;
      case MSUSBMessage.ILV.MessageCommandCmd.MORPHO_PRESS_FINGER_HARDER:
        DBStatusLabel.Text = "Press Harder";
        PIVFPRStatusLabel.Text = "Press Harder";
        break;
      case MSUSBMessage.ILV.MessageCommandCmd.MORPHO_LATENT:
        DBStatusLabel.Text = "Latent";
        PIVFPRStatusLabel.Text = "Latent";
        break;
      case MSUSBMessage.ILV.MessageCommandCmd.MORPHO_REMOVE_FINGER:
        DBStatusLabel.Text = "Remove Finger";
        PIVFPRStatusLabel.Text = "Remove Finger";
        break;
      case MSUSBMessage.ILV.MessageCommandCmd.MORPHO_FINGER_OK:
        DBStatusLabel.Text = "Finger OK";
        PIVFPRStatusLabel.Text = "Finger OK";
        break;
      default:
        DBStatusLabel.Text = "";
        PIVFPRStatusLabel.Text = "";
        DebugLine("Command " + ui32Command.ToString() + " unknown");
        break;
    }
    DebugLine("HandleILVMessageCommandCMD-");
  }
  #endregion

  #region private void HandleILVMessageImageCMD(MSUSBMessage msg)
  /// <summary>
  /// Helper function called when a MESSAGE_IMAGE_CMD is found within an
  /// Asynchronous Message ILV recevied by the CN3PIV object.  Adjusts UI
  /// to show fingerprint preview image received in message.
  /// </summary>
  /// <param name="msg">MSUSBMessage containing MESSAGE_IMAGE_CMD ILV.</param>
  private void HandleILVMessageImageCMD(MSUSBMessage msg)
  {
    DebugLine("HandleILVMessageImageCMD+");

    //
    // create .bmp image in memory
    //
    byte[] bmp = m_cn3piv.ILV2BMP(msg, 0);

    //
    // now create a memory stream from the image file in memory and
    // read the bitmap file from it.
    //
    MemoryStream bmpStream = new MemoryStream(bmp);
    SagemImagePictureBox.Image = new Bitmap(bmpStream);
    PIVFPRImagePictureBox.Image = new Bitmap(bmpStream);

    DebugLine("HandleILVMessageImageCMD-");
  }
  #endregion

  #region private void HandleILVAsynchronousMessage(MSUSBMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleILVAsynchronousMessage
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when an Asynchronous Message ILV is received.
  /// </summary>
  /// <param name="msg">MSUSBMessage containing Asynchronous Message ILV.</param>
  private void HandleILVAsynchronousMessage(MSUSBMessage msg)
  {
    DebugLine("HandleILVAsynchronousMessage+");
    ulong ui64L = msg.L;
    uint ui32L = (uint)ui64L;
    uint ui32LBytes = (uint)(ui64L>>32);

    if(msg.V[0] == MSUSBMessage.ILV.ILV_OK)
    {
      ArrayList ilvs = msg.GetILVList(1);
      DebugLine("ILV_OK (" + ilvs.Count.ToString() + " ILVs)");
      for(int i=0; i<ilvs.Count; i++)
      {
        MSUSBMessage m = (MSUSBMessage)ilvs[i];
        switch(m.I)
        {
          case MSUSBMessage.ILV.MESSAGE_COMMAND_CMD:
            HandleILVMessageCommandCMD(m);
            break;
          case MSUSBMessage.ILV.MESSAGE_IMAGE_CMD:
            HandleILVMessageImageCMD(m);
            break;
          default:
            DebugLine("MESSAGE_?_CMD " + m.I.ToString("X2"));
            break;
        }
      }
    }
    else
    {
      DebugLine("ILV_ERROR");
    }
    DebugLine("HandleILVAsynchronousMessage-");
  }
  #endregion

  #region private void HandleILVGetDescriptor(MSUSBMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleILVGetDescriptor
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when a GET DESCRIPTOR ILV is received.
  /// </summary>
  /// <param name="msg">MSUSBMessage containing GET DESCRIPTOR ILV.</param>
  private void HandleILVGetDescriptor(MSUSBMessage msg)
  {
    DebugLine("HandleILVGetDescriptor+");
    ulong ui64L = msg.L;
    uint ui32L = (uint)ui64L;
    uint ui32LBytes = (uint)(ui64L>>32);

    if(ui32L == 0x000B)
    {
      DebugLine("FORMAT_BIN_VERSION");
      ArrayList ilvs = msg.GetILVList(1);
      for(int i=0; i<ilvs.Count; i++)
      {
        MSUSBMessage ilv = (MSUSBMessage)ilvs[i];
        if(ilv.I == MSUSBMessage.ILV.ID_FORMAT_BIN_VERSION)
        {
          m_msusbVersionString = System.Text.Encoding.ASCII.GetString(ilv.V, 0, ilv.V.Length);
          SagemFWLabel.Text = m_msusbVersionString;
          PIVFPRFWVersionLabel.Text = m_msusbVersionString;
          DebugLine("Vers: " + m_msusbVersionString);
        }
      }
    }
    else
    {
      DebugLine("Format Unknown");
    }
    DebugLine("HandleILVGetDescriptor-");
  }
  #endregion

  #region private void HandleILVVerifyMatch(MSUSBMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleILVVerifyMatch
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when a VERIFY MATCH ILV is received.
  /// </summary>
  /// <param name="msg">MSUSBMessage containing VERIFY MATCH ILV.</param>
  private void HandleILVVerifyMatch(MSUSBMessage msg)
  {
    DBEntry entry=null;

    byte rs = msg.V[0];
    byte mr = msg.V[1];
    byte idx = msg.V[2];
    if(rs == MSUSBMessage.ILV.ILV_OK)
    {
      if(mr == MSUSBMessage.ILV.ILVSTS_HIT)
      {
        entry = (DBEntry)(m_entries[m_verifyMatchIndex]);
      }
    }
    else
    {
      DBStatusLabel.Text = "Rdr Resp " + rs.ToString("X2");
      PIVFPRStatusLabel.Text = "Rdr Resp " + rs.ToString("X2");
      m_verifyMatchIndex = m_entries.Count-1;
    }

    if(entry == null)
    {
      if(m_verifyMatchIndex == m_entries.Count-1)
      {
        DBStatusLabel.Text = "No Match Found";
        PIVFPRStatusLabel.Text = "No Match Found";
        UpdateDBUI();
      }
      else
      {
        DoVerifyMatchNext();
      }
    }
    else
    {
      DBStatusLabel.Text = "Match Found";
      PIVFPRStatusLabel.Text = "Match Found";
      UpdateDBUI();
      DisplayDBEntry(entry);
    }
  }
  #endregion

  #region private void HandleILVEnrollAddToDatabase(MSUSBMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleILVEnroll
  /// delegate when the fingerprint information received in the ENROLL
  /// ILV is to be added to the database.  This function is invoked on
  /// the application UI thread by the CN3PIV object when an ENROLL ILV
  /// is received.
  /// </summary>
  /// <param name="msg">MSUSBMessage containing ENROLL ILV.</param>
  private void HandleILVEnrollAddToDatabase(MSUSBMessage msg)
  {
    DebugLine("HandleILVEnrollAddToDatabase+");

    MSUSBMessage imageILV=null;

    ArrayList ilvs = ExtractEnroll(msg);
    if(ilvs != null)
    {
      DBEntry entry = new DBEntry();
      for(int i=0; i<ilvs.Count; i++)
      {
        MSUSBMessage ilv = (MSUSBMessage)ilvs[i];
        switch(ilv.I)
        {
          case MSUSBMessage.ILV.ID_PK_COMP:
          {
            DebugLine(" ID_PK_COMP");
            entry.m_minutiae = ilv.Message;
          }
          break;

          case MSUSBMessage.ILV.ID_EXPORT_IMAGE:
          {
            DebugLine(" ID_EXPORT_IMAGE");
            imageILV = ilv;
          }
          break;

          default:
          {
            DebugLine(" I " + ilv.I.ToString("X2") + " unknown");
          }
          break;
        }
      }

      if(imageILV != null)
      {
        if(MessageBox.Show("Fingerprint OK.  Add to database?", "Add?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
        {
          Cursor.Current = Cursors.WaitCursor;
          {
            entry.m_wsq = m_cn3piv.ILV2WSQ(imageILV);
            if(TabControl.SelectedIndex == 0)
            {
              entry.m_name = PIVFPRNameTextBox.Text;
            }
            else
            {
              entry.m_name = DBNameTextBox.Text;
            }
            m_entries.Add(entry);
            SaveDB();
          }
          Cursor.Current = Cursors.Default;
#if false
          FileStream fs = File.Create("fingerprint.ilv");
          BinaryWriter bw = new BinaryWriter(fs);
          fs.Write(imageILV.Message, 0, imageILV.Message.Length);
          bw.Close();
          fs.Close();

          byte[] bmp = m_cn3piv.ILV2BMP(imageILV, BMPNumberOfColors);
          fs = File.Create("ILV2BMP.bmp");
          bw = new BinaryWriter(fs);
          fs.Write(bmp, 0, bmp.Length);
          bw.Close();
          fs.Close();

          fs = File.Create("ILV2WSQ.wsq");
          bw = new BinaryWriter(fs);
          fs.Write(entry.m_wsq, 0, entry.m_wsq.Length);
          bw.Close();
          fs.Close();

          bmp = m_cn3piv.WSQ2BMP(entry.m_wsq, 1024*256, BMPNumberOfColors, BMPAllColorsImportant);
          fs = File.Create("WSQ2BMP.bmp");
          bw = new BinaryWriter(fs);
          fs.Write(bmp, 0, bmp.Length);
          bw.Close();
          fs.Close();
#endif
        }
      }
      else
      {
        DBStatusLabel.Text = "No ENROLL Image";
        PIVFPRStatusLabel.Text = "No ENROLL Image";
      }
    }
    else
    {
      switch(msg.V[0])
      {
        case MSUSBMessage.ILV.ILVERR_TIMEOUT:
          DBStatusLabel.Text = "Timed Out";
          PIVFPRStatusLabel.Text = "Timed Out";
        break;
        case MSUSBMessage.ILV.ILVERR_CMDE_ABORTED:
          PIVFPRStatusLabel.Text = "Cancelled";
        break;
        default:
          DBStatusLabel.Text = "Rdr Resp " + msg.V[0].ToString("X2");
          PIVFPRStatusLabel.Text = "Rdr Resp " + msg.V[0].ToString("X2");
        break;
      }
    }

    m_cn3piv.HandleILVEnroll -= HandleILVEnrollAddToDatabase;

    UpdateDBUI();
    SystemSettings.ScreenOrientation = ScreenOrientation.Angle0;

    DebugLine("HandleILVEnrollAddToDatabase+");
  }
  #endregion

  #region private void HandleILVEnrollSearchDatabase(MSUSBMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleILVEnroll
  /// delegate when the fingerprint information received in the ENROLL
  /// ILV is to be searched for in the database.  This function is invoked
  /// on the application UI thread by the CN3PIV object when an ENROLL ILV
  /// is received.
  /// </summary>
  /// <param name="msg">MSUSBMessage containing ENROLL ILV.</param>
  private void HandleILVEnrollSearchDatabase(MSUSBMessage msg)
  {
    MSUSBMessage searchTemplateILV = null;

    ArrayList ilvs = ExtractEnroll(msg);
    if(ilvs != null)
    {
      for(int i=0; i<ilvs.Count; i++)
      {
        MSUSBMessage ilv = (MSUSBMessage)ilvs[i];
        switch(ilv.I)
        {
          case MSUSBMessage.ILV.ID_PK_COMP:
          {
            searchTemplateILV = ilv;
          }
          break;
        }
      }
      if(searchTemplateILV != null)
      {
        DoVerifyMatch(searchTemplateILV);
      }
      else
      {
        UpdateDBUI();
      }
    }
    else
    {
      switch(msg.V[0])
      {
        case MSUSBMessage.ILV.ILVERR_TIMEOUT:
          DBStatusLabel.Text = "Timed Out";
          PIVFPRStatusLabel.Text = "Timed Out";
        break;
        case MSUSBMessage.ILV.ILVERR_CMDE_ABORTED:
          DBStatusLabel.Text = "Cancelled";
          PIVFPRStatusLabel.Text = "Cancelled";
        break;
        default:
          DBStatusLabel.Text = "Rdr Resp " + msg.V[0].ToString("X2") + " " + msg.V[1].ToString("X2");
          PIVFPRStatusLabel.Text = "Rdr Resp " + msg.V[0].ToString("X2") + " " + msg.V[1].ToString("X2");
        break;
      }
      UpdateDBUI();
    }

    m_cn3piv.HandleILVEnroll -= HandleILVEnrollSearchDatabase;
    SystemSettings.ScreenOrientation = ScreenOrientation.Angle0;
  }
  #endregion

  #region private void HandleSagemMessage(MSUSBMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleSagemMessage
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when an any ILV is received.
  /// </summary>
  /// <param name="msg">MSUSBMessage containing ILV.</param>
  private void HandleSagemMessage(MSUSBMessage msg)
  {
    ulong ui64L=msg.L;
    uint ui32L = (uint)ui64L;
    uint ui32LBytes = (uint)(ui64L >> 32);
    DebugLine("RX: " + msg.I.ToString("X2") + " " + ui32L.ToString("X8") + " (" + ui32LBytes.ToString() + ")");
  }
  #endregion

  #region private void HandleSagemOpenException(Exception ex)
  /// <summary>
  /// 
  /// </summary>
  /// <param name="ex"></param>
  private void HandleSagemOpenException(Exception ex)
  {
    DebugLine("HandleSagemOpenException: " + ex.Message);
    MessageBox.Show(ex.Message, "HandleSagemOpenException");
  }
  #endregion

  #region private void HandleSagemReadException(Exception ex)
  /// <summary>
  /// Function registered to CN3PIV object's HandleSagemReadException
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when an exception is thrown by the CN3PIV object's
  /// MSUSBSerialPort member's read thread.
  /// </summary>
  /// <param name="ex">Exception thrown by CN3PIV MSUSBSerialPort object.</param>
  private void HandleSagemReadException(Exception ex)
  {
    DebugLine("HandleSagemReadException: " + ex.Message);
    MessageBox.Show(ex.Message, "HandleSagemReadException");
  }
  #endregion

  #region private void DBGoButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on the DBGoButton.  Checks UI and
  /// initiates an 'Enroll' or 'Verify' cycle.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void DBGoButton_Click(object sender, EventArgs e)
  {
    if(DBVerifyRadioButton.Checked)
    {
      DisableDBUI();
      DBNameTextBox.Text = "";
      //m_cn3piv.HandleILVEnroll += HandleILVEnrollSearchDatabase;
      ushort ui16Timeout = 0;
      if(DBTimeoutCheckbox.Checked)
      {
        ui16Timeout = (ushort)(DBTimeoutUpDown.Value);
      }
      //CN3PIV.Error err = m_cn3piv.SendILVEnroll(ui16Timeout, 1, 1,
      //  MSUSBMessage.ILV.MESSAGE_COMMAND_CMD | MSUSBMessage.ILV.MESSAGE_IMAGE_CMD,
      //  (byte)MSUSBMessage.ILV.BiometricAlgorithmParameter.PK_COMP, true);

      CN3PIV.Error err = DoVerify(ui16Timeout);

      if(err != CN3PIV.Error.None)
      {
        MessageBox.Show("Error sending FPR command", err.ToString());
        //m_cn3piv.HandleILVEnroll -= HandleILVEnrollSearchDatabase;
        UpdateDBUI();
      }
    }
    else if(DBEnrollRadioButton.Checked)
    {
      if(DBNameTextBox.Text.Length > 0)
      {
        DisableDBUI();
        //m_cn3piv.HandleILVEnroll += HandleILVEnrollAddToDatabase;
        ushort ui16Timeout = 0;
        if(DBTimeoutCheckbox.Checked)
        {
          ui16Timeout = (ushort)(DBTimeoutUpDown.Value);
        }
        //CN3PIV.Error err = m_cn3piv.SendILVEnroll(ui16Timeout, 1, 1,
        //  MSUSBMessage.ILV.MESSAGE_COMMAND_CMD | MSUSBMessage.ILV.MESSAGE_IMAGE_CMD,
        //  (byte)MSUSBMessage.ILV.BiometricAlgorithmParameter.PK_COMP, true);
        CN3PIV.Error err = DoEnroll(ui16Timeout);
        if(err != CN3PIV.Error.None)
        {
          MessageBox.Show("Error sending FPR command", err.ToString());
          //m_cn3piv.HandleILVEnroll -= HandleILVEnrollAddToDatabase;
          UpdateDBUI();
        }
      }
      else
      {
        MessageBox.Show("Name cannot be emtpy.", "Error");
      }
    }
  }
  #endregion

  #region private void DBEnrollRadioButton_CheckedChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for CheckChanged event on DBEnrollRadioButton.  Causes
  /// udate of UI based on system state.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void DBEnrollRadioButton_CheckedChanged(object sender, EventArgs e)
  {
    UpdateDBUI();
  }
  #endregion

  #region private void DBVerifyRadioButton_CheckedChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for CheckChanged event on DBVerifyRadioButton.  Causes
  /// udate of UI based on system state.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void DBVerifyRadioButton_CheckedChanged(object sender, EventArgs e)
  {
    UpdateDBUI();
  }
  #endregion

  #region private void DBTimeoutCheckbox_CheckStateChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for CheckStateChanged event on DBTimeoutCheckbox.  Causes
  /// udate of UI based on system state.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void DBTimeoutCheckbox_CheckStateChanged(object sender, EventArgs e)
  {
    DBTimeoutUpDown.Enabled = DBTimeoutCheckbox.Checked;
  }
  #endregion

  #region private void DBCancelButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on DBCancelButton.  Sends CANCEL ILV
  /// to Sagem device, which will cancel any current operation.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void DBCancelButton_Click(object sender, EventArgs e)
  {
    CN3PIV.Error err = m_cn3piv.SendILVCancel();
    if(err != CN3PIV.Error.None)
    {
      MessageBox.Show("Error canceling FPR command.", err.ToString());
    }
    UpdateDBUI();
  }
  #endregion

  #region private void UpdateMSRUI()
  /// <summary>
  /// Updates MSR tab UI elements based on system state.
  /// </summary>
  private void UpdateMSRUI()
  {
    MSRSerialComboBox.Enabled = !m_cn3piv.MSRIsOpen;
    MSRRefreshButton.Enabled = !m_cn3piv.MSRIsOpen;
    MSRPingButton.Enabled = m_cn3piv.MSRIsOpen;
    MSRGetLastButton.Enabled = m_cn3piv.MSRIsOpen;
    MSRClrLastButton.Enabled = m_cn3piv.MSRIsOpen;
    PowerFPCheckBox.Enabled = m_cn3piv.MSRIsOpen;
    PowerCCCheckBox.Enabled = m_cn3piv.MSRIsOpen;
    Power5VCheckBox.Enabled = m_cn3piv.MSRIsOpen;
    PowerSetButton.Enabled = m_cn3piv.MSRIsOpen;
    PowerGetButton.Enabled = m_cn3piv.MSRIsOpen;
    MSRByteCountButton.Enabled = m_cn3piv.MSRIsOpen;
    MSRByteCountResetButton.Enabled = m_cn3piv.MSRIsOpen;
    if(!m_cn3piv.MSRIsOpen && MSROpenCloseCheckBox.Checked)
    {
      PowerFPCheckBox.Checked = false;
      PowerCCCheckBox.Checked = false;
      Power5VCheckBox.Checked = false;
      MSROpenCloseCheckBox.Checked = false;
    }
  }
  #endregion

  #region private void HandleMSRMessageTrack1Data(MDPMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleMSRMessageTrack1Data
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when a track one MSR data message is received.
  /// </summary>
  /// <param name="msg">MDPMessage containing track one MSR data.</param>
  private void HandleMSRMessageTrack1Data(MDPMessage msg)
  {
    string s = System.Text.ASCIIEncoding.ASCII.GetString(msg.Data, 0, msg.DataLength);
    MSRTrack1DataTextBox.Text = s;
    if(PIVMSRTrack1DataTextBox.Text.CompareTo(s) != 0)
    {
      PIVMSRTrack1DataTextBox.Text = s;
    }
  }
  #endregion

  #region private void HandleMSRMessageTrack2Data(MDPMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleMSRMessageTrack2Data
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when a track two MSR data message is received.
  /// </summary>
  /// <param name="msg">MDPMessage containing track two MSR data.</param>
  private void HandleMSRMessageTrack2Data(MDPMessage msg)
  {
    string s = System.Text.ASCIIEncoding.ASCII.GetString(msg.Data, 0, msg.DataLength);
    MSRTrack2DataTextBox.Text = s;
    if(PIVMSRTrack2DataTextBox.Text.CompareTo(s) != 0)
    {
      PIVMSRTrack2DataTextBox.Text = s;
    }
  }
  #endregion

  #region private void HandleMSRMessageTrack3Data(MDPMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleMSRMessageTrack2Data
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when a track three MSR data message is received.
  /// </summary>
  /// <param name="msg">MDPMessage containing track three MSR data.</param>
  private void HandleMSRMessageTrack3Data(MDPMessage msg)
  {
    string s = System.Text.ASCIIEncoding.ASCII.GetString(msg.Data, 0, msg.DataLength);
    MSRTrack3DataTextBox.Text = s;
    if(PIVMSRTrack3DataTextBox.Text.CompareTo(s) != 0)
    {
      PIVMSRTrack3DataTextBox.Text = s;
    }
  }
  #endregion

  #region private void HandleMSRMessageTrack1Error(MDPMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleMSRMessageTrack1Error
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when a track one MSR error message is received.
  /// </summary>
  /// <param name="msg">MDPMessage containing the track one MSR error.</param>
  private void HandleMSRMessageTrack1Error(MDPMessage msg)
  {
    MSRTrack1DataTextBox.Text = "[error]";
    PIVMSRTrack1DataTextBox.Text = "[error]";
  }
  #endregion

  #region private void HandleMSRMessageTrack2Error(MDPMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleMSRMessageTrack2Error
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when a track two MSR error message is received.
  /// </summary>
  /// <param name="msg">MDPMessage containing the track two MSR error.</param>
  private void HandleMSRMessageTrack2Error(MDPMessage msg)
  {
    MSRTrack2DataTextBox.Text = "[error]";
    PIVMSRTrack2DataTextBox.Text = "[error]";
  }
  #endregion

  #region private void HandleMSRMessageTrack3Error(MDPMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleMSRMessageTrack3Error
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when a track three MSR error message is received.
  /// </summary>
  /// <param name="msg">MDPMessage containing the track three MSR error.</param>
  private void HandleMSRMessageTrack3Error(MDPMessage msg)
  {
    MSRTrack3DataTextBox.Text = "[error]";
    PIVMSRTrack3DataTextBox.Text = "[error]";
  }
  #endregion

  #region private void HandleMSRMessage(MDPMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleMSRMessage
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when an any MSR message is received.
  /// </summary>
  /// <param name="msg">MDPMessage received by CN3PIV object.</param>
  private void HandleMSRMessage(MDPMessage msg)
  {
    DebugLine("RX: " + msg.ToString());
  }
  #endregion

  #region private void HandleMSRReadException(Exception ex)
  /// <summary>
  /// Function registered to CN3PIV object's HandleMSRReadException
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when its MDPSerialPort object's read thread
  /// throws an exception.
  /// </summary>
  /// <param name="ex">Exception thrown by CN3PIV object's MDPSerialPort object.</param>
  private void HandleMSRReadException(Exception ex)
  {
    DebugLine("HandleMSRReadException: " + ex.Message);
    MessageBox.Show(ex.Message, "HandleMSRReadException");
  }
  #endregion

  #region private void HandleMSRMessagePing(MDPMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleMSRMessagePing
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when an MSR Ping message is received.
  /// </summary>
  /// <param name="msg">MDPMessage received by CN3PIV object.</param>
  private void HandleMSRMessagePing(MDPMessage msg)
  {
    MSRFWLabel.Text = System.Text.ASCIIEncoding.ASCII.GetString(msg.Data, 0, 4);
    PIVMSRFWVersionLabel.Text = System.Text.ASCIIEncoding.ASCII.GetString(msg.Data, 0, 4);
  }
  #endregion

  #region private void HandleMSRMessagePower(MDPMessage msg)
  /// <summary>
  /// Handler for MSR power status message.  Update UI based on current
  /// status of MSR power control.
  /// </summary>
  /// <param name="msg"></param>
  private void HandleMSRMessagePower(MDPMessage msg)
  {
    byte[] data = msg.Data;

    for(int i=0; i<data.Length; i+=2)
    {
      switch(data[i])
      {
        case (byte)(CN3PIV.PowerControl.FP):
        {
          if(data[i+1] == 0x00)
          {
            PowerFPStatusLabel.Text = "Off";
            PowerFPCheckBox.Checked = false;
          }
          else
          {
            PowerFPStatusLabel.Text = "On";
            PowerFPCheckBox.Checked = true;
          }
        }
        break;
        case (byte)(CN3PIV.PowerControl.CC):
        {
          if(data[i+1] == 0x00)
          {
            PowerCCStatusLabel.Text = "Off";
            PowerCCCheckBox.Checked = false;
          }
          else
          {
            PowerCCStatusLabel.Text = "On";
            PowerCCCheckBox.Checked = true;
          }
        }
        break;
        case (byte)(CN3PIV.PowerControl._5V):
        {
          if(data[i+1] == 0x00)
          {
            Power5VStatusLabel.Text = "Off";
            Power5VCheckBox.Checked = false;
          }
          else
          {
            Power5VStatusLabel.Text = "On";
            Power5VCheckBox.Checked = true;
          }
        }
        break;
        default:
          break;
      }
    }
  }
  #endregion

  #region private void HandleMSRMessageDataClear(MDPMessage msg)
  /// <summary>
  /// Function registered to CN3PIV object's HandleMSRMessageDataClear
  /// delegate.  This function is invoked on the application UI thread by
  /// the CN3PIV object when an MSR Data Clear message is received.
  /// </summary>
  /// <param name="msg">MDPMessage received by CN3PIV object.</param>
  private void HandleMSRMessageDataClear(MDPMessage msg)
  {
    MSRTrack1DataTextBox.Text = "";
    MSRTrack2DataTextBox.Text = "";
    MSRTrack3DataTextBox.Text = "";
  }
  #endregion

  #region private void MSROpenCloseCheckBox_CheckStateChanged(object sender, EventArgs e)
  /// <summary>
  /// Attempts to open the serial port selected on the 'MSR' tab and, if
  /// successful, sends a 'Ping' command to retrieve the MSR device's
  /// firmware version (et al).  Also updates UI elements according to
  /// serial port state.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void MSROpenCloseCheckBox_CheckStateChanged(object sender, EventArgs e)
  {
    MSRFWLabel.Text = "";
    if(MSROpenCloseCheckBox.Checked)
    {
      //
      // the OpenMSR() call may change the MSRPortName parameter to what
      // it finds the COM port should be, so we change the text in the dropdown
      // to match after the call.
      //
      m_cn3piv.OpenMSR();
      MSRSerialComboBox.Text = m_cn3piv.MSRPortName;
      if(m_cn3piv.MSRIsOpen)
      {
        MSRTrack1DataTextBox.Text = "";
        MSRTrack2DataTextBox.Text = "";
        MSRTrack3DataTextBox.Text = "";
        #warning <Why Are Three Pings Necessary?>
        m_cn3piv.SendMSRPing();
        m_cn3piv.SendMSRPing();
        m_cn3piv.SendMSRPing();
        m_cn3piv.SendMSRPowerGet();
      }
      else
      {
        MessageBox.Show("Error opening " + MSRSerialComboBox.Text);
        MSROpenCloseCheckBox.Checked = false;
      }
    }
    else
    {
      PowerFPStatusLabel.Text = "";
      PowerCCStatusLabel.Text = "";
      Power5VStatusLabel.Text = "";
      PowerFPCheckBox.Checked = false;
      PowerCCCheckBox.Checked = false;
      Power5VCheckBox.Checked = false;
      m_cn3piv.CloseMSR();
    }
    UpdateMSRUI();
  }
  #endregion

  #region private void MSRClearTextButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on MSRClearTextButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void MSRClearTextButton_Click(object sender, EventArgs e)
  {
    MSRTrack1DataTextBox.Text = "";
    MSRTrack2DataTextBox.Text = "";
    MSRTrack3DataTextBox.Text = "";
  }
  #endregion

  #region private void MSRGetLastButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on MSRGetLastButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void MSRGetLastButton_Click(object sender, EventArgs e)
  {
    CN3PIV.Error err = m_cn3piv.SendMSRDataRequest();
    if(err != CN3PIV.Error.None)
    {
      MessageBox.Show("Error requesting MSR data.", err.ToString());
      UpdateMSRUI();
    }
  }
  #endregion

  #region private void MSRClrLastButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on MSRClrLastButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void MSRClrLastButton_Click(object sender, EventArgs e)
  {
    CN3PIV.Error err = m_cn3piv.SendMSRDataClear();
    if(err != CN3PIV.Error.None)
    {
      MessageBox.Show("Error clearing MSR data.", err.ToString());
      UpdateMSRUI();
    }
  }
  #endregion

  #region private void MSRPingButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on MSRPingButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void MSRPingButton_Click(object sender, EventArgs e)
  {
    MSRFWLabel.Text = "";
    CN3PIV.Error err = m_cn3piv.SendMSRPing();
    if(err != CN3PIV.Error.None)
    {
      MessageBox.Show("Error pinging MSR.", err.ToString());
      UpdateMSRUI();
    }
  }
  #endregion

  #warning <Remove This>
  private void MSRByteCountButton_Click(object sender, EventArgs e)
  {
    MSRByteCountLabel.Text = m_cn3piv.MSRByteCount.ToString();
  }

  #warning <Remove This>
  private void MSRByteCountResetButton_Click(object sender, EventArgs e)
  {
    m_cn3piv.MSRByteCount = 0;
    MSRByteCountLabel.Text = m_cn3piv.MSRByteCount.ToString();
  }

  #region private void PIVControlForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
  /// <summary>
  /// Event handler for Closing event on PIVControlForm.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVControlForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
  {
    m_cn3piv.CloseAndStopAll();
    m_cn3piv.CloseMSR();
    m_cn3piv.CloseSagem();
  }
  #endregion

  #region private void MSRRefreshButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on MSRRefreshButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void MSRRefreshButton_Click(object sender, EventArgs e)
  {
    UpdateMSRPortList();
    if(m_cn3piv.FindMSR())
    {
      MSRSerialComboBox.Text = m_cn3piv.MSRPortName;
      MessageBox.Show("Found MSR on " + m_cn3piv.MSRPortName + ".", "MSR");
    }
    else
    {
      MessageBox.Show("MSR not found.", "Error");
    }
  }
  #endregion

  #region private void SagemRefreshButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on SagemRefreshButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void SagemRefreshButton_Click(object sender, EventArgs e)
  {
    UpdateSagemPortList();
    if(m_cn3piv.FindSagem())
    {
      DBSerialComboBox.Text = m_cn3piv.SagemPortName;
      MessageBox.Show("Found FPR on " + m_cn3piv.SagemPortName + ".", "FPR");
    }
    else
    {
      MessageBox.Show("FPR not found.", "Error");
    }
  }
  #endregion

  #region private void PowerAllGoButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on PowerAllGoButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PowerAllGoButton_Click(object sender, EventArgs e)
  {
    PowerFPStatusLabel.Text = "";
    PowerCCStatusLabel.Text = "";
    Power5VStatusLabel.Text = "";
    CN3PIV.Error err = m_cn3piv.SendMSRPowerSet(PowerFPCheckBox.Checked, PowerCCCheckBox.Checked, Power5VCheckBox.Checked);
    if(err != CN3PIV.Error.None)
    {
      MessageBox.Show("Error setting MSR power.", err.ToString());
      UpdateMSRUI();
    }
  }
  #endregion

  #region private void PowerAllGetButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on PowerAllGetButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PowerAllGetButton_Click(object sender, EventArgs e)
  {
    PowerFPStatusLabel.Text = "";
    PowerCCStatusLabel.Text = "";
    Power5VStatusLabel.Text = "";
    CN3PIV.Error err = m_cn3piv.SendMSRPowerGet();
    if(err != CN3PIV.Error.None)
    {
      MessageBox.Show("Error getting MSR power.", err.ToString());
      UpdateMSRUI();
    }
  }
  #endregion

  #region private void FPRPingButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on FPRPingButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void FPRPingButton_Click(object sender, EventArgs e)
  {
    SagemFWLabel.Text = "";
    CN3PIV.Error err = m_cn3piv.SendILVGetDescriptor(MSUSBMessage.ILV.ID_FORMAT_BIN_VERSION);
    if(err != CN3PIV.Error.None)
    {
      MessageBox.Show("Error pinging FPR.", err.ToString());
      UpdateDBUI();
    }
  }
  #endregion

  #region private void PowerFPCheckBox_CheckStateChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for CheckStateChanged event on PowerFPCheckBox.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PowerFPCheckBox_CheckStateChanged(object sender, EventArgs e)
  {
    if(PowerFPCheckBox.Checked)
    {
      if(PowerCCCheckBox.Checked)
      {
        PowerCCCheckBox.Checked = false;
      }
    }
  }
  #endregion

  #region private void PowerCCCheckBox_CheckStateChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for CheckStateChanged event on PowerCCCheckBox.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PowerCCCheckBox_CheckStateChanged(object sender, EventArgs e)
  {
    if(PowerCCCheckBox.Checked)
    {
      if(PowerFPCheckBox.Checked)
      {
        PowerFPCheckBox.Checked = false;
      }
    }
  }
  #endregion

  #region private void SCRInitButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on SCRInitButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void SCRInitButton_Click(object sender, EventArgs e)
  {
    CN3PIV.Error error = m_cn3piv.SCRInit(CN3PIV.SCARD_SCOPE_USER);
    if(error == CN3PIV.Error.None)
    {
      SCRInitLabel.Text = "OK";
    }
    else
    {
      SCRInitLabel.Text = error.ToString();
    }
    SCRConnectLabel.Text = "";
    SCRProtocolLabel.Text = "";
    SCRStatusLabel.Text = "";
    SCRATRLabel.Text = "";
    SCRStateLabel.Text = "";
    SCRDisconnectLabel.Text = "";
    SCRDeinitLabel.Text = "";
  }
  #endregion

  #region private void SCRConnectButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on SCRConnectButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void SCRConnectButton_Click(object sender, EventArgs e)
  {
    CN3PIV.Error error = m_cn3piv.SCRConnectReader(CN3PIV.SCARD_SHARE_EXCLUSIVE, CN3PIV.SCARD_PROTOCOL_T0 | CN3PIV.SCARD_PROTOCOL_T1, (uint)(SCRContactCheckBox.Checked ? 1 : 0));
    if(error == CN3PIV.Error.None)
    {
      SCRConnectLabel.Text = "OK";
      string protocol="";
      switch(m_cn3piv.SCRActiveProtocol)
      {
        default:
        case CN3PIV.SCARD_PROTOCOL_UNDEFINED:
          protocol = "Undefined";
          break;
        case CN3PIV.SCARD_PROTOCOL_RAW:
          protocol = "Raw";
          break;
        case CN3PIV.SCARD_PROTOCOL_T0:
          protocol = "T=0";
          break;
        case CN3PIV.SCARD_PROTOCOL_T1:
          protocol = "T=1";
          break;
      }
      SCRProtocolLabel.Text = "Protocol: " + protocol;
    }
    else
    {
      SCRConnectLabel.Text = error.ToString();
      SCRProtocolLabel.Text = "";
    }
    SCRStatusLabel.Text = "";
    SCRATRLabel.Text = "";
    SCRStateLabel.Text = "";
    SCRDisconnectLabel.Text = "";
  }
  #endregion

  #region private void SCRStatusButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on SCRStatusButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void SCRStatusButton_Click(object sender, EventArgs e)
  {
    CN3PIV.Error error = m_cn3piv.SCRStatus();
    if(error == CN3PIV.Error.None)
    {
      SCRStatusLabel.Text = "OK";
      byte[] pui8ATRData = m_cn3piv.SCRATRData;
      if(pui8ATRData != null)
      {
        string atrData = pui8ATRData[0].ToString("X2");
        for(int i=1; i<pui8ATRData.Length; i++)
        {
          atrData += " " + pui8ATRData[i].ToString("X2");
        }
        SCRATRLabel.Text = "ATR: " + atrData;
      }
      else
      {
        SCRATRLabel.Text = "ATR: null (?)";
      }
      string sState="";
      uint uiState = m_cn3piv.SCRState;
      switch(uiState)
      {
        case CN3PIV.SCARD_UNKNOWN:
          sState = "UNKNOWN";
          break;
        case CN3PIV.SCARD_ABSENT:
          sState = "ABSENT";
          break;
        case CN3PIV.SCARD_PRESENT:
          sState = "PRESENT";
          break;
        case CN3PIV.SCARD_SWALLOWED:
          sState = "SWALLOWED";
          break;
        case CN3PIV.SCARD_POWERED:
          sState = "POWERED";
          break;
        case CN3PIV.SCARD_NEGOTIABLE:
          sState = "NEGOTIABLE";
          break;
        case CN3PIV.SCARD_SPECIFIC:
          sState = "SPECIFIC";
          break;
      }
      SCRStateLabel.Text = "State: " + uiState.ToString() + " (" + sState + ")";
    }
    else
    {
      SCRStatusLabel.Text = error.ToString();
      SCRATRLabel.Text = "";
      SCRStateLabel.Text = "";
    }
    SCRDisconnectLabel.Text = "";
  }
  #endregion

  #region private void SCRDisconnectButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on SCRDisconnectButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void SCRDisconnectButton_Click(object sender, EventArgs e)
  {
    CN3PIV.Error error = m_cn3piv.SCRDisconnect(CN3PIV.SCARD_LEAVE_CARD);
    if(error == CN3PIV.Error.None)
    {
      SCRDisconnectLabel.Text = "OK";
    }
    else
    {
      SCRDisconnectLabel.Text = error.ToString();
    }
    SCRConnectLabel.Text = "";
    SCRProtocolLabel.Text = "";
    SCRStatusLabel.Text = "";
    SCRATRLabel.Text = "";
    SCRStateLabel.Text = "";
  }
  #endregion

  #region private void SCRDeinitButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on SCRDeinitButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void SCRDeinitButton_Click(object sender, EventArgs e)
  {
    CN3PIV.Error error = m_cn3piv.SCRDeinit();
    if(error == CN3PIV.Error.None)
    {
      SCRDeinitLabel.Text = "OK";
    }
    else
    {
      SCRDeinitLabel.Text = error.ToString();
    }
    SCRInitLabel.Text = "";
    SCRConnectLabel.Text = "";
    SCRProtocolLabel.Text = "";
    SCRStatusLabel.Text = "";
    SCRATRLabel.Text = "";
    SCRStateLabel.Text = "";
    SCRDisconnectLabel.Text = "";
  }
  #endregion

  #region private void UpdatePIVUI()
  /// <summary>
  /// Updates PIV tab UI in accordance with internal variables and state.
  /// </summary>
  private void UpdatePIVUI()
  {
    PIVMSRFWLabel.Visible = PIVMSRCheckBox.Checked;
    PIVMSRFWVersionLabel.Visible = PIVMSRCheckBox.Checked;
    PIVMSRTrack1DataTextBox.Visible = PIVMSRCheckBox.Checked;
    PIVMSRTrack2DataTextBox.Visible = PIVMSRCheckBox.Checked;
    PIVMSRTrack3DataTextBox.Visible = PIVMSRCheckBox.Checked;
    PIVMSRTrack1DataTextBox.Text = "";
    PIVMSRTrack2DataTextBox.Text = "";
    PIVMSRTrack3DataTextBox.Text = "";
    PIVMSRTrack1DataLabel.Visible = PIVMSRCheckBox.Checked;
    PIVMSRTrack2DataLabel.Visible = PIVMSRCheckBox.Checked;
    PIVMSRTrack3DataLabel.Visible = PIVMSRCheckBox.Checked;
    PIVMSRDataTimer.Interval = 250;
    PIVMSRDataTimer.Enabled = PIVMSRCheckBox.Checked && m_cn3piv.MSRIsOpen;

    PIVFPRFWLabel.Visible = PIVFPRCheckBox.Checked;
    PIVFPRFWVersionLabel.Visible = PIVFPRCheckBox.Checked;
    PIVFPREnrollRadioButton.Visible = PIVFPRCheckBox.Checked;
    PIVFPRVerifyRadioButton.Visible = PIVFPRCheckBox.Checked;
    PIVFPRFlipCheckBox.Visible = PIVFPRCheckBox.Checked;
    PIVFPRGoButton.Visible = PIVFPRCheckBox.Checked;
    PIVFPRCancelButton.Visible = PIVFPRCheckBox.Checked;
    PIVFPRTimeoutUpDown.Visible = PIVFPRCheckBox.Checked;
    PIVFPRTimeoutCheckbox.Visible = PIVFPRCheckBox.Checked;
    PIVFPRNameLabel.Visible = PIVFPRCheckBox.Checked;
    PIVFPRNameTextBox.Visible = PIVFPRCheckBox.Checked;
    PIVFPRSIPPictureBox.Visible = PIVFPRCheckBox.Checked;
    PIVFPRStatusLabel.Visible = PIVFPRCheckBox.Checked;
    PIVFPRImagePictureBox.Visible = PIVFPRCheckBox.Checked;
    PIVFPRClearDBButton.Visible = PIVFPRCheckBox.Checked;

    PIVSCRATRDataTextBox.Visible = PIVSCRCheckBox.Checked;
    PIVSCRATRLabel.Visible = PIVSCRCheckBox.Checked;
    PIVSCRProtocolLabel.Visible = PIVSCRCheckBox.Checked;
    PIVSCRProtocolDataLabel.Visible = PIVSCRCheckBox.Checked;
    PIVSCRStatusLabel.Visible = PIVSCRCheckBox.Checked;
    PIVSCRStatusDataLabel.Visible = PIVSCRCheckBox.Checked;
    PIVSCRTimer.Interval = 250;
    PIVSCRTimer.Enabled = PIVSCRCheckBox.Checked;
  }
  #endregion

  #region private void PIVMSRCheckBox_CheckStateChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for CheckStateChanged event on PIVMSRCheckBox.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVMSRCheckBox_CheckStateChanged(object sender, EventArgs e)
  {
    DebugLine("PIVMSRCheckBox_CheckStateChanged+");
    if(PIVMSRCheckBox.Checked)
    {
      Cursor.Current = Cursors.WaitCursor;
      {
        DebugLine(" checked");
        PIVFPRCheckBox.Checked = false;
        PIVSCRCheckBox.Checked = false;

        PIVMSRFWVersionLabel.Text = "";

        DebugLine(" msr port " + m_cn3piv.MSRPortName);
        m_cn3piv.OpenMSR();
        DebugLine(" msr port " + m_cn3piv.MSRPortName);
        if(!m_cn3piv.MSRIsOpen)
        {
          MessageBox.Show("Error opening MSR " + m_cn3piv.MSRPortName, "Error");
          PIVMSRCheckBox.Checked = false;
        }
        else
        {
          #warning <Why Are Three Pings Necessary?>
          m_cn3piv.SendMSRPing();
          m_cn3piv.SendMSRPing();
          m_cn3piv.SendMSRPing();
          DebugLine(" MSR open");
        }
      }
      Cursor.Current = Cursors.Default;
    }
    else
    {
      DebugLine(" unchecked");
      m_cn3piv.CloseMSR();
    }
    UpdatePIVUI();
    DebugLine("PIVMSRCheckBox_CheckStateChanged-");
  }
  #endregion

  #region private void PIVFPRCheckBox_CheckStateChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for CheckStateChanged event on PIVFPRCheckBox.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVFPRCheckBox_CheckStateChanged(object sender, EventArgs e)
  {
    DebugLine("PIVFPRCheckBox_CheckStateChanged+");
    if(PIVFPRCheckBox.Checked)
    {
      DebugLine(" checked");
      PIVMSRCheckBox.Checked = false;
      PIVSCRCheckBox.Checked = false;

      PIVFPRFWVersionLabel.Text = "";
      PIVFPRNameTextBox.Text = "";
      PIVFPRFlipCheckBox.Checked = false;

      Cursor.Current = Cursors.WaitCursor;
      {
        DebugLine(" msr port " + m_cn3piv.MSRPortName);
        m_cn3piv.OpenMSR();
        DebugLine(" msr port " + m_cn3piv.MSRPortName);
        if(m_cn3piv.MSRIsOpen)
        {
          DebugLine(" MSR open");
          #warning <Why Are These Pings Necessary?>
          m_cn3piv.SendMSRPing();
          m_cn3piv.SendMSRPing();
          m_cn3piv.SendMSRPing();
          m_cn3piv.SendMSRPowerSet(true, false, true);
          int iCount=0;
          do
          {
            System.Threading.Thread.Sleep(250);
            iCount++;
            DebugLine(" fpr port " + m_cn3piv.SagemPortName);
            m_cn3piv.OpenSagem();
            DebugLine(" fpr port " + m_cn3piv.SagemPortName);
          } while((iCount < 20) && (!m_cn3piv.SagemIsOpen));
          DebugLine(" iCount " + iCount.ToString());
          if(m_cn3piv.SagemIsOpen)
          {
            DebugLine(" FPR open");
            m_cn3piv.SendILVGetDescriptor(MSUSBMessage.ILV.ID_FORMAT_BIN_VERSION);
          }
          else
          {
            MessageBox.Show("Error opening FPR " + m_cn3piv.SagemPortName, "Error");
            PIVFPRCheckBox.Checked = false;
          }
        }
        else
        {
          MessageBox.Show("Error opening MSR " + m_cn3piv.MSRPortName, "Error");
          PIVFPRCheckBox.Checked = false;
        }
      }
      Cursor.Current = Cursors.Default;
    }
    else
    {
      DebugLine(" unchecked");
      m_cn3piv.CloseSagem();
      if(m_cn3piv.MSRIsOpen)
      {
        DebugLine(" MSR open");
        m_cn3piv.SendMSRPowerSet(false, false, true);
      }
      m_cn3piv.CloseMSR();
    }
    UpdateDBUI();
    UpdatePIVUI();
    DebugLine("PIVFPRCheckBox_CheckStateChanged-");
  }
  #endregion

  #region private void PIVSCRCheckBox_CheckStateChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for CheckStateChanged event on PIVSCRCheckBox.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVSCRCheckBox_CheckStateChanged(object sender, EventArgs e)
  {
    if(PIVSCRCheckBox.Checked)
    {
      //if(m_scrOptions.ShowDialog() == DialogResult.OK)
      //{
        DebugLine(" checked");
        PIVMSRCheckBox.Checked = false;
        PIVFPRCheckBox.Checked = false;

        PIVSCRATRDataTextBox.Text = "";
        PIVSCRProtocolDataLabel.Text = "";
        PIVSCRStatusDataLabel.Text = "";

        Cursor.Current = Cursors.WaitCursor;
        {
          CN3PIV.Error err=CN3PIV.Error.Unknown;

          DebugLine(" msr port " + m_cn3piv.MSRPortName);
          m_cn3piv.OpenMSR();
          DebugLine(" msr port " + m_cn3piv.MSRPortName);
          if(m_cn3piv.MSRIsOpen)
          {
            DebugLine(" MSR open");
            #warning <Why Are These Pings Necessary?>
            m_cn3piv.SendMSRPing();
            m_cn3piv.SendMSRPing();
            m_cn3piv.SendMSRPing();
            m_cn3piv.SendMSRPowerSet(false, true, true);

            int iCount=0;
            do
            {
              DebugLine(" sleeping b4 init");
              System.Threading.Thread.Sleep(250);
              iCount++;
              err = m_cn3piv.SCRInit(CN3PIV.SCARD_SCOPE_USER);
              DebugLine(" init err " + err.ToString());
              if(err != CN3PIV.Error.None)
              {
                DebugLine(" de-initing");
                m_cn3piv.SCRDeinit();
              }
            } while((iCount < 20) && (!m_cn3piv.SCRIsInit));
            DebugLine(" iCount " + iCount.ToString());
            if(!m_cn3piv.SCRIsInit)
            {
              MessageBox.Show("Error initializing SCR", "Error");
              PIVSCRCheckBox.Checked = false;
            }
            else
            {
              System.Threading.Thread.Sleep(1000);
              #warning <Set SCR Options Here>
            }
          }
          else
          {
            MessageBox.Show("Error opening MSR " + m_cn3piv.MSRPortName, "Error");
            PIVSCRCheckBox.Checked = false;
          }
        }
        Cursor.Current = Cursors.Default;
      //}
    }
    else
    {
      DebugLine(" unchecked");
      m_cn3piv.SCRDeinit();
      if(m_cn3piv.MSRIsOpen)
      {
        DebugLine(" MSR open");
        m_cn3piv.SendMSRPowerSet(false, false, true);
      }
      m_cn3piv.CloseMSR();
    }

    UpdatePIVUI();
  }
  #endregion

  #region private void PIVMSRDataTimer_Tick(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Tick event on PIVMSRDataTimer.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVMSRDataTimer_Tick(object sender, EventArgs e)
  {
    if(m_cn3piv.MSRIsOpen)
    {
      CN3PIV.Error err = m_cn3piv.SendMSRDataRequest();
      if(err != CN3PIV.Error.None)
      {
        MessageBox.Show("Error requesting MSR data.", "Error");
        PIVMSRCheckBox.Checked = false;
      }
    }
  }
  #endregion

  #region private void TabControl_SelectedIndexChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for SelectedIndexChanged event on TabControl.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void TabControl_SelectedIndexChanged(object sender, EventArgs e)
  {
    if(TabControl.SelectedIndex == 0)
    {
      UpdatePIVUI();
    }
  }
  #endregion

  #region private void PIVFPRGoButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on PIVFPRGoButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVFPRGoButton_Click(object sender, EventArgs e)
  {
    if(PIVFPRVerifyRadioButton.Checked)
    {
      DisableDBUI();
      if(PIVFPRFlipCheckBox.Checked)
      {
        SystemSettings.ScreenOrientation = ScreenOrientation.Angle180;
      }
      PIVFPRNameTextBox.Text = "";
      //m_cn3piv.HandleILVEnroll += HandleILVEnrollSearchDatabase;
      ushort ui16Timeout = 0;
      if(PIVFPRTimeoutCheckbox.Checked)
      {
        ui16Timeout = (ushort)(PIVFPRTimeoutUpDown.Value);
      }
      //CN3PIV.Error err = m_cn3piv.SendILVEnroll(ui16Timeout, 1, 1,
      //  MSUSBMessage.ILV.MESSAGE_COMMAND_CMD | MSUSBMessage.ILV.MESSAGE_IMAGE_CMD,
      //  (byte)MSUSBMessage.ILV.BiometricAlgorithmParameter.PK_COMP, true);

      CN3PIV.Error err = DoVerify(ui16Timeout);

      if(err != CN3PIV.Error.None)
      {
        MessageBox.Show("Error sending FPR command", err.ToString());
        //m_cn3piv.HandleILVEnroll -= HandleILVEnrollSearchDatabase;
        UpdateDBUI();
      }
    }
    else if(PIVFPREnrollRadioButton.Checked)
    {
      if(PIVFPRNameTextBox.Text.Length > 0)
      {
        DisableDBUI();
        if(PIVFPRFlipCheckBox.Checked)
        {
          SystemSettings.ScreenOrientation = ScreenOrientation.Angle180;
        }
        //m_cn3piv.HandleILVEnroll += HandleILVEnrollAddToDatabase;
        ushort ui16Timeout = 0;
        if(PIVFPRTimeoutCheckbox.Checked)
        {
          ui16Timeout = (ushort)(PIVFPRTimeoutUpDown.Value);
        }
        //CN3PIV.Error err = m_cn3piv.SendILVEnroll(ui16Timeout, 1, 1,
        //  MSUSBMessage.ILV.MESSAGE_COMMAND_CMD | MSUSBMessage.ILV.MESSAGE_IMAGE_CMD,
        //  (byte)MSUSBMessage.ILV.BiometricAlgorithmParameter.PK_COMP, true);
        CN3PIV.Error err = DoEnroll(ui16Timeout);
        if(err != CN3PIV.Error.None)
        {
          MessageBox.Show("Error sending FPR command", err.ToString());
          //m_cn3piv.HandleILVEnroll -= HandleILVEnrollAddToDatabase;
          UpdateDBUI();
        }
      }
      else
      {
        MessageBox.Show("Name cannot be emtpy.", "Error");
      }
    }
  }
  #endregion

  #region private void PIVFPRCancelButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on PIVFPRCancelButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVFPRCancelButton_Click(object sender, EventArgs e)
  {
    CN3PIV.Error err = m_cn3piv.SendILVCancel();
    if(err != CN3PIV.Error.None)
    {
      MessageBox.Show("Error canceling FPR command.", err.ToString());
    }
    UpdateDBUI();
  }
  #endregion

  #region private void PIVFPREnrollRadioButton_CheckedChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for CheckedChanged event on PIVFPREnrollRadioButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVFPREnrollRadioButton_CheckedChanged(object sender, EventArgs e)
  {
    if(PIVFPREnrollRadioButton.Checked)
    {
      PIVFPRNameTextBox.Text = "";
    }
    UpdateDBUI();
  }
  #endregion

  #region private void PIVFPRVerifyRadioButton_CheckedChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for CheckedChanged event on PIVFPRVerifyRadioButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVFPRVerifyRadioButton_CheckedChanged(object sender, EventArgs e)
  {
    UpdateDBUI();
  }
  #endregion

  #region private void PIVFPRTimeoutCheckbox_CheckStateChanged(object sender, EventArgs e)
  /// <summary>
  /// Event handler for PIVFPRTimeoutCheckbox event on PIVFPRTimeoutCheckbox.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVFPRTimeoutCheckbox_CheckStateChanged(object sender, EventArgs e)
  {
    PIVFPRTimeoutUpDown.Enabled = PIVFPRTimeoutCheckbox.Checked;
  }
  #endregion

  #region private void PIVFPRClearDBButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on PIVFPRClearDBButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVFPRClearDBButton_Click(object sender, EventArgs e)
  {
    if(MessageBox.Show("Do you want to clear the existing database?", "Clear DB?", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
    {
      ClearDB();
    }
  }
  #endregion

  #region private void AboutPortsButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on AboutPortsButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void AboutPortsButton_Click(object sender, EventArgs e)
  {
    string msrPortString=null, fprPortString=null;
    Microsoft.Win32.RegistryKey key=null;
    key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("Drivers\\Active");

    if(key != null)
    {
      DebugLine("opened active driver key");
      string[] subKeyNames = key.GetSubKeyNames();
      if(subKeyNames != null)
      {
        for(int i=0; i<subKeyNames.Length; i++)
        {
          DebugLine("subkey " + subKeyNames[i]);
          Microsoft.Win32.RegistryKey subkey=null;
          subkey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey("Drivers\\Active\\" + subKeyNames[i]);
          if(subkey != null)
          {
            object o = subkey.GetValue("Key", (object)null);
            if(o != null)
            {
              string keyString = o.ToString();
              DebugLine("key is " + keyString);
              if(keyString.CompareTo("Drivers\\USB\\ClientDrivers\\USBCDC_Template_PIV_MSR") == 0)
              {
                DebugLine("found MSR port");
                o = subkey.GetValue("Name", (object)null);
                if(o != null)
                {
                  msrPortString = o.ToString();
                  DebugLine("MSR port " + msrPortString);
                }
                else
                {
                  DebugLine("\"Name\" null");
                }
              }
              else if(keyString.CompareTo("Drivers\\USB\\ClientDrivers\\USBCDC_Template_PIV_FPR") == 0)
              {
                DebugLine("found FPR port");
                o = subkey.GetValue("Name", (object)null);
                if(o != null)
                {
                  fprPortString = o.ToString();
                  DebugLine("FPR port " + fprPortString);
                }
                else
                {
                  DebugLine("\"Name\" null");
                }
              }
              if((msrPortString != null) && (fprPortString != null))
              {
                break;
              }
            }
            else
            {
              DebugLine("\"Key\" is null");
            }
          }
          else
          {
            DebugLine("didn't open subkey");
          }
        }
      }
      else
      {
        DebugLine("no subkey name list");
      }
    }
    else
    {
      DebugLine("didn't open active driver key");
    }

    string msr = m_cn3piv.MSRIsOpen ? "open" : "closed";
    string fpr = m_cn3piv.SagemIsOpen ? "open" : "closed";
    AboutPortsLabel.Text = "MSR " + msr + ", FPR " + fpr;
  }
  #endregion

  #region private void PIVSCRTimer_Tick(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Tick event on PIVSCRTimer.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void PIVSCRTimer_Tick(object sender, EventArgs e)
  {
    CN3PIV.Error error = CN3PIV.Error.Unknown;

    DebugLine("PIVSCRTimer_Tick+");
    PIVMSRDataTimer.Enabled = false;
    if(m_cn3piv.SCRIsInit)
    {
      DebugLine(" is init'd");
      if(m_cn3piv.SCRIsConnected)
      {
        DebugLine(" is connected");
        error = m_cn3piv.SCRStatus();
        DebugLine(" error = " + error.ToString());
        if(PIVSCRATRDataTextBox.Text == "")
        {
          DebugLine(" text box blank");
          if(error == CN3PIV.Error.None)
          {
            DebugLine(" showing atr data");
            byte[] atrData = m_cn3piv.SCRATRData;
            string atr = atrData[0].ToString("X2");
            for(int i=1; i<atrData.Length; i++)
            {
              atr += " " + atrData[i].ToString("X2");
            }
            PIVSCRATRDataTextBox.Text = atr;
          }
          else
          {
            DebugLine(" some error");
            PIVSCRATRDataTextBox.Text = "[error]";
          }
        }
        else
        {
          DebugLine(" have atr data");
          if(error == CN3PIV.Error.None)
          {
            DebugLine(" no error, getting state");
            switch(m_cn3piv.SCRState)
            {
              default:
              case CN3PIV.SCARD_UNKNOWN:
                PIVSCRStatusDataLabel.Text = "Unknown";
                break;
              case CN3PIV.SCARD_ABSENT:
                PIVSCRStatusDataLabel.Text = "Absent";
                m_cn3piv.SCRDisconnect(CN3PIV.SCARD_LEAVE_CARD);
                break;
              case CN3PIV.SCARD_PRESENT:
                PIVSCRStatusDataLabel.Text = "Present";
                break;
              case CN3PIV.SCARD_SWALLOWED:
                PIVSCRStatusDataLabel.Text = "Swallowed";
                break;
              case CN3PIV.SCARD_POWERED:
                PIVSCRStatusDataLabel.Text = "Powered";
                break;
              case CN3PIV.SCARD_NEGOTIABLE:
                PIVSCRStatusDataLabel.Text = "Negotiable";
                break;
              case CN3PIV.SCARD_SPECIFIC:
                PIVSCRStatusDataLabel.Text = "Specific";
                break;
            }
          }
          else
          {
            DebugLine(" some error");
            PIVSCRStatusDataLabel.Text = "Error";
          }
        }
      }
      else
      {
        DebugLine(" not connected");
        if(bContact)
        {
          DebugLine(" checking contact");
          error = m_cn3piv.SCRConnectReader(CN3PIV.SCARD_SHARE_EXCLUSIVE, CN3PIV.SCARD_PROTOCOL_T0 | CN3PIV.SCARD_PROTOCOL_T1, 1);
        }
        else
        {
          DebugLine(" checking contactless");
          error = m_cn3piv.SCRConnectReader(CN3PIV.SCARD_SHARE_EXCLUSIVE, CN3PIV.SCARD_PROTOCOL_T0 | CN3PIV.SCARD_PROTOCOL_T1, 0);
        }
        bContact = !bContact;
        DebugLine(" error " + error.ToString());
        if(error == CN3PIV.Error.None)
        {
          DebugLine(" connected OK");
          PIVSCRStatusDataLabel.Text = "Connected";
          string protocol="";
          switch(m_cn3piv.SCRActiveProtocol)
          {
            default:
            case CN3PIV.SCARD_PROTOCOL_UNDEFINED:
              protocol = "Undefined";
              break;
            case CN3PIV.SCARD_PROTOCOL_RAW:
              protocol = "Raw";
              break;
            case CN3PIV.SCARD_PROTOCOL_T0:
              protocol = "T=0";
              break;
            case CN3PIV.SCARD_PROTOCOL_T1:
              protocol = "T=1";
              break;
          }
          PIVSCRProtocolDataLabel.Text = protocol;
        }
        else if(error == CN3PIV.Error.NoCard)
        {
          DebugLine(" no card");
          PIVSCRATRDataTextBox.Text = "";
          PIVSCRProtocolDataLabel.Text = "";
          PIVSCRStatusDataLabel.Text = "Insert Card";
        }
        else
        {
          DebugLine(" error connecting");
          PIVSCRStatusDataLabel.Text = "Connect error " + error.ToString();
          m_cn3piv.SCRDeinit();
          System.Threading.Thread.Sleep(500);
          PIVSCRStatusDataLabel.Text = "Reinitializing...";
          int iCount=0;
          CN3PIV.Error err;
          DebugLine(" trying re-init...");
          do
          {
            DebugLine(" sleeping b4 init");
            System.Threading.Thread.Sleep(250);
            iCount++;
            err = m_cn3piv.SCRInit(CN3PIV.SCARD_SCOPE_USER);
            DebugLine(" init err " + err.ToString());
            if(err != CN3PIV.Error.None)
            {
              DebugLine(" de-initing");
              m_cn3piv.SCRDeinit();
            }
          } while((iCount < 20) && (!m_cn3piv.SCRIsInit));
          DebugLine(" iCount " + iCount.ToString());
          if(err == CN3PIV.Error.None)
          {
            PIVSCRStatusDataLabel.Text = "Reinit OK";
          }
          else
          {
            PIVSCRStatusDataLabel.Text = "Reinit Error";
          }
        }
      }
    }
    else
    {
      DebugLine(" error initing");
      PIVSCRStatusDataLabel.Text = "Init error " + error.ToString();
    }
    PIVMSRDataTimer.Enabled = true;
    DebugLine("PIVSCRTimer_Tick-");
  }
  #endregion

  #region private void LAPPIVLAPButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on LAPPIVLAPButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void LAPPIVLAPButton_Click(object sender, EventArgs e)
  {
    Registry.SetValue(@"HKEY_LOCAL_MACHINE\comm\Security\LASSD\LAP", "ActiveLAP", "lap_piv");
    bool ok = (LASSReloadConfig() != 0);
    MessageBox.Show("Reload " + (ok ? "Succeeded" : "Failed"));
  }
  #endregion

  #region private void LAPPWLAPButton_Click(object sender, EventArgs e)
  /// <summary>
  /// Event handler for Click event on LAPPWLAPButton.
  /// </summary>
  /// <param name="sender">Event sender.</param>
  /// <param name="e">Event args.</param>
  private void LAPPWLAPButton_Click(object sender, EventArgs e)
  {
    Registry.SetValue(@"HKEY_LOCAL_MACHINE\comm\Security\LASSD\LAP", "ActiveLAP", "lap_pw");
    bool ok = (LASSReloadConfig() != 0);
    MessageBox.Show("Reload " + (ok ? "Succeeded" : "Failed"));
  }
  #endregion

  #region private void PIVFPRSIPPictureBox_Click(object sender, EventArgs e)
  private void PIVFPRSIPPictureBox_Click(object sender, EventArgs e)
  {
    PIVInputPanel.Enabled = true;
  }
  #endregion

  #region private void DBUnflipButton_Click(object sender, EventArgs e)
  private void DBUnflipButton_Click(object sender, EventArgs e)
  {
    SystemSettings.ScreenOrientation = ScreenOrientation.Angle0;
  }
  #endregion

  #region private void DebugClearButton_Click(object sender, EventArgs e)
  private void DebugClearButton_Click(object sender, EventArgs e)
  {
    DebugTextBox.Text = "";
  }
  #endregion

  #region private void AboutOpenButton_Click(object sender, EventArgs e)
  private void AboutOpenButton_Click(object sender, EventArgs e)
  {
    int iReader=0;

    iReader = AboutCLCheckBox.Checked ? 0 : 1;
    string name = m_cn3piv.SCRReaderName(iReader);
    MessageBox.Show(name);

    if(m_cn3piv.SCRPower_OpenReader(name, ref m_hReader))
    {
      MessageBox.Show("opened reader handle " + m_hReader.ToString("X8"));
    }
    else
    {
      MessageBox.Show("error opening reader");
    }
  }
  #endregion

  #region private void AboutCloseButton_Click(object sender, EventArgs e)
  private void AboutCloseButton_Click(object sender, EventArgs e)
  {
    if(m_cn3piv.SCRPower_CloseReader(m_hReader))
    {
      MessageBox.Show("closed reader");
    }
    else
    {
      MessageBox.Show("error closing reader");
    }
    m_hReader = 0;
  }
  #endregion

  #region private void AboutAntennaButton_Click(object sender, EventArgs e)
  private void AboutAntennaButton_Click(object sender, EventArgs e)
  {
    if(AboutAntennaCheckBox.Checked)
    {
      if(m_cn3piv.SCRPower_AntennaOn(m_hReader))
      {
        MessageBox.Show("antenna on OK");
      }
      else
      {
        uint ui = GetLastError();
        MessageBox.Show("antenna on ERROR " + ui.ToString());
      }
    }
    else
    {
      if(m_cn3piv.SCRPower_AntennaOff(m_hReader))
      {
        MessageBox.Show("antenna off OK");
      }
      else
      {
        uint ui = GetLastError();
        MessageBox.Show("antenna off ERROR " + ui.ToString());
      }
    }
  }
  #endregion

  #region private void AboutIdleButton_Click(object sender, EventArgs e)
  private void AboutIdleButton_Click(object sender, EventArgs e)
  {
    if(AboutIdleCheckBox.Checked)
    {
      if(m_cn3piv.SCRPower_IdleOn(m_hReader, 0))
      {
        MessageBox.Show("idle on OK");
      }
      else
      {
        uint ui = GetLastError();
        MessageBox.Show("idle on ERROR" + ui.ToString());
      }
    }
    else
    {
      if(m_cn3piv.SCRPower_IdleOff(m_hReader))
      {
        MessageBox.Show("idle off OK");
      }
      else
      {
        uint ui = GetLastError();
        MessageBox.Show("idle off ERROR " + ui.ToString());
      }
    }
  }
  #endregion

  #region private void AboutReaderButton_Click(object sender, EventArgs e)
  private void AboutReaderButton_Click(object sender, EventArgs e)
  {
    if(AboutReaderCheckBox.Checked)
    {
      if(m_cn3piv.SCRPower_ReaderOn(m_hReader))
      {
        MessageBox.Show("reader on OK");
      }
      else
      {
        uint ui = GetLastError();
        MessageBox.Show("reader on ERROR " + ui.ToString());
      }
    }
    else
    {
      if(m_cn3piv.SCRPower_ReaderOff(m_hReader))
      {
        MessageBox.Show("reader off OK");
      }
      else
      {
        uint ui = GetLastError();
        MessageBox.Show("reader off ERROR " + ui.ToString());
      }
    }
  }
  #endregion

  #region private void PowerSaveButton_Click(object sender, EventArgs e)
  private void PowerSaveButton_Click(object sender, EventArgs e)
  {
    PowerFPStatusLabel.Text = "";
    PowerCCStatusLabel.Text = "";
    Power5VStatusLabel.Text = "";
    CN3PIV.Error err = m_cn3piv.SendMSRPowerSave();
    if(err != CN3PIV.Error.None)
    {
      MessageBox.Show("Error saving MSR power config.", err.ToString());
      UpdateMSRUI();
    }
    else
    {
      MessageBox.Show("Sent \"save config\" message.  Check UI for config.");
    }
  }
  #endregion

  #region private void AboutInitButton_Click(object sender, EventArgs e)
  private void AboutInitButton_Click(object sender, EventArgs e)
  {
    CN3PIV.Error err = m_cn3piv.SCRInit(CN3PIV.SCARD_SCOPE_USER);
    if(err != CN3PIV.Error.None)
    {
      MessageBox.Show("SCRInit error ", err.ToString());
    }
    else
    {
      MessageBox.Show("SCRInit OK.");
    }
  }
  #endregion

  #region private void AboutDeinitButton_Click(object sender, EventArgs e)
  private void AboutDeinitButton_Click(object sender, EventArgs e)
  {
    CN3PIV.Error err = m_cn3piv.SCRDeinit();
    if(err != CN3PIV.Error.None)
    {
      MessageBox.Show("SCRDeinit error ", err.ToString());
    }
    else
    {
      MessageBox.Show("SCRDeinit OK.");
    }
  }
  #endregion

  #endregion

}

#region public class DBEntry
/// <summary>
/// A class implementing a simple database entry used to demonstrate the
/// Sagem device's capabilities.
/// </summary>
public class DBEntry
{
  #region Members

  /// <summary>
  /// Users name.
  /// </summary>
  public string m_name;

  /// <summary>
  /// Users fingerprint minutiae data, in ILV format as generated by the
  /// Sagem device and returned in the ENROLL command response Biometric
  /// Data ILV.
  /// </summary>
  public byte[] m_minutiae;

  /// <summary>
  /// Users fingerprint image data, in WSQ format as generated by our
  /// compression utility.  No ILV formatting will wrap this data.
  /// </summary>
  public byte[] m_wsq;

  #endregion
}
#endregion
