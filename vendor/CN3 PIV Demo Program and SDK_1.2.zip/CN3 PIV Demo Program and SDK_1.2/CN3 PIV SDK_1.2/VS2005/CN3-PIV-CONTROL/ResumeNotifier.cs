//
////////////////////////////////////////////////////////////////////////////////
//
/// \file ResumeNotifier.cs
/// \brief Implementation file for the ResumeNotifier object.
/// \details ResumeNotifier is an object which allows a user to register for
/// power control 'resume' events.
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009 Semtek Innovative Solutions.  All rights reserved.
//
////////////////////////////////////////////////////////////////////////////////
//
using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

/// <summary>
/// Objet which can notify owner of "resume" power control events.
/// </summary>
class ResumeNotifier
{
  #region Members

  /// <summary>
  /// Form on which we'll invoke a delegate for 'resume' events.
  /// </summary>
  private Form m_form;

  /// <summary>
  /// Handle to event we'll use to signal the listener thread to stop
  /// </summary>
  private IntPtr m_hEvtQuit;

  /// <summary>
  /// Handle to the listener thread
  /// </summary>
  private Thread m_th;

  /// <summary>
  /// Handle to the message queue we'll register for listening
  /// </summary>
  private IntPtr m_hQueue;

  /// <summary>
  /// Delegate we'll use to invoke when a resume event happens.
  /// </summary>
  /// <param name="state">PowerState sent in resume event.</param>
  public delegate void ResumeDelegate(PowerState state);

  /// <summary>
  /// Delegate variable to which owner can add his handler.
  /// </summary>
  public ResumeDelegate HandleResume;

  #endregion

  #region Constructors

  #region public ResumeNotifier()
  /// <summary>
  /// Default constructor.
  /// </summary>
  public ResumeNotifier()
  {
    m_form = null;
    HandleResume = DefaultHandleResume;
  }
  #endregion

  #region public ResumeNotifier(Form form)
  /// <summary>
  /// Full valued constructor.  Pass in form for which handler
  /// will be Invoke()'d.
  /// </summary>
  /// <param name="form">Form on which resume event handler will be invoked.</param>
  public ResumeNotifier(Form form)
  {
    m_form = form;
    HandleResume = DefaultHandleResume;
  }
  #endregion

  #endregion

  #region Methods

  #region private void DefaultHandleResume(PowerState state)
  /// <summary>
  /// Default resume event handler.  Ignores event.
  /// </summary>
  /// <param name="state">PowerState passed in with resume event.</param>
  private void DefaultHandleResume(PowerState state)
  {
  }
  #endregion

  #region public void Start()
  /// <summary>
  /// Called to start listening for resume events.
  /// </summary>
  public void Start()
  {
    //
    // Create event to stop the thread
    //
    m_hEvtQuit = CreateEvent(0, true, false, null);

    //
    // Create listener thread
    //
    m_th = new Thread(new ThreadStart(WaitThreadProc));

    //
    // Create message queue for power broadcasts - we may get an
    // exception here if we don't have the correct API calls
    // available, so trap for that.
    //
    try
    {
      MSGQUEUEOPTIONS opt = new MSGQUEUEOPTIONS();
      opt.bReadAccess = 1;
      m_hQueue = CreateMsgQueue( "PowerEventWaitQueue", opt );
    }
    catch (MissingMethodException)
    {
      MessageBox.Show("This application uses API not available on current platform. Supported platforms are Windows CE.NET 4.1 devices, such as Windows Mobile 2003", "Error");
      return;
    }

    //
    // Start listener thread
    //
    m_th.Start();

    //
    // Register for power notifications
    //
    IntPtr hNotif = RequestPowerNotifications(m_hQueue, PowerEventType.PBT_POWERSTATUSCHANGE|PowerEventType.PBT_RESUME|PowerEventType.PBT_TRANSITION);
  }
  #endregion

  #region public void Stop()
  /// <summary>
  /// Called to stop listening for resume events
  /// </summary>
  public void Stop()
  {
    try
    {
      //
      // Tell listener thread to stop 
      //
      EventModify(m_hEvtQuit, EVENT_SET);

      //
      // Clean up
      //
      CloseHandle(m_hQueue);
    }
    catch{}
  }
  #endregion

  #region void WaitThreadProc()
  /// <summary>
  /// Thread procedure which polls message queue for power notification events.
  /// When one is detected, this thread Invoke()'s its handler on the owning
  /// form's UI thread (if a form is registered) or just calls it on this thread.
  /// </summary>
  void WaitThreadProc()
  {
    //
    // Open our message queue for reading
    //
    MSGQUEUEOPTIONS opt = new MSGQUEUEOPTIONS();
    opt.bReadAccess = 1;
    IntPtr hQueue = CreateMsgQueue("PowerEventWaitQueue", opt);

    //
    // Start waiting for Message Queue to fill up, and wait also
    // for 'stop' requests from owner
    //
    while(WaitForSingleObject(m_hEvtQuit, 0 ) != WAIT_OBJECT_0)
    {
      if(WaitForSingleObject(m_hQueue, 100) == WAIT_OBJECT_0)
      {
        //
        // ok, read data from message queue.  1024 byte buffer
        // should be well enough to read the message
        //
        POWER_BROADCAST pb = new POWER_BROADCAST(1024);
        int nRead, Flags;
        ReadMsgQueue(hQueue, pb.Data, pb.Data.Length, out nRead, 0,  out Flags);

        //
        // trap for 'resume' events and invoke delegate on form thread
        //
        if((pb.Message & PowerEventType.PBT_RESUME) == PowerEventType.PBT_RESUME)
        {
          if(m_form != null)
          {
            m_form.BeginInvoke(HandleResume, new object[] {pb.Flags});
          }
          else
          {
            HandleResume(pb.Flags);
          }
        }
      }
    }

    //
    // we've been asked to quit listening - close the handle to read our queue
    // and clean up the handle to the stop event.
    //
    CloseHandle(hQueue);
    CloseHandle(m_hEvtQuit);
  }
  #endregion

  #endregion

  #region P/Invoke Stuff

  /// <summary>
  /// See \ref http://msdn.microsoft.com/en-us/library/aa908497.aspx
  /// </summary>
  [DllImport("coredll.dll")]
  static extern bool PowerPolicyNotify(int dwMessage, int onOrOff);  

  /// <summary>
  /// See \ref http://msdn.microsoft.com/en-us/library/bb202792.aspx
  /// </summary>
  [DllImport("coredll")]
  static extern IntPtr CreateMsgQueue(string Name, MSGQUEUEOPTIONS Options);

  /// <summary>
  /// See \ref http://msdn.microsoft.com/en-us/library/aa909162.aspx
  /// </summary>
  [DllImport("coredll")]
  static extern bool ReadMsgQueue(
    IntPtr hMsgQ,
    byte[] lpBuffer,
    int cbBufferSize,
    out int lpNumberOfBytesRead,
    int dwTimeout,
    out int pdwFlags
    );

  /// <summary>
  /// See \ref http://msdn.microsoft.com/en-us/library/ms682396(VS.85).aspx
  /// </summary>
  [DllImport("coredll")]
  static extern IntPtr CreateEvent( int dwReserved1, bool bManualReset, bool bInitialState, string Name); 

  /// <summary>
  /// </summary>
  [DllImport("coredll")]
  static extern bool EventModify(IntPtr hEvent, int func); 

  /// <summary>
  /// See \ref http://msdn.microsoft.com/en-us/library/ms724211(VS.85).aspx
  /// </summary>
  [DllImport("coredll")]
  static extern bool CloseHandle(IntPtr h); 

  /// <summary>
  /// See \ref http://msdn.microsoft.com/en-us/library/aa932427.aspx
  /// </summary>
  [DllImport("coredll")]
  static extern IntPtr RequestPowerNotifications(	IntPtr hMsgQ, PowerEventType Flags );

  /// <summary>
  /// See \ref http://msdn.microsoft.com/en-us/library/ms687032(VS.85).aspx
  /// </summary>
  [DllImport("coredll")]
  static extern int WaitForSingleObject( IntPtr hHandle, int dwMilliseconds );

  const int WAIT_OBJECT_0 = 0;
  const int EVENT_SET     = 3;
  #endregion

}


/// <summary>
/// Power event type as sent through notification event.
/// </summary>
[Flags]
public enum PowerEventType
{
  PBT_TRANSITION          = 0x00000001,
  PBT_RESUME              = 0x00000002,
  PBT_POWERSTATUSCHANGE   = 0x00000004,
  PBT_POWERINFOCHANGE     = 0x00000008,
}

/// <summary>
/// Power state as sent through notification event.
/// </summary>
[Flags]
public enum PowerState
{
  POWER_STATE_ON           =(0x00010000),
  POWER_STATE_OFF          =(0x00020000),

  POWER_STATE_CRITICAL     =(0x00040000),
  POWER_STATE_BOOT         =(0x00080000),
  POWER_STATE_IDLE         =(0x00100000),
  POWER_STATE_SUSPEND      =(0x00200000),
  POWER_STATE_RESET        =(0x00800000),
}

/// <summary>
/// Message queue options structure.
/// </summary>
class MSGQUEUEOPTIONS
{
  public MSGQUEUEOPTIONS()
  {
    dwSize = Marshal.SizeOf(typeof(MSGQUEUEOPTIONS));
    dwFlags = 0;
    dwMaxMessages = 20;
    cbMaxMessage = 100;
    bReadAccess = 0;
  }
  public int dwSize;
  public int dwFlags;
  public int dwMaxMessages;
  public int cbMaxMessage;
  public int bReadAccess;
}

/// <summary>
/// Power broadcast structure as received in power notification event.
/// </summary>
class POWER_BROADCAST 
{
  public POWER_BROADCAST(int size)
  {
    m_data = new byte[size];
  }
  byte[] m_data;
  public byte[] Data { get { return m_data; } }
  public PowerEventType Message { get { return (PowerEventType)BitConverter.ToInt32(m_data, 0); } }
  public PowerState Flags { get { return (PowerState)BitConverter.ToInt32(m_data, 4); } }
  public int Length { get { return BitConverter.ToInt32(m_data, 8); } }
  public byte[] SystemPowerState { get { byte[] data = new byte[Length]; Buffer.BlockCopy(m_data, 12, data, 0, Length); return data; } }
}
