//
////////////////////////////////////////////////////////////////////////////////
//
/// \file CN3PIVDocMainPage.cpp
/// \brief Main documentation page for the CN3PIV project.
/// \details
/// \author Semtek Innovative Solutions
/// \remarks Copyright(c) 2009, Semtek Innovative Solutions.  All rights reserved.
//
/// \mainpage
/// \section Introduction
/// The CN3PIV code provides two interfaces to the CN3PIV hardware.  It allows a
/// developer to easily integrate the operation of the CN3PIV hardware into a
/// C# or C++ project.  It requires Visual Studio 2005 or greater.  It can be
/// used to develop applications for Win32, Windows Mobile 5.0 or Windows Mobile
/// 6.0.
///
/// \section CSharpAPI C# API - CN3PIV.cs
/// The C# API is contained in the \ref CN3PIV.cs file and its subordinate files
/// as demonstrated in the \ref CN3-PIV-CONTROL and \ref ParsingSerialPort
/// projects.
///
/// \section CPPAPI C++ API - CN3PIV.cpp
/// The C++ API is contained in the \ref CN3PIV.cpp file and its subordinate
/// files as demonstrated in the \ref CN3PIVLAP, \ref MorphoSmartTest and
/// \ref SerialPortTest projects.
///
/// \section WSQAPI WSQ DLL
/// The WSQ dll provides a simple interface for supporting the Wavelet Scalar
/// Quantization grayscale fingerprint image compression algorithm as described
/// at http://fingerprint.nist.gov/wsq/.
//
////////////////////////////////////////////////////////////////////////////////
//
